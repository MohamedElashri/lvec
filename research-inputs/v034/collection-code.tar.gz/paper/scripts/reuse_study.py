"""Measure construction and region scans on the real PID-selected LHCb parents."""
import argparse
import csv
import gc
import hashlib
import os
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import time

from study_source import PAPER, activate_source

MODES = ('owned_cached', 'owned_uncached', 'native', 'materialized')
STAGES = (1, 4, 16)
OUTPUT = PAPER / 'results/design-evidence-v0.3.4/reuse'


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parents(cache):
    import numpy as np
    from lhcb_analysis import momenta, energies
    from lhcb_data import KAON
    parts = []
    for polarity in ('down', 'up'):
        with np.load(cache / f'pid-selected-{polarity}.npz', allow_pickle=False) as bank:
            columns = {name: bank[name] for name in bank.files}
        spatial = momenta(columns)
        energy = energies(spatial, (KAON,) * 3)
        parts.append(tuple((spatial[0][i] + spatial[1][i]) + spatial[2][i] for i in range(3))
                     + ((energy[0] + energy[1]) + energy[2],))
    return tuple(np.concatenate([part[i] for part in parts]) for i in range(4))


def observables(p):
    import numpy as np
    return tuple(np.asarray(x) for x in (p.mass, p.pt, p.rapidity))


def scan(values, stages):
    import numpy as np
    mass, pt, rapidity = values
    return np.histogram(mass[(mass > 5.15) & (mass < 5.45)
                             & (pt > stages[0]) & (rapidity < stages[1])],
                        bins=np.linspace(5.15, 5.45, 31))[0]


def calculate(columns, mode, stages, *, retain=False):
    import awkward as ak
    import numpy as np
    from lvec import LVec
    from lvec.awkward import zip as native_zip
    if mode.startswith('owned'):
        p = LVec(*columns, max_cache_size=None if mode == 'owned_cached' else 0)
    else:
        p = native_zip(dict(zip(('px', 'py', 'pz', 'E'), columns)))
    saved = observables(p) if mode == 'materialized' else None
    result = []
    for index in range(stages):
        values = saved if saved is not None else observables(p)
        result.append(scan(values, (float(index % 4) * 2., 4. + (index // 4) * .25)))
    result = np.stack(result)
    if not retain:
        return result
    # Additional live numerical payload beyond the shared, pre-existing input.
    # Exclude transient selection masks, histograms and Python object overhead.
    owned_bytes = sum(getattr(p, key).nbytes for key in ('px', 'py', 'pz', 'E')) if mode.startswith('owned') else 0
    cache_bytes = p.cache_stats['overall']['retained_bytes'] if mode.startswith('owned') else 0
    saved_bytes = sum(value.nbytes for value in saved) if saved is not None else 0
    return result, dict(component_bytes=owned_bytes, retained_observable_bytes=cache_bytes + saved_bytes), (p, saved)


def expected(columns, stages):
    import numpy as np
    x, y, z, e = columns
    values = (np.sqrt(e*e - (x*x + y*y + z*z)), np.hypot(x, y), .5*np.log((e+z)/(e-z)))
    return np.stack([scan(values, (float(i % 4)*2., 4. + (i // 4)*.25)) for i in range(stages)])


def worker(args):
    source = activate_source()
    import lvec
    import numpy as np
    assert Path(lvec.__file__).resolve().parent == source / 'lvec'
    columns = parents(args.cache)
    reference = expected(columns, args.stages)
    call = lambda: calculate(columns, args.mode, args.stages)
    np.testing.assert_array_equal(call(), reference)
    if args.worker == 'memory':
        result, payload, keepalive = calculate(columns, args.mode, args.stages, retain=True)
        np.testing.assert_array_equal(result, reference)
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        write(args.file, [dict(mode=args.mode, stages=args.stages, repetition=args.block,
                              candidates=len(columns[0]), peak_rss_bytes=rss if sys.platform == 'darwin' else rss*1024,
                              **payload)])
        return
    gc.disable()
    try:
        loops = 1
        while True:
            start = time.perf_counter()
            for _ in range(loops): call()
            if time.perf_counter() - start >= .05: break
            loops *= 2
        rows = []
        for sample in range(5):
            cpu, start = time.process_time(), time.perf_counter()
            for _ in range(loops): result = call()
            elapsed, cpu_elapsed = time.perf_counter()-start, time.process_time()-cpu
            np.testing.assert_array_equal(result, reference)
            rows.append(dict(mode=args.mode, stages=args.stages, block=args.block, order=args.order,
                             sample=sample, loops=loops, candidates=len(columns[0]),
                             wall_seconds=elapsed/loops, cpu_seconds=cpu_elapsed/loops))
        write(args.file, rows)
    finally:
        gc.enable()


def collect(args):
    source = activate_source()
    import lvec
    from common import environment, write_provenance
    info = environment()
    assert Path(lvec.__file__).resolve().parent == source / 'lvec'
    target = args.output
    target.mkdir(parents=True, exist_ok=False)
    inputs = []
    for polarity in ('down', 'up'):
        path = args.cache / f'pid-selected-{polarity}.npz'
        inputs.append(dict(file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    write(target / 'inputs.csv', inputs)
    write_provenance(target, info, args)
    provenance = target / 'provenance.md'
    provenance.write_text(provenance.read_text().replace(
        'Numerical validation only; no execution-time measurements.',
        'One local M1 collection session with sequential fresh-process runtime and separate RSS workers.'))
    (target / 'collector.py').write_bytes(Path(__file__).read_bytes())
    (target / 'collector.sha256').write_text(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()+'\n')
    rows, memory = [], []
    env = os.environ.copy()
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        env[key] = '1'
    # Each mode occupies each process-order position twice in eight blocks.
    for block in range(8):
        order = tuple(MODES[(i+block) % 4] for i in (0, 1, 3, 2))
        for stages in STAGES if block % 2 == 0 else STAGES[::-1]:
            for rank, mode in enumerate(order):
                path = target / f'worker-{block}-{stages}-{mode}.csv'
                subprocess.run([sys.executable, __file__, '--worker', 'time', '--mode', mode,
                                '--stages', str(stages), '--block', str(block), '--order', str(rank),
                                '--cache', str(args.cache), '--file', str(path)], env=env, check=True)
                with path.open() as stream: rows.extend(csv.DictReader(stream))
                print('reuse', block+1, stages, mode, flush=True)
    write(target / 'samples.csv', rows)
    for mode in MODES:
        for repetition in range(3):
            path = target / f'memory-{mode}-{repetition}.csv'
            subprocess.run([sys.executable, __file__, '--worker', 'memory', '--mode', mode,
                            '--stages', '16', '--block', str(repetition), '--cache', str(args.cache),
                            '--file', str(path)], env=env, check=True)
            with path.open() as stream: memory.extend(csv.DictReader(stream))
    write(target / 'memory.csv', memory)
    for stages in STAGES:
        for mode in MODES:
            values = [statistics.median(float(r['wall_seconds']) for r in rows
                      if r['mode']==mode and int(r['stages'])==stages and int(r['block'])==block) for block in range(8)]
            print(stages, mode, statistics.median(values), flush=True)
    (target / 'COMPLETE').write_text(info['library_sha256']+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', type=Path, default=Path('/tmp/lvec-lhcb-open-data'))
    parser.add_argument('--output', type=Path, default=OUTPUT)
    parser.add_argument('--worker', choices=('time', 'memory'))
    parser.add_argument('--mode', choices=MODES)
    parser.add_argument('--stages', type=int, default=1)
    parser.add_argument('--block', type=int, default=0)
    parser.add_argument('--order', type=int, default=0)
    parser.add_argument('--file', type=Path)
    args = parser.parse_args()
    worker(args) if args.worker else collect(args)
