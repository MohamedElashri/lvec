"""Measure ordinary-input costs of the released validation and coordinate fixes."""
import argparse
import csv
import hashlib
import io
import importlib.metadata
import os
from pathlib import Path
import random
import platform
import statistics
import subprocess
import sys
import tomllib

from study_source import PAPER, fingerprint

THREADS = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
           'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')
SOURCES = {'released': Path(os.environ.get('LVEC_STUDY_BASELINE', '/tmp/lvec-paper-v0.3.1')), 'candidate': Path(os.environ.get('LVEC_STUDY_SOURCE', '/tmp/lvec-release-v0.3.4'))}
EXPECTED = {'released': '13be557c610f7724410cdda01d3bb30e284a1772263929327460cbbeede20556',
            'candidate': '71622a5be1ec9e2dbb9f90da0c086f5f444ba49cfa7a57e53b5fd180fd214bd4'}


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def worker(args):
    source = SOURCES[args.worker]
    assert fingerprint(source / 'lvec') == EXPECTED[args.worker]
    sys.path.insert(0, str(source))
    import numpy as np
    import lvec
    from benchmarks.runner import measure
    assert Path(lvec.__file__).resolve().parent == source.resolve() / 'lvec'
    pinned = tomllib.loads((PAPER / 'source.toml').read_text())['baseline_environment']
    assert platform.python_version() == pinned['python']
    for name in ('numpy', 'awkward', 'vector', 'pytest'):
        assert importlib.metadata.version(name) == pinned[name]
    cases = [(layout, case) for layout in ('scalar', 'numpy', 'jagged')
             for case in ('is_physical', 'positive_mass_factory', 'negative_mass_factory')]
    random.Random(20261104 + args.block).shuffle(cases)
    rows = []
    for layout, case in cases:
        def column(value):
            if layout == 'scalar':
                return float(value)
            result = np.full(10000, value, dtype=float)
            if layout == 'jagged':
                import awkward as ak
                return ak.unflatten(result, 4)
            return result
        x, y, z = map(column, (3., 4., 0.))
        if case == 'is_physical':
            collection = lvec.LVec(x, y, z, column(6.))
            call = collection.is_physical
            expected = True
        else:
            mass = column(2. if case == 'positive_mass_factory' else -2.)
            call = lambda: lvec.obj(x=x, y=y, z=z, mass=mass).E
            expected = np.sqrt(29. if case == 'positive_mass_factory' else 21.)
        def check():
            result = call()
            if layout == 'jagged':
                import awkward as ak
                assert ak.to_list(ak.num(result)) == [4]*2500
                result = ak.to_numpy(ak.flatten(result))
            np.testing.assert_allclose(result, expected, rtol=3e-15, atol=0)
        check()
        timed = measure(call, 5, .03, 3)
        check()
        for sample, seconds in enumerate(timed['seconds']):
            rows.append(dict(block=args.block, order=args.order, variant=args.worker,
                             layout=layout, particles=1 if layout == 'scalar' else 10000,
                             case=case, sample=sample, loops=timed['loops'], seconds=seconds,
                             library_sha256=EXPECTED[args.worker]))
    writer = csv.DictWriter(sys.stdout, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=PAPER / 'results/v0.3.4/measurements/api-costs')
    parser.add_argument('--worker', choices=tuple(SOURCES))
    parser.add_argument('--block', type=int)
    parser.add_argument('--order', type=int)
    args = parser.parse_args()
    if args.worker:
        worker(args)
        return
    assert any((args.output.parent / mark).exists() for mark in ('COMPLETE', 'MEASURED')), 'Finish the primary collection first'
    args.output.mkdir(exist_ok=False)
    script = Path(__file__).resolve()
    (args.output / 'collector.py').write_bytes(script.read_bytes())
    digest = hashlib.sha256(script.read_bytes()).hexdigest()
    rows = []
    env = dict(os.environ, PYTHONHASHSEED='0', **{name: '1' for name in THREADS})
    for block in range(6):
        order = ('released', 'candidate') if block % 2 == 0 else ('candidate', 'released')
        for index, variant in enumerate(order):
            print(f'API costs: block {block+1}/6, {variant}', flush=True)
            result = subprocess.run([sys.executable, '-W', 'error::RuntimeWarning', str(script),
                                     '--worker', variant, '--block', str(block), '--order', str(index)],
                                    env=env, capture_output=True, text=True, check=True, timeout=180)
            rows.extend(csv.DictReader(io.StringIO(result.stdout)))
            write(args.output / 'samples.csv', rows)
    summaries, ratios = [], []
    for layout in ('scalar', 'numpy', 'jagged'):
        for case in ('is_physical', 'positive_mass_factory', 'negative_mass_factory'):
            centers = {}
            for variant in SOURCES:
                values = []
                for block in range(6):
                    samples = [float(r['seconds']) for r in rows if r['layout'] == layout and r['case'] == case
                               and r['variant'] == variant and int(r['block']) == block]
                    assert len(samples) == 5
                    centers[variant, block] = statistics.median(samples)
                    values.append(centers[variant, block])
                median = statistics.median(values)
                summaries.append(dict(layout=layout, case=case, variant=variant, median_seconds=median,
                                      mad_seconds=statistics.median(abs(x-median) for x in values), processes=6))
            values = [centers['released', block]/centers['candidate', block] for block in range(6)]
            median = statistics.median(values)
            ratios.append(dict(layout=layout, case=case, median_ratio=median,
                               mad_ratio=statistics.median(abs(x-median) for x in values),
                               minimum=min(values), maximum=max(values), blocks=6))
    write(args.output / 'summary.csv', summaries)
    write(args.output / 'ratios.csv', ratios)
    lines = ['# Ordinary numerical-API costs', '',
             'Medians and MAD describe six fresh-process medians. Ratios are paired within blocks.',
             'Values above unity indicate shorter runtime for 0.3.4. These are descriptive controls,',
             'not complete-workflow results. Scalar cells contain one vector, other cells 10,000 particles.', '',
             '| Layout | API | 0.3.1 median ms | 0.3.4 median ms | 0.3.1 / 0.3.4 |',
             '| --- | --- | ---: | ---: | ---: | ---: |']
    for row in ratios:
        cells = [next(r for r in summaries if r['layout'] == row['layout'] and r['case'] == row['case']
                      and r['variant'] == variant) for variant in ('released', 'candidate')]
        values = [f'${1000*r["median_seconds"]:.5f}$' for r in cells]
        lines.append(f'| {row["layout"]} | `{row["case"]}` | ' + ' | '.join(values)
                     + f' | ${row["median_ratio"]:.3f}$ |')
    lines += ['', 'All raw samples, loop counts, process orders, source fingerprints, and dispersion',
              'remain in the CSVs. Safeguards remain enabled. Slower controls are retained.', '']
    (args.output / 'README.md').write_text('\n'.join(lines))
    (args.output / 'provenance.md').write_text(
        '# Ordinary numerical-API cost comparison\n\n'
        f'Collector SHA256: `{digest}`. The exact collector is retained as `collector.py`.\n\n'
        f'Python {platform.python_version()}, platform `{platform.platform()}`.\n\n'
        'Six alternating-order blocks compare clean releases 0.3.1 and 0.3.4. Each treatment runs\n'
        'in a fresh process. Nine layout/API cells share shuffled order within each block.\n'
        'Each cell uses five calibrated samples of at least 0.03 s, three warmups, and disabled\n'
        'garbage collection through the unchanged benchmark timer. Numerical checks occur outside timing.\n'
        'Inputs are ordinary, finite values, far from cancellation boundaries. Scalar cells contain\n'
        'one vector. Dense and jagged cells contain 10,000 particles, four per jagged event.\n'
        'These are API construction/validation costs, not complete-workflow improvements.\n'
        'Ratios above one indicate shorter runtime for 0.3.4. MAD describes process-block dispersion.\n'
        'This supplementary collection follows, and does not overlap, the primary frozen collection.\n')
    print('Ordinary numerical-API cost comparison complete.', flush=True)


if __name__ == '__main__':
    main()
