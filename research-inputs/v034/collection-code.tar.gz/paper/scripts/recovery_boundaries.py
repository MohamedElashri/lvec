"""Untimed adjacent-input checks of the released numerical recovery policies."""
import argparse
import csv
from decimal import Decimal, localcontext
import hashlib
import math
from pathlib import Path
from unittest.mock import patch

from study_source import PAPER, activate_source, fingerprint
from boundary_manifest import write_manifest


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def neighbors(value):
    return (('below', math.nextafter(value, -math.inf)), ('at', value),
            ('above', math.nextafter(value, math.inf)))


def axis_reference(row, parameter, precision):
    """Independent Decimal Lorentz matrix for a signed-gamma x boost."""
    with localcontext() as context:
        context.prec = precision
        x, y, z, energy = map(Decimal.from_float, row)
        g = abs(Decimal.from_float(parameter))
        u = ((g-1)*(g+1)).sqrt()
        if parameter < 0:
            u = -u
        return (g*x+u*energy, y, z, u*x+g*energy)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=PAPER / 'results/numerical-detail-v0.3.4/boundaries')
    args = parser.parse_args()
    source = activate_source()
    import lvec
    import lvec._exact as exact
    import lvec._boost as boost
    import numpy as np
    from accuracy import error_metrics
    from common import environment, write_provenance
    from ordinary_recovery import instrument, counters
    from references import invariant, root_reference, as_decimal, rounded
    assert Path(lvec.__file__).resolve().parent == source / 'lvec'
    assert lvec.__version__ == '0.3.4'
    output = args.output
    output.mkdir(parents=True, exist_ok=False)
    write_provenance(output, environment(), args)
    (output / 'collector.py').write_bytes(Path(__file__).read_bytes())
    (output / 'collector.sha256').write_text(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()+'\n')
    write(output / 'code-inputs.csv', [dict(file=name,
        sha256=hashlib.sha256((PAPER / 'scripts' / name).read_bytes()).hexdigest())
        for name in ('study_source.py', 'accuracy.py', 'references.py', 'ordinary_recovery.py',
                     'common.py', 'boundary_manifest.py')])
    epsilon = np.finfo(float).eps
    threshold = math.sqrt(epsilon)
    upper = math.sqrt(np.finfo(float).max)/4
    lower = 4*math.sqrt(np.finfo(float).tiny)/epsilon
    assert upper == exact._SAFE_MAX and lower == exact._SAFE_MIN
    cases = []
    for prefix, cutoff in (('cancellation_', threshold), ('mass_cancellation_', 1./4096)):
        for sign in (1, -1):
            for position, x in neighbors(math.sqrt(1-sign*cutoff)):
                cases.append((prefix+str(sign), position, (x, 0., 0., 1.), None))
    for position, small in neighbors(1e-12):
        cases.append(('component_hierarchy', position, (1., small, 0., 1.),
                      'integer' if small < 1e-12 else 'compensated'))
    for position, large in neighbors(upper):
        cases.append(('upper_range', position, (large, math.ldexp(large, -27), 0., large),
                      'integer' if large > upper else 'compensated'))
    for position, small in neighbors(lower):
        large = math.ldexp(small, 27)
        cases.append(('lower_range', position, (large, small, 0., large),
                      'integer' if small < lower else 'compensated'))
    rows = []
    for family, position, values, expected_route in cases:
        squared, scale = invariant(values)
        with localcontext() as context:
            context.prec = 800
            root_scale = as_decimal(scale).sqrt()
        initial = values[3]*values[3]-sum(x*x for x in values[:3])
        for observable, reference, denominator in (
                ('mass2', squared, scale), ('mass', root_reference(squared), root_scale)):
            cutoff = threshold if observable == 'mass2' else 1./4096
            recover = (not math.isfinite(initial) or abs(initial) <= cutoff*values[3]*values[3]
                       or abs(initial) < np.finfo(float).tiny)
            def evaluate():
                obj = lvec.LVec(*(np.full(17, value) for value in values))
                return getattr(obj, observable)
            plain = evaluate()
            count = counters()
            with instrument(count):
                actual = evaluate()
            assert np.array_equal(actual.view(np.uint64), plain.view(np.uint64))
            assert count['invariant_entries'] == 17
            assert count['recovered_invariants'] == 17*int(recover), (family, position, count)
            if expected_route == 'integer':
                assert count['integer_entries'] == 17 and count['compensated_attempts'] == 0
            if expected_route == 'compensated':
                assert count['compensated_attempts'] == 17 and count['integer_entries'] == 0
            metrics = error_metrics(float(actual[0]), reference, denominator)
            assert metrics['status'] == 'finite', (family, position, observable, metrics)
            assert metrics['within_error_bound'], (family, position, observable, metrics)
            assert np.all(actual == actual[0])
            rows.append(dict(family=family, position=position, observable=observable,
                **{name+'_hex': value.hex() for name, value in zip(('px', 'py', 'pz', 'E'), values)},
                preliminary_mass2_hex=initial.hex(), expected_recovery=recover,
                expected_inner_route=expected_route or 'mask-dependent',
                **count, instrumented_matches=True, **metrics))
    # Both signs cross the cancellation selection boundary in this adjacent grid.
    for prefix, observable in (('cancellation_', 'mass2'), ('mass_cancellation_', 'mass')):
        for sign in (1, -1):
            assert {r['expected_recovery'] for r in rows if r['family'] == prefix+str(sign)
                    and r['observable'] == observable} == {False, True}
    write(output / 'invariants.csv', rows)

    boost_rows = []
    original_context = boost._context
    boost_cases = []
    for position, magnitude in neighbors(1e4):
        for sign in (1, -1):
            boost_cases.append(('gamma_threshold', position, (.25, .5, -.75, 2.), sign*magnitude))
    # Span changes exercise the precision rule in public boosts, including its floor.
    for span in (0, 1, 2, 3, 52, 100, 1000, 2097):
        largest = math.ldexp(1., 1023) if span == 2097 else 1.
        smallest = math.ldexp(1., -1074) if span == 2097 else math.ldexp(1., -span)
        boost_cases.append(('precision_span', str(span), (smallest, 0., 0., largest),
                            -math.nextafter(1e4, math.inf)))
    precisions = []
    for family, position, values, parameter in boost_cases:
        contexts = []
        def counted_context(data):
            manager = original_context(data)
            contexts.append(tuple(float(x).hex() for x in data))
            return manager
        def evaluate_boost():
            obj = lvec.LVec(*(np.full(17, value) for value in values))
            result = obj.boostX(gamma=parameter)
            return tuple(np.asarray(getattr(result, key)) for key in ('px', 'py', 'pz', 'E'))
        plain = evaluate_boost()
        with patch.object(boost, '_context', counted_context):
            actual = evaluate_boost()
        assert all(np.array_equal(a.view(np.uint64), b.view(np.uint64)) for a, b in zip(actual, plain))
        if family == 'gamma_threshold':
            assert len(contexts) == (17 if abs(parameter) > 1e4 else 0), (position, parameter, len(contexts))
        inputs = (values[0], values[3], parameter)
        exponents = [math.frexp(abs(x))[1] for x in inputs if x]
        span = max(exponents)-min(exponents)
        with original_context(inputs) as context:
            precision = context.prec
        assert precision == 80+math.floor(.604*span)
        precisions.append(dict(family=family, position=position, exponent_span=span,
                               gamma_hex=parameter.hex(), decimal_digits=precision,
                               decimal_entries=len(contexts)))
        low = axis_reference(values, parameter, 400)
        high = axis_reference(values, parameter, 800)
        assert all(rounded(a).hex() == rounded(b).hex() for a, b in zip(low, high))
        scale = max(abs(value) for value in high)
        for observable, array, reference in zip(('px', 'py', 'pz', 'E'), actual, high):
            assert np.all(array == array[0])
            metrics = error_metrics(float(array[0]), reference, scale)
            assert metrics['status'] in ('finite', 'expected_overflow'), (family, position, observable, metrics)
            assert metrics['within_error_bound'], (family, position, observable, metrics)
            boost_rows.append(dict(family=family, position=position, observable=observable,
                **{name+'_hex': value.hex() for name, value in zip(('px', 'py', 'pz', 'E'), values)},
                gamma_hex=parameter.hex(), exponent_span=span, decimal_digits=precision,
                decimal_entries=len(contexts), instrumented_matches=True, **metrics))
    write(output / 'boosts.csv', boost_rows)
    write(output / 'precision.csv', precisions)
    outside = [row for row in rows+boost_rows if not row['within_error_bound']]
    assert not outside, outside
    summary = (f'Boundary route and reference checks: PASSED\nLibrary SHA256: {fingerprint(source / "lvec")}\n'
        f'{len(cases)} invariant inputs, two observables each, and {len(boost_cases)} signed-gamma boosts, four components each.\n'
        'Every public call uses 17-element NumPy arrays to exercise the bulk path.\n'
        'Immediate binary64 neighbors test cancellation, hierarchy, compensated-range and gamma thresholds.\n'
        'The gamma threshold is checked with both boost directions. Precision-span probes include floor transitions and the full binary64 exponent span.\n'
        'Selected routes match the documented predicates.\n'
        f'{len(outside)} of {len(rows)+len(boost_rows)} observable results exceed the empirical fixture criterion.\n'
        'Every invariant and boost output satisfies the unchanged empirical fixture criterion.\n'
        'Instrumentation preserves every output bit. No timing is collected.\n'
        'These local boundary checks do not prove correct rounding or complete threshold coverage.\n')
    (output / 'summary.txt').write_text(summary)
    (output / 'COMPLETE').write_text(fingerprint(source / 'lvec')+'\n')
    write_manifest(output)
    print(summary)


if __name__ == '__main__':
    main()
