"""Resident LHCb analysis with Python array packages and a compiled reference.

The complete magnet-down PID-selected sample is resident. Each call forms the
three-kaon parents, mass and Dalitz histograms, and the helicity histogram.
The compiled treatment is an explicit-component Numba loop; compilation is
excluded by a checked warmup. ROOT input is excluded for every treatment.
"""
import argparse
import csv
import gc
import hashlib
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

from study_source import PAPER, activate_source

TREATMENTS = ('lvec_numpy', 'lvec_native', 'vector_numpy', 'vector_awkward', 'numba')
KEYS = ('mass', 'positive', 'negative', 'dalitz_positive', 'dalitz_negative', 'helicity')


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def columns(cache, polarity):
    import numpy as np
    with np.load(cache/f'pid-selected-{polarity}.npz', allow_pickle=False) as bank:
        return {name: bank[name] for name in bank.files}


def compiled():
    import numba
    import numpy as np
    from lhcb_analysis import MASS_EDGES, DALITZ_EDGES, ANGLE_EDGES
    from lhcb_data import KAON
    mlo, mstep, mbins = MASS_EDGES[0], MASS_EDGES[1]-MASS_EDGES[0], len(MASS_EDGES)-1
    dstep, dbins = DALITZ_EDGES[1]-DALITZ_EDGES[0], len(DALITZ_EDGES)-1
    abins = len(ANGLE_EDGES)-1

    @numba.njit(cache=False)
    def kernel(x, y, z, q, mass_h, pos_h, neg_h, dpos, dneg, hel):
        n = x.shape[1]
        k2 = KAON*KAON
        for c in range(n):
            e0 = np.sqrt(x[0, c]*x[0, c]+y[0, c]*y[0, c]+z[0, c]*z[0, c]+k2)
            e1 = np.sqrt(x[1, c]*x[1, c]+y[1, c]*y[1, c]+z[1, c]*z[1, c]+k2)
            e2 = np.sqrt(x[2, c]*x[2, c]+y[2, c]*y[2, c]+z[2, c]*z[2, c]+k2)
            px = x[0, c]+x[1, c]+x[2, c]; py = y[0, c]+y[1, c]+y[2, c]; pz = z[0, c]+z[1, c]+z[2, c]
            E = e0+e1+e2
            s = E*E-(px*px+py*py+pz*pz)
            m = np.sqrt(s) if s >= 0 else -np.sqrt(-s)
            charge = q[0, c]+q[1, c]+q[2, c]
            b = int(np.floor((m-mlo)/mstep))
            if 0 <= b < mbins:
                mass_h[b] += 1
                if charge == 1: pos_h[b] += 1
                elif charge == -1: neg_h[b] += 1
            if not (5.15 < m < 5.45) or abs(charge) != 1:
                continue
            odd = -1
            for i in range(3):
                if q[i, c] == -charge: odd = i
            if odd < 0:
                continue
            a = 1 if odd == 0 else 0
            d = 1 if odd == 2 else 2
            es = (e0, e1, e2)
            pa = (x[odd, c]+x[a, c], y[odd, c]+y[a, c], z[odd, c]+z[a, c], es[odd]+es[a])
            pb = (x[odd, c]+x[d, c], y[odd, c]+y[d, c], z[odd, c]+z[d, c], es[odd]+es[d])
            sa = pa[3]*pa[3]-(pa[0]*pa[0]+pa[1]*pa[1]+pa[2]*pa[2])
            sb = pb[3]*pb[3]-(pb[0]*pb[0]+pb[1]*pb[1]+pb[2]*pb[2])
            low, high = (sa, sb) if sa <= sb else (sb, sa)
            i, j = int(np.floor(low/dstep)), int(np.floor(high/dstep))
            if 0 <= i < dbins and 0 <= j < dbins:
                if charge == 1: dpos[i, j] += 1
                else: dneg[i, j] += 1
            r = pa if sa <= sb else pb
            mr = np.sqrt(r[3]*r[3]-(r[0]*r[0]+r[1]*r[1]+r[2]*r[2]))
            kd = (x[odd, c], y[odd, c], z[odd, c], es[odd])
            ek = (kd[3]*r[3]-(kd[0]*r[0]+kd[1]*r[1]+kd[2]*r[2]))/mr
            eb = (E*r[3]-(px*r[0]+py*r[1]+pz*r[2]))/mr
            kb = kd[3]*E-(kd[0]*px+kd[1]*py+kd[2]*pz)
            cosine = (kb-ek*eb)/(np.sqrt(max(0., ek*ek-k2))*np.sqrt(max(0., eb*eb-s)))
            cosine = min(1., max(-1., cosine))
            h = int(np.floor((cosine+1.)*abins/2.))
            hel[min(h, abins-1)] += 1

    def call(data):
        x, y, z, q = data
        out = (np.zeros(mbins, np.int64), np.zeros(mbins, np.int64), np.zeros(mbins, np.int64),
               np.zeros((dbins, dbins), np.int64), np.zeros((dbins, dbins), np.int64), np.zeros(abins, np.int64))
        kernel(x, y, z, q, *out)
        return dict(zip(KEYS, out))
    return call


def treatment_call(name, data):
    from lhcb_analysis import calculate
    if name == 'numba':
        import numpy as np
        x, y, z = (np.stack([data[f'H{i}_P{a}']*.001 for i in (1, 2, 3)]) for a in 'XYZ')
        q = np.stack([np.asarray(data[f'H{i}_Charge'], dtype=np.int64) for i in (1, 2, 3)])
        kernel = compiled()
        return lambda: kernel((x, y, z, q))
    implementation, layout = name.split('_')
    layout = {'numpy': 'numpy', 'native': 'awkward_native', 'awkward': 'awkward_native'}[layout]
    def call():
        result = calculate(data, implementation, layout, 'analysis')
        return {key: result[key] for key in KEYS}
    return call


def check(result, expected, tolerance):
    import numpy as np
    for key in KEYS:
        difference = int(np.abs(np.asarray(result[key]) - np.asarray(expected[key])).sum())
        assert difference <= tolerance, (key, difference)


def worker(args):
    activate_source()
    import numpy as np
    from lhcb_analysis import reference
    data = columns(args.cache, 'down')
    expected = {key: reference(data, 'analysis')[key] for key in KEYS}
    call = treatment_call(args.treatment, data)
    first = call()
    # Python packages must reproduce the reference exactly; the compiled loop
    # uses its own floating-point order and may move at most two bin entries.
    check(first, expected, 2 if args.treatment == 'numba' else 0)
    gc.disable()
    try:
        loops = 1
        while True:
            start = time.perf_counter()
            for _ in range(loops): call()
            if time.perf_counter()-start >= .05: break
            loops *= 2
        rows = []
        for sample in range(5):
            start = time.perf_counter()
            for _ in range(loops): call()
            rows.append(dict(treatment=args.treatment, block=args.block, order=args.order, repetition=sample,
                             loops=loops, candidates=len(data['H1_PX']),
                             wall_seconds=(time.perf_counter()-start)/loops))
        write(args.file, rows)
    finally:
        gc.enable()


def collect(args):
    source = activate_source()
    import lvec
    from common import environment, write_provenance
    info = environment()
    assert Path(lvec.__file__).resolve().parent == source/'lvec'
    target = args.output
    target.mkdir(parents=True, exist_ok=False)
    path = args.cache/'pid-selected-down.npz'
    write(target/'inputs.csv', [dict(file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest())])
    write_provenance(target, info, args)
    provenance = target/'provenance.md'
    provenance.write_text(provenance.read_text().replace(
        'Numerical validation only; no execution-time measurements.',
        'Sequential fresh-process resident analysis timing with a compiled explicit-component reference.'))
    (target/'collector.py').write_bytes(Path(__file__).read_bytes())
    env = dict(os.environ, NUMBA_NUM_THREADS='1', **{key: '1' for key in (
        'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')})
    rows = []
    for block in range(6):
        order = TREATMENTS[block % 5:]+TREATMENTS[:block % 5]
        if block >= 5: order = order[::-1]
        for rank, treatment in enumerate(order):
            path = target/f'worker-{block}-{treatment}.csv'
            subprocess.run([sys.executable, __file__, '--worker', '--treatment', treatment, '--block', str(block),
                            '--order', str(rank), '--cache', str(args.cache), '--file', str(path)], env=env, check=True)
            with path.open() as stream: rows.extend(csv.DictReader(stream))
        print('compiled', block+1, flush=True)
    write(target/'timing.csv', rows)
    for treatment in TREATMENTS:
        medians = [statistics.median(float(r['wall_seconds']) for r in rows
                                     if r['treatment'] == treatment and int(r['block']) == block) for block in range(6)]
        print(treatment, f'{statistics.median(medians)*1e3:.3f} ms', flush=True)
    (target/'COMPLETE').write_text(info['library_sha256']+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', type=Path, default=Path('/tmp/lvec-lhcb-open-data'))
    parser.add_argument('--output', type=Path, default=PAPER/'results/compiled-reference-v0.3.4')
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--treatment', choices=TREATMENTS)
    parser.add_argument('--block', type=int, default=0)
    parser.add_argument('--order', type=int, default=0)
    parser.add_argument('--file', type=Path)
    args = parser.parse_args()
    worker(args) if args.worker else collect(args)
