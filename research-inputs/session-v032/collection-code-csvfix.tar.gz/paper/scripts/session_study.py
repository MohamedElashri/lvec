"""Targeted independent sessions and a matched NumPy snapshot comparison."""
import argparse
import csv
from datetime import datetime, timezone
import gc
import hashlib
import itertools
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

from study_source import PAPER, activate_source, fingerprint
from boundary_manifest import write_manifest, verify_manifest

THREADS = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
           'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')
MODES = ('cached', 'lvec_materialized', 'vector_materialized')
CASES = ('lhcb_25k', 'lhcb_500k', 'cms_1m_natural')
SOURCE_SHA = 'e5c523e0bf2766d13398e596cb985c9065dacb18181cf8a6c4d546d6ad1e6174'
MODULES = ('session_study', 'reuse_study', 'common', 'study_source', 'boundary_manifest',
           'complete_study', 'component_vectors', 'lhcb_analysis', 'lhcb_data',
           'cms_analysis', 'cms_data', 'performance', 'references', 'lhcb_benchmark')


def utc():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(dict.fromkeys(key for row in rows for key in row)))
        writer.writeheader()
        writer.writerows(rows)


def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(4*1024*1024):
            sha.update(data)
    return sha.hexdigest()


def configure(args):
    source = activate_source(args.source)
    from complete_study import setup
    setup(source)
    import lvec
    assert Path(lvec.__file__).resolve().parent == source / 'lvec'
    assert fingerprint(source / 'lvec') == SOURCE_SHA
    return source


def snapshot(columns, mode):
    import numpy as np
    import vector
    from lvec import LVec
    if mode == 'vector_materialized':
        result = vector.array(dict(zip(('px', 'py', 'pz', 'E'), columns)))
        result.flags.writeable = False
    else:
        result = LVec(*columns, max_cache_size=None if mode == 'cached' else 0)
    saved = None
    if mode != 'cached':
        saved = tuple(np.asarray(value) for value in (result.mass, result.pt, result.rapidity))
        for value in saved:
            value.flags.writeable = False
    return result, saved


def reuse(columns, mode, regions, retain=False):
    import numpy as np
    from reuse_study import observables, scan
    obj, saved = snapshot(columns, mode)
    result = np.stack([scan(saved if saved is not None else observables(obj),
                           (float(i % 4)*2., 4.+(i//4)*.25)) for i in range(regions)])
    if not retain:
        return result
    components = sum(np.asarray(getattr(obj, key)).nbytes for key in ('px', 'py', 'pz', 'E'))
    observables = (sum(value.nbytes for value in saved) if saved is not None
                   else obj.cache_stats['overall']['retained_bytes'])
    return result, dict(component_bytes=components, observable_bytes=observables), (obj, saved)


def check_snapshots(columns):
    import numpy as np
    from reuse_study import expected
    checks = []
    for mode in MODES:
        for regions in (1, 16):
            np.testing.assert_array_equal(reuse(columns, mode, regions), expected(columns, regions))
        copied = tuple(value.copy() for value in columns)
        obj, saved = snapshot(copied, mode)
        original = [np.asarray(getattr(obj, key)).copy() for key in ('px', 'py', 'pz', 'E')]
        for source, key in zip(copied, ('px', 'py', 'pz', 'E')):
            component = np.asarray(getattr(obj, key))
            assert not component.flags.writeable and not np.shares_memory(component, source)
            source[0] += 1.
        for key, value in zip(('px', 'py', 'pz', 'E'), original):
            np.testing.assert_array_equal(getattr(obj, key), value)
        checks.append(dict(strategy=mode, snapshot_isolated=True, components_readonly=True,
                           regions_1_equal=True, regions_16_equal=True))
    return checks


def host_metadata(args, output):
    from common import environment, write_provenance
    info = environment()
    write_provenance(output, info, args)
    path = output / 'provenance.md'
    path.write_text(path.read_text().replace('Numerical validation only; no execution-time measurements.',
        'Preparation is untimed. Session collectors execute validated workloads in separate fresh processes.'))
    expected = {'m1-macos': ('Darwin', ('arm64',)), 'x86_64-linux': ('Linux', ('x86_64',)),
                'aarch64-linux': ('Linux', ('aarch64', 'arm64'))}
    system, machines = expected[args.host]
    assert platform.system() == system and platform.machine().lower() in machines
    if system == 'Darwin':
        hardware = subprocess.check_output(['sysctl', 'machdep.cpu.brand_string', 'hw.memsize'], text=True)
        assert 'Apple M1' in hardware
        (output / 'hardware.txt').write_text(hardware)
    else:
        for name in ('cpuinfo', 'meminfo', 'sys/kernel/random/boot_id'):
            (output / (Path(name).name+'.txt')).write_bytes((Path('/proc') / name).read_bytes())
    (output / 'allocation.txt').write_text(''.join(f'{key}={os.environ.get(key, "not-set")}\n'
        for key in ('GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT', 'RUNNER_NAME', 'RUNNER_ARCH'))+
        f'host={args.host}\naffinity={sorted(os.sched_getaffinity(0)) if hasattr(os,"sched_getaffinity") else "unsupported"}\n')
    write(output / 'code-inputs.csv', [dict(file=name+'.py', sha256=digest(PAPER/'scripts'/f'{name}.py'))
                                     for name in MODULES])
    return info


def prepare(args):
    import numpy as np
    from lhcb_data import FILES, READ_BRANCHES, chunks, pid, select, verify
    from lhcb_analysis import reference, add_results
    from reuse_study import parents
    from cms_data import load_cache, NAME, verify as verify_cms
    from cms_analysis import calculate, check
    output = args.output
    output.mkdir(parents=True, exist_ok=False)
    host_metadata(args, output)
    golden = []
    for polarity in ('down', 'up'):
        verify(args.lhcb_cache/FILES[polarity]['name'], FILES[polarity])
        total, parts = None, []
        for columns in chunks(args.lhcb_cache/FILES[polarity]['name'], 100000):
            total = add_results(total, reference(columns, 'analysis'))
            parts.append(select(columns, pid(columns)))
        for name, values in total.items():
            if name == 'counts':
                continue
            for index, value in np.ndenumerate(values):
                golden.append(dict(polarity=polarity, observable=name, bin_x=index[0],
                                   bin_y=index[1] if len(index)>1 else -1, count=int(value)))
        selected = {name:np.concatenate([part[name] for part in parts]) for name in READ_BRANCHES}
        path = args.lhcb_cache/f'pid-selected-{polarity}.npz'
        if path.exists():
            with np.load(path, allow_pickle=False) as saved:
                for name, value in selected.items(): np.testing.assert_array_equal(saved[name], value)
        else:
            np.savez(path, **selected)
        print('Prepared independent LHCb reference:', polarity, flush=True)
    write(output/'golden-histograms.csv', golden)
    verify_cms(args.cms_cache/NAME)
    columns = load_cache(args.cms_cache/'prefix-1000000.npz')
    expected = calculate(columns, 'components', 'pairs')
    for variant in ('lvec', 'vector_coordinates'):
        check(calculate(columns, variant, 'pairs'), expected)
    write(output/'snapshot-checks.csv', check_snapshots(parents(args.lhcb_cache)))
    paths = [*(args.lhcb_cache/FILES[p]['name'] for p in ('down','up')),
             *(args.lhcb_cache/f'pid-selected-{p}.npz' for p in ('down','up')),
             args.cms_cache/NAME, args.cms_cache/'prefix-1000000.npz']
    write(output/'inputs.csv', [dict(file=str(path), bytes=path.stat().st_size,
                                    mtime_ns=path.stat().st_mtime_ns, sha256=digest(path)) for path in paths])
    (output/'COMPLETE').write_text(SOURCE_SHA+'\n')
    write_manifest(output)
    print('Preparation and matched-snapshot validation complete.', flush=True)


def collision_worker(args):
    from complete_study import worker
    suite, case, variant = ('cms', 1, 'vector_coordinates' if args.variant == 'vector' else 'candidate') if args.case == 'cms_1m_natural' else ('lhcb', 0 if args.case == 'lhcb_25k' else 2, args.variant)
    # The original worker reads its independent histogram reference here.
    import common
    reference = read(args.preparation/'golden-histograms.csv')
    golden_path = PAPER/'results/lhcb/histograms.csv'
    golden_path.parent.mkdir(parents=True, exist_ok=True)
    if not golden_path.exists(): write(golden_path, reference)
    else:
        records = lambda rows: sorted(tuple(sorted(row.items())) for row in rows)
        assert records(read(golden_path)) == records(reference)
    worker(argparse.Namespace(source=args.source, suite=suite, case=case, variant=variant,
        mode='time', block=args.block, order=args.order, output=args.file,
        lhcb_cache=args.lhcb_cache, cms_cache=args.cms_cache))


def reuse_worker(args):
    import resource
    import numpy as np
    from reuse_study import parents, expected
    from lhcb_benchmark import timed
    columns = parents(args.lhcb_cache)
    oracle = expected(columns, args.regions)
    if args.kind == 'memory':
        actual, payload, keepalive = reuse(columns, args.strategy, args.regions, retain=True)
        np.testing.assert_array_equal(actual, oracle)
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        write(args.file, [dict(strategy=args.strategy, repetition=args.block,
              peak_rss_bytes=peak if sys.platform == 'darwin' else peak*1024, **payload)])
        return
    call = lambda:reuse(columns, args.strategy, args.regions)
    np.testing.assert_array_equal(call(), oracle)
    rows = timed(call, 5, 0, .05)
    np.testing.assert_array_equal(call(), oracle)
    write(args.file, [dict(strategy=args.strategy, regions=args.regions, block=args.block,
                           order=args.order, **row) for row in rows])


def collect(args):
    verify_manifest(args.preparation)
    assert (args.preparation/'COMPLETE').read_text().strip() == SOURCE_SHA
    for row in read(args.preparation/'code-inputs.csv'):
        assert digest(PAPER/'scripts'/row['file']) == row['sha256'], row['file']
    for row in read(args.preparation/'inputs.csv'):
        stat = Path(row['file']).stat()
        assert stat.st_size == int(row['bytes']) and stat.st_mtime_ns == int(row['mtime_ns'])
    output = args.output
    output.mkdir(parents=True, exist_ok=False)
    host_metadata(args, output)
    start = utc()
    env = dict(os.environ, PYTHONHASHSEED='0', **{key:'1' for key in THREADS})
    base = [sys.executable, __file__, 'worker', '--host', args.host, '--source', str(args.source),
            '--preparation', str(args.preparation), '--lhcb-cache', str(args.lhcb_cache),
            '--cms-cache', str(args.cms_cache)]
    collision, reuse_rows, memory = [], [], []
    for block, order in enumerate(itertools.permutations(CASES)):
        for index, case in enumerate(order):
            variants = ('candidate','vector') if (block+args.session)%2 == 0 else ('vector','candidate')
            for rank, variant in enumerate(variants):
                path = output/f'collision-{block}-{case}-{variant}.csv'
                subprocess.run([*base,'--kind','collision','--case',case,'--variant',variant,
                    '--block',str(block),'--order',str(rank),'--file',str(path)],env=env,check=True)
                collision += [dict(selected_case=case, session=args.session, **row) for row in read(path)]
                print('session',args.session,block,case,variant,flush=True)
    for block, order in enumerate(itertools.permutations(MODES)):
        for regions in ((1,16) if block%2 == 0 else (16,1)):
            for rank, strategy in enumerate(order):
                path = output/f'reuse-{block}-{regions}-{strategy}.csv'
                subprocess.run([*base,'--kind','reuse','--strategy',strategy,'--regions',str(regions),
                    '--block',str(block),'--order',str(rank),'--file',str(path)],env=env,check=True)
                reuse_rows += [dict(session=args.session, **row) for row in read(path)]
    for strategy in MODES:
        for repetition in range(3):
            path = output/f'memory-{strategy}-{repetition}.csv'
            subprocess.run([*base,'--kind','memory','--strategy',strategy,'--regions','16',
                '--block',str(repetition),'--file',str(path)],env=env,check=True)
            memory += [dict(session=args.session, **row) for row in read(path)]
    write(output/'collision.csv',collision)
    write(output/'reuse.csv',reuse_rows)
    write(output/'memory.csv',memory)
    (output/'session.md').write_text(f'host = {args.host}\nsession = {args.session}\nstart_utc = {start}\nend_utc = {utc()}\n'
        f'preparation_manifest_sha256 = {digest(args.preparation/"checksums.sha256")}\n')
    (output/'COMPLETE').write_text(SOURCE_SHA+'\n')
    write_manifest(output)
    print('Completed session',args.host,args.session,flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('prepare','collect','worker'))
    p.add_argument('--host', choices=('m1-macos','x86_64-linux','aarch64-linux'), required=True)
    p.add_argument('--source', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--preparation', type=Path)
    p.add_argument('--session', type=int, choices=(1,2,3), default=1)
    p.add_argument('--lhcb-cache', type=Path, default=Path('/tmp/lvec-lhcb-open-data'))
    p.add_argument('--cms-cache', type=Path, default=Path('/tmp/lvec-cms-open-data'))
    p.add_argument('--kind', choices=('collision','reuse','memory'))
    p.add_argument('--strategy', choices=MODES)
    p.add_argument('--regions', type=int, default=1)
    p.add_argument('--case', choices=CASES)
    p.add_argument('--variant', choices=('candidate','vector'))
    p.add_argument('--block', type=int, default=0)
    p.add_argument('--order', type=int, default=0)
    p.add_argument('--file', type=Path)
    args = p.parse_args()
    args.source = configure(args)
    if args.command == 'prepare': prepare(args)
    elif args.command == 'collect': collect(args)
    elif args.kind == 'collision': collision_worker(args)
    else: reuse_worker(args)


if __name__ == '__main__':
    main()
