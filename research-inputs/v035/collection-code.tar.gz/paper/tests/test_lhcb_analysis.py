"""Physics anchors for flat collision-candidate analysis and selection ordering."""
from pathlib import Path
import sys
import numpy as np
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from lhcb_analysis import calculate,reference,check,LAYOUTS,SCENARIOS
from lhcb_data import KAON,BRANCHES,pid

MASS=5.28
pytestmark=pytest.mark.filterwarnings('ignore:Setting the dtype on a NumPy array has been deprecated:DeprecationWarning:vector.backends.numpy')

def toy():
    # Symmetric decay inside the fixed parent window; every observable is populated.
    q=np.sqrt((MASS/3)**2-KAON**2)
    momenta=[(q,0.,0.),(-q/2,q*np.sqrt(3)/2,0.),(-q/2,-q*np.sqrt(3)/2,0.)]
    data={name:np.zeros(4) for name in BRANCHES}
    for i,p in enumerate(momenta,1):
        for axis,value in zip('XYZ',p):data[f'H{i}_P{axis}'][:]=1000*value
        data[f'H{i}_ProbK'][:]=.9;data[f'H{i}_ProbPi'][:]=.1
        data[f'H{i}_Charge'][:]=1 if i<3 else -1
    data['H1_ProbK'][1]=-1000  # Actual data can contain invalid-PID sentinels.
    data['H2_isMuon'][2]=1
    return data


def helicity_anchor():
    # The other opposite-sign invariant is linear in the helicity cosine:
    # s_other = 2m^2 + 2(E_k* E_s* + |p_k*||p_s*| cos).
    pair=(MASS**2+3*KAON**2)/3;mr=np.sqrt(pair)
    ek=mr/2;es=(MASS**2-pair-KAON**2)/(2*mr)
    return (pair-2*KAON**2-2*ek*es)/(2*np.sqrt(ek*ek-KAON**2)*np.sqrt(es*es-KAON**2))


def test_helicity_matches_public_helicity_angle():
    from lvec import LVec
    data=toy();data['H2_PY']*=1.0001
    actual=calculate(data,'lvec','numpy','rest_frame',True)
    k=[LVec(*(data[f'H{i}_P{a}'][[0,3]]*1e-3 for a in 'XYZ'),
            np.sqrt(sum((data[f'H{i}_P{a}'][[0,3]]*1e-3)**2 for a in 'XYZ')+KAON**2)) for i in (1,2,3)]
    low=(k[2]+k[0]).mass2<=(k[2]+k[1]).mass2
    partner=[k[0][j] if low[j] else k[1][j] for j in range(2)]
    angle=[k[2][j].helicity_angle(k[2][j]+partner[j],k[0][j]+k[1][j]+k[2][j]) for j in range(2)]
    np.testing.assert_allclose(actual['cosine'],np.cos(angle),rtol=1e-12,atol=1e-12)


def test_units_charge_pairing_and_rest_frame():
    data=toy();expected=reference(data,'analysis',True)
    assert len(expected['rest_energy'])==2 and len(expected['cosine'])==2
    np.testing.assert_allclose(expected['masses'],MASS,rtol=2e-15)
    np.testing.assert_allclose(expected['rest_energy'],MASS/3,rtol=2e-15)
    # The symmetric toy decay has an exactly perpendicular helicity direction.
    assert abs(helicity_anchor())<1e-15
    np.testing.assert_allclose(expected['cosine'],helicity_anchor(),rtol=0,atol=2e-15)
    assert expected['dalitz_positive'].sum()==2 and expected['dalitz_negative'].sum()==0
    assert pid(data).tolist()==[True,False,False,True]
    # Pairwise invariants of this symmetric decay are equal analytically.
    np.testing.assert_allclose(expected['low'],(MASS**2+3*KAON**2)/3,rtol=2e-15)
    np.testing.assert_allclose(expected['high'],expected['low'],rtol=2e-15)


@pytest.mark.parametrize('layout',LAYOUTS)
@pytest.mark.parametrize('implementation',['lvec','vector'])
def test_public_workflows_and_selection_equivalence(layout,implementation):
    data=toy()
    data['H2_PY']*=1.0001
    for scenario in SCENARIOS:check(calculate(data,implementation,layout,scenario),reference(data,scenario))
    early=calculate(data,implementation,layout,'select_early')
    late=calculate(data,implementation,layout,'select_late')
    check(early,late)
    for key in ('mass','positive','negative','counts'):np.testing.assert_array_equal(early[key],calculate(data,implementation,layout,'analysis')[key])


def test_exact_angle_boundary_is_a_rounding_case_not_a_physics_failure():
    data=toy()
    expected=reference(data,'rest_frame',True)
    actual=calculate(data,'lvec','numpy','rest_frame',True)
    np.testing.assert_allclose(actual['cosine'],expected['cosine'],rtol=2e-14,atol=2e-14)
    for result in [actual,expected]:
        assert result['helicity'].sum()==2
        assert set(np.flatnonzero(result['helicity']))<={39,40}
