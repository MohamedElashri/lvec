"""Count numerical recovery routes in unboosted collision reconstructions, untimed."""
import argparse
from contextlib import contextmanager
import csv
import hashlib
import importlib
from pathlib import Path

from study_source import PAPER, activate_source

OUTPUT = PAPER / 'results/design-evidence-v0.3.5/ordinary-recovery'


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


@contextmanager
def instrument(counts):
    import numpy as np
    import lvec.utils as utils
    import lvec._exact as exact
    import lvec._boost as boost
    owned = importlib.import_module('lvec.lvec')
    originals = [(utils, 'invariant_result'), (owned, 'invariant_result'),
                 (utils, 'accurate_result'), (exact, '_compensated_sum'),
                 (exact, '_numpy_result'), (boost, '_blocked'), (boost, '_reference_decimal')]
    saved = [getattr(module, key) for module, key in originals]
    depth = 0

    def invariant(m2, *args, **kwargs):
        nonlocal depth
        counts['invariant_entries'] += np.asarray(m2).size
        depth += 1
        try: return saved[0](m2, *args, **kwargs)
        finally: depth -= 1

    def accurate(values, *args, **kwargs):
        if depth:
            mask = kwargs.get('where')
            counts['recovered_invariants'] += np.asarray(values[0]).size if mask is None else np.count_nonzero(mask)
        return saved[2](values, *args, **kwargs)

    def compensated(values, *args, **kwargs):
        if depth: counts['compensated_attempts'] += np.asarray(values[0]).size
        return saved[3](values, *args, **kwargs)

    def integer(values, *args, **kwargs):
        if depth: counts['integer_entries'] += np.asarray(values[0]).size
        return saved[4](values, *args, **kwargs)

    def blocked(evaluate, arrays, *args, **kwargs):
        def counted(*data):
            counts['boost_entries'] += np.asarray(data[0]).size
            return evaluate(*data)
        return saved[5](counted, arrays, *args, **kwargs)

    def decimal(*args, **kwargs):
        counts['decimal_entries'] += 1
        return saved[6](*args, **kwargs)

    replacements = [invariant, invariant, accurate, compensated, integer, blocked, decimal]
    try:
        for (module, key), replacement in zip(originals, replacements): setattr(module, key, replacement)
        yield
    finally:
        for (module, key), original in zip(originals, saved): setattr(module, key, original)


def counters():
    return dict(invariant_entries=0, recovered_invariants=0, compensated_attempts=0,
                integer_entries=0, boost_entries=0, decimal_entries=0)


def identical(actual, expected, label):
    import awkward as ak
    import numpy as np
    assert set(actual) == set(expected)
    rows = []
    for key in actual:
        if isinstance(actual[key], ak.Array):
            a, b = ak.to_buffers(ak.to_packed(actual[key])), ak.to_buffers(ak.to_packed(expected[key]))
            assert a[:2] == b[:2]
            assert a[2].keys() == b[2].keys()
            for name in a[2]: np.testing.assert_array_equal(a[2][name], b[2][name])
            count = int(ak.count(actual[key], axis=None))
        else:
            np.testing.assert_array_equal(actual[key], expected[key])
            count = np.asarray(actual[key]).size
        rows.append(dict(workflow=label, field=key, entries=count, instrumented_matches=True))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lhcb-cache', type=Path, default=Path('/tmp/lvec-lhcb-open-data'))
    parser.add_argument('--cms-cache', type=Path, default=Path('/tmp/lvec-cms-open-data'))
    parser.add_argument('--output', type=Path, default=OUTPUT)
    args = parser.parse_args()
    source = activate_source()
    import lvec
    from common import accurate_invariants
    # Recovery counts describe the accurate policy, which is opt-in.
    accurate_invariants()
    import awkward as ak
    import numpy as np
    from common import environment, write_provenance
    from lhcb_analysis import calculate as lhcb, reference as lhcb_reference, check as lhcb_check
    from cms_analysis import calculate as cms, check as cms_check
    from cms_data import load_cache
    assert Path(lvec.__file__).resolve().parent == source / 'lvec'
    target = args.output
    target.mkdir(parents=True, exist_ok=False)
    info = environment()
    write_provenance(target, info, args)
    (target / 'collector.py').write_bytes(Path(__file__).read_bytes())
    (target / 'collector.sha256').write_text(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()+'\n')
    results, inputs, validation = [], [], []
    for polarity in ('down', 'up'):
        path = args.lhcb_cache / f'pid-selected-{polarity}.npz'
        inputs.append(dict(file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        with np.load(path, allow_pickle=False) as bank:
            columns = {key: bank[key] for key in bank.files}
        expected = lhcb(columns, 'lvec', 'awkward_native', 'analysis', True)
        lhcb_check(expected, lhcb_reference(columns, 'analysis', True))
        count = counters()
        with instrument(count): actual = lhcb(columns, 'lvec', 'awkward_native', 'analysis', True)
        validation += identical(actual, expected, 'lhcb_'+polarity)
        results.append(dict(workflow='lhcb_'+polarity, candidates=len(columns['H1_PX']),
                            selected=int(actual['counts'][2]), **count))
    path = args.cms_cache / 'eligible-four-muon.npz'
    inputs.append(dict(file=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    columns = load_cache(path)
    expected = cms(columns, 'lvec', 'rest_frame', True)
    cms_check(expected, cms(columns, 'components', 'rest_frame', True))
    count = counters()
    with instrument(count): actual = cms(columns, 'lvec', 'rest_frame', True)
    validation += identical(actual, expected, 'cms_four_muon')
    assert len(columns['nMuon']) == 366 and int(actual['counts'][-1]) == 86
    results.append(dict(workflow='cms_four_muon', candidates=366, selected=86, **count))

    def control():
        a = float(2**100)
        data = np.tile(np.array([[3., 0., 0., 5.], [2.**20, 1., 0., 2.**20],
                                 [3*a, 4*a, 1., 5*a], [1e308, 0., 0., 1.25e308]]), (4,1))
        with np.errstate(all='ignore'):
            mass = lvec.LVec(*data.T).mass
            q = lvec.LVec(np.full(16, 1e308), np.zeros(16), np.zeros(16), np.full(16, 1e308))
            boosted = q.boostCM_of_p4(lvec.LVec(0., 0., 3., 5.))
        return dict(mass=mass, **dict(zip(('px','py','pz','E'), boosted.to_p4())))

    expected, positive = control(), counters()
    with instrument(positive): actual = control()
    validation += identical(actual, expected, 'positive_control')
    assert all(positive[key] > 0 for key in positive)
    write(target / 'controls.csv', [positive])
    write(target / 'inputs.csv', inputs)
    write(target / 'counts.csv', results)
    write(target / 'validation.csv', validation)
    (target / 'protocol.md').write_text(
        '# Ordinary-input recovery paths\n\n'
        'Untimed native-host diagnostics with released 0.3.5 and the pinned environment. '
        'LHCb uses every PID-selected candidate in both polarities with the native integrated workflow. '
        'CMS uses the complete 366-event eligible bank with four-muon and rest-frame reconstruction. '
        'No artificial longitudinal boost is applied. Invariant counts are evaluated kernel entries, '
        'including repeated observables and reference masses, not unique candidates. Boost counts '
        'are reference-boost kernel entries. Counts can include structural buffer work. '
        'Compensated attempts and integer evaluation can overlap. Decimal counts denote '
        'reevaluated four-momenta, not individual components. These are counts of activation '
        'for these samples, not event-population failure probabilities.\n\n'
        'Hooks wrap the invariant evaluator, selected recovery, compensated and integer sums, '
        'reference-boost block evaluation and Decimal calls, then restore every original function. '
        'Every result buffer and histogram matches the uninstrumented output exactly. '
        'Independent component workflows also validate selections and reconstructed observables. '
        'Positive controls activate every counted path and preserve their numerical outputs. '
        'No timing is collected or inferred from this instrumentation.\n')
    (target / 'COMPLETE').write_text(info['library_sha256']+'\n')
    print(*results, positive, sep='\n')


if __name__ == '__main__': main()
