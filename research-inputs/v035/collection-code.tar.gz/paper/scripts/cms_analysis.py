"""Muon-pair and four-muon workflows on real jagged CMS event records."""
import awkward as ak
import numpy as np
import vector

from lvec.awkward import zip as native_zip
from component_vectors import Components

Z_MASS=91.1876
TIE=1e-9
SCENARIOS=('pairs','four_muons','rest_frame')
EDGES={'mll':np.linspace(0,200,101),'m4':np.linspace(70,180,56),
       'z1':np.linspace(40,120,41),'z2':np.linspace(12,120,55),
       'helicity':np.linspace(-1,1,41),'energy':np.linspace(0,180,181)}


def flat(value):return ak.to_numpy(ak.flatten(value,axis=None))

def hist(value,edges):return np.histogram(flat(value),bins=edges)[0]


def good_muons(columns):
    fields={key[5:]:ak.values_astype(value,np.float64) if key!='Muon_charge' else value
            for key,value in columns.items() if key.startswith('Muon_')}
    fields['source_index']=ak.local_index(fields['pt'],axis=1)
    mu=ak.zip(fields)
    uncertainty=np.sqrt(mu.dxyErr**2+mu.dzErr**2)
    safe=ak.where(uncertainty>0,uncertainty,1.)
    significance=ak.where(uncertainty>0,np.sqrt(mu.dxy**2+mu.dz**2)/safe,np.inf)
    keep=(mu.pt>5)&(abs(mu.eta)<2.4)&(mu.pfRelIso04_all<.4)&(abs(mu.dxy)<.5)&(abs(mu.dz)<1)&(significance<4)
    for name in ('pt','eta','phi','mass'):keep = keep & np.isfinite(mu[name])
    keep = keep & (mu.mass>=0)
    return mu[keep]


def construct(mu,backend):
    if backend=='vector_coordinates':
        return vector.zip({'pt':mu.pt,'eta':mu.eta,'phi':mu.phi,'mass':mu.mass})
    px=mu.pt*np.cos(mu.phi);py=mu.pt*np.sin(mu.phi);pz=mu.pt*np.sinh(mu.eta)
    E=np.sqrt(px*px+py*py+pz*pz+mu.mass*mu.mass)
    if backend=='components':return Components(px,py,pz,E)
    fields={'px':px,'py':py,'pz':pz,'E':E}
    return native_zip(fields) if backend=='lvec' else vector.zip(fields)


def first(vector):
    if isinstance(vector,Components):return Components(*(ak.firsts(getattr(vector,k)) for k in ('px','py','pz','E')))
    return ak.firsts(vector)


def take(vector,index):return first(vector[ak.singletons(index)])

def pair_choice(mass):
    score=abs(mass-Z_MASS)
    minimum=ak.min(score,axis=1,keepdims=True,mask_identity=False,initial=np.inf)
    eligible=score<=minimum+TIE
    return ak.argmax(eligible,axis=1,keepdims=True,mask_identity=True)


def delta_r(mu,i,j):
    dphi=mu.phi[i]-mu.phi[j]
    wrapped=np.arctan2(np.sin(dphi),np.cos(dphi))
    return np.hypot(mu.eta[i]-mu.eta[j],wrapped)


def calculate(columns,backend,scenario,details=False):
    if scenario not in SCENARIOS:raise ValueError(scenario)
    n=len(columns['nMuon']);mu=good_muons(columns)
    total_mu=int(ak.sum(columns['nMuon']));ngood=int(ak.sum(ak.num(mu)))
    eligible=(ak.num(mu)>=4)&(ak.sum(mu.charge==1,axis=1)>=2)&(ak.sum(mu.charge==-1,axis=1)>=2)
    neligible=int(ak.sum(eligible))
    positions=ak.Array(np.arange(n,dtype=np.int64))
    if scenario!='pairs':mu=mu[eligible];positions=positions[eligible]
    if scenario!='pairs' and neligible==0:
        result={name:np.zeros(len(EDGES[name])-1,dtype=np.int64) for name in ('mll','m4','z1','z2')}
        result['counts']=np.array([n,total_mu,ngood,0,0,0],dtype=np.int64)
        if scenario=='rest_frame':
            result.update({name:np.zeros(len(EDGES[name])-1,dtype=np.int64) for name in ('helicity','energy')})
            if details:result.update(cosine=ak.Array(np.array([],dtype=float)),rest_energy=ak.Array(np.array([],dtype=float)))
        if details:result.update(pair_masses=ak.Array(np.array([],dtype=float)),masses=ak.Array(np.array([],dtype=float)),
                                 event_positions=ak.Array(np.array([],dtype=np.int64)),track_indices=ak.Array(np.empty((0,4),dtype=np.int64)))
        return result
    p=construct(mu,backend)
    pairs=ak.argcombinations(mu.pt,2,fields=['i','j'])
    pairs=pairs[mu.charge[pairs.i]*mu.charge[pairs.j]<0]
    sums=p[pairs.i]+p[pairs.j];mass=sums.mass
    result={'mll':hist(mass,EDGES['mll']),
            'counts':np.array([n,total_mu,ngood,neligible,int(ak.sum(ak.num(pairs))),0],dtype=np.int64)}
    if scenario=='pairs':
        if details:result['pair_masses']=mass
        return result
    choice=pair_choice(mass)
    ids1=ak.firsts(pairs[choice]);z1=first(sums[choice]);m1=ak.firsts(mass[choice])
    disjoint=(pairs.i!=ids1.i)&(pairs.i!=ids1.j)&(pairs.j!=ids1.i)&(pairs.j!=ids1.j)
    other_pairs=pairs[disjoint];other_mass=mass[disjoint];other_sums=sums[disjoint]
    choice2=pair_choice(other_mass)
    ids2=ak.firsts(other_pairs[choice2]);z2=first(other_sums[choice2]);m2=ak.firsts(other_mass[choice2])
    parent=z1+z2
    indices=[ids1.i,ids1.j,ids2.i,ids2.j]
    pts=ak.sort(ak.concatenate([mu.pt[ak.singletons(index)] for index in indices],axis=1),ascending=False)
    keep=ak.fill_none((m1>40)&(m1<120)&(m2>12)&(m2<120)&(pts[:,0]>20)&(pts[:,1]>10)
                      &(ak.firsts(delta_r(mu,ak.singletons(ids1.i),ak.singletons(ids1.j)))>.02)
                      &(ak.firsts(delta_r(mu,ak.singletons(ids2.i),ak.singletons(ids2.j)))>.02),False)
    result['counts'][-1]=int(ak.sum(keep))
    result.update(m4=hist(parent.mass[keep],EDGES['m4']),z1=hist(m1[keep],EDGES['z1']),z2=hist(m2[keep],EDGES['z2']))
    if scenario=='rest_frame':
        # Z1 helicity angle: the negative muon in the Z1 rest frame, measured
        # from the direction opposite the four-muon system.
        negative=ak.where(ak.firsts(mu.charge[ak.singletons(ids1.i)])<0,ids1.i,ids1.j)
        muon=take(p,negative)[keep];resonance=z1[keep];mother=parent[keep]
        a=muon.boostCM_of_p4(resonance);b=mother.boostCM_of_p4(resonance)
        cosine=-(a.px*b.px+a.py*b.py+a.pz*b.pz)/(np.sqrt(a.px*a.px+a.py*a.py+a.pz*a.pz)*np.sqrt(b.px*b.px+b.py*b.py+b.pz*b.pz))
        energy=muon.boostCM_of_p4(mother).E
        result.update(helicity=hist(np.clip(cosine,-1,1),EDGES['helicity']),energy=hist(energy,EDGES['energy']))
        if details:result.update(cosine=cosine,rest_energy=energy)
    if details:
        result.update(pair_masses=mass,masses=parent.mass[keep],event_positions=positions[keep],
                      track_indices=ak.concatenate([mu.source_index[ak.singletons(index)][keep] for index in indices],axis=1))
    return result


def check(actual,expected):
    assert set(actual)==set(expected),(set(actual),set(expected))
    for key,value in actual.items():
        if key in ('pair_masses','masses','cosine','rest_energy'):
            np.testing.assert_allclose(flat(value),flat(expected[key]),rtol=2e-7,atol=2e-8,equal_nan=False)
        elif key in ('event_positions','track_indices'):
            assert ak.to_list(value)==ak.to_list(expected[key]),key
        else:np.testing.assert_array_equal(value,expected[key],err_msg=key)


def scalar_reference(columns):
    """Independent scalar combinatorics and component arithmetic for eligible events."""
    import math
    from itertools import combinations
    output=[]
    eligible=columns['nMuon']>=4
    positions=ak.to_numpy(ak.local_index(columns['nMuon'])[eligible])
    arrays={key:ak.to_list(value[eligible]) for key,value in columns.items()}
    for event in range(len(arrays['nMuon'])):
        tracks=[]
        for i in range(int(arrays['nMuon'][event])):
            get=lambda key:float(arrays['Muon_'+key][event][i])
            pt,eta,phi,m=(get(key) for key in ('pt','eta','phi','mass'))
            dx,dy,ex,ey=(get(key) for key in ('dxy','dz','dxyErr','dzErr'))
            error=math.hypot(ex,ey)
            if not (pt>5 and abs(eta)<2.4 and m>=0 and get('pfRelIso04_all')<.4 and abs(dx)<.5 and abs(dy)<1 and error>0 and math.hypot(dx,dy)/error<4):continue
            if not all(math.isfinite(x) for x in (pt,eta,phi,m)):continue
            px=pt*math.cos(phi);py=pt*math.sin(phi);pz=pt*math.sinh(eta)
            energy=math.sqrt(px*px+py*py+pz*pz+m*m)
            tracks.append(dict(index=i,pt=pt,eta=eta,phi=phi,q=int(get('charge')),p=(px,py,pz,energy)))
        if len(tracks)<4 or sum(t['q']==1 for t in tracks)<2 or sum(t['q']==-1 for t in tracks)<2:continue
        def plus(a,b):return tuple(x+y for x,y in zip(a,b))
        def mass(p):
            q=p[3]*p[3]-sum(v*v for v in p[:3])
            return math.copysign(math.sqrt(abs(q)),q)
        pairs=[(i,j,plus(tracks[i]['p'],tracks[j]['p'])) for i,j in combinations(range(len(tracks)),2) if tracks[i]['q']!=tracks[j]['q']]
        def choose(rows):
            minimum=min(abs(mass(row[2])-Z_MASS) for row in rows)
            return next(row for row in rows if abs(mass(row[2])-Z_MASS)<=minimum+TIE)
        a=choose(pairs);b=choose([pair for pair in pairs if not {pair[0],pair[1]}&{a[0],a[1]}])
        m1,m2=mass(a[2]),mass(b[2]);indices=(a[0],a[1],b[0],b[1]);pts=sorted((tracks[i]['pt'] for i in indices),reverse=True)
        def separated(pair):
            first,second=(tracks[i] for i in pair[:2]);phi=first['phi']-second['phi']
            return math.hypot(first['eta']-second['eta'],math.atan2(math.sin(phi),math.cos(phi)))>.02
        if not (40<m1<120 and 12<m2<120 and pts[0]>20 and pts[1]>10 and separated(a) and separated(b)):continue
        output.append(dict(event=int(positions[event]),indices=[tracks[i]['index'] for i in indices],mass=mass(plus(a[2],b[2]))))
    return output
