"""Cost and accuracy of invariant-mass evaluation for light particles.

Real CMS muon momenta (first stored muons and opposite-sign pairs of the
four-muon bank) are evaluated with their stored mass and with electron, photon,
and heavy-particle hypotheses on the same momenta. Collections are built before
timing; each timed call evaluates the signed mass of one resident sample.
"""
import argparse
import csv
from decimal import Decimal, localcontext
from fractions import Fraction
import gc
import hashlib
import os
from pathlib import Path
import resource
import statistics
import subprocess
import sys
import time

from study_source import PAPER, activate_source

TREATMENTS = ('lvec_accurate', 'lvec_fast', 'lvec_previous', 'vector', 'components')
SAMPLES = ('muon', 'electron', 'photon', 'heavy', 'dimuon')
HYPOTHESES = {'electron': 0.51099895e-3, 'photon': 0., 'heavy': 5.27934}
PREVIOUS_SHA = 'fb9bd5d7bf386336aae87fad9d252bbad09670c727bfd3ef53d16c2538c2d251'
SIZE = int(os.environ.get("LVEC_LIGHT_SIZE", 1_000_000))
AUDIT = 4096


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def prepare(bank, target):
    """Cartesian float64 samples and stored masses from the four-muon bank."""
    import awkward as ak
    import numpy as np
    from cms_data import load_cache
    columns = load_cache(bank)
    fields = {name: ak.values_astype(columns['Muon_'+name], np.float64) for name in ('pt', 'eta', 'phi', 'mass')}
    charge = columns['Muon_charge']
    flat = {name: ak.to_numpy(ak.flatten(value))[:SIZE] for name, value in fields.items()}
    pt, eta, phi, mass = (flat[name] for name in ('pt', 'eta', 'phi', 'mass'))
    px, py, pz = pt*np.cos(phi), pt*np.sin(phi), pt*np.sinh(eta)
    p2 = px*px + py*py + pz*pz
    arrays = {'muon_stored_mass': mass}
    for name, value in (('muon', mass), *HYPOTHESES.items()):
        arrays[name] = np.stack((px, py, pz, np.sqrt(p2 + value*value)))
    for name in ('electron', 'photon', 'heavy'):
        arrays[name+'_stored_mass'] = np.full(len(pt), HYPOTHESES[name])
    # Opposite-sign pairs in event order, using the same Cartesian construction.
    x, y, z = (fields['pt']*np.cos(fields['phi']), fields['pt']*np.sin(fields['phi']),
               fields['pt']*np.sinh(fields['eta']))
    e = np.sqrt(x*x + y*y + z*z + fields['mass']**2)
    pairs = ak.argcombinations(fields['pt'], 2, fields=['i', 'j'])
    pairs = pairs[charge[pairs.i]*charge[pairs.j] < 0]
    total = [ak.to_numpy(ak.flatten(c[pairs.i] + c[pairs.j]))[:SIZE] for c in (x, y, z, e)]
    arrays['dimuon'] = np.stack(total)
    np.savez(target, **arrays)
    return {name: arrays[name].shape[-1] for name in SAMPLES}


def load(path, sample):
    import numpy as np
    with np.load(path, allow_pickle=False) as bank:
        return bank[sample]


def evaluator(treatment, values):
    """Return a zero-argument call evaluating the signed mass of a resident sample."""
    import numpy as np
    px, py, pz, energy = values
    if treatment == 'components':
        def call():
            squared = energy*energy - (px*px + py*py + pz*pz)
            return np.copysign(np.sqrt(abs(squared)), squared)
        return call
    if treatment == 'vector':
        import vector
        collection = vector.array({'px': px, 'py': py, 'pz': pz, 'E': energy})
        return lambda: collection.mass
    import lvec
    collection = lvec.LVec(px, py, pz, energy, max_cache_size=0)
    if treatment in ('lvec_fast', 'lvec_accurate'):
        policy = treatment.removeprefix('lvec_')
        def call():
            with lvec.invariant_policy(policy):
                return collection.mass
        return call
    # Release 0.3.3 has no policy and always recovers.
    return lambda: collection.mass


def activate(treatment, previous):
    if treatment == 'lvec_previous':
        from common import fingerprint
        assert fingerprint(previous/'lvec') == PREVIOUS_SHA, previous
        previous = previous.resolve()
        sys.path.insert(0, str(previous))
        return previous
    return activate_source()


def worker(args):
    source = activate(args.treatment, args.previous)
    import numpy as np
    if args.treatment.startswith('lvec'):
        import lvec
        assert Path(lvec.__file__).resolve().parent == source/'lvec'
    values = tuple(np.ascontiguousarray(v) for v in load(args.samples, args.sample))
    call = evaluator(args.treatment, values)
    if args.worker == 'memory':
        call()
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        write(args.file, [dict(treatment=args.treatment, sample=args.sample, repetition=args.block,
                               peak_rss_bytes=rss if sys.platform == 'darwin' else rss*1024)])
        return
    reference = call()
    gc.disable()
    try:
        loops = 1
        while True:
            start = time.perf_counter()
            for _ in range(loops): call()
            if time.perf_counter() - start >= .05: break
            loops *= 2
        rows = []
        for sample in range(5):
            cpu, start = time.process_time(), time.perf_counter()
            for _ in range(loops): result = call()
            elapsed, cpu_elapsed = time.perf_counter()-start, time.process_time()-cpu
            np.testing.assert_array_equal(result, reference)
            rows.append(dict(treatment=args.treatment, sample=args.sample, block=args.block, order=args.order,
                             repetition=sample, loops=loops, entries=len(values[0]),
                             wall_seconds=elapsed/loops, cpu_seconds=cpu_elapsed/loops))
        write(args.file, rows)
    finally:
        gc.enable()


def exact_mass(row):
    squares = [Fraction(float(v))**2 for v in row]
    invariant = squares[3] - sum(squares[:3])
    if invariant == 0:
        return 0.
    with localcontext() as context:
        context.prec = 60
        root = (Decimal(abs(invariant.numerator))/Decimal(invariant.denominator)).sqrt()
    return float(root) if invariant > 0 else -float(root)


def accuracy(samples, previous):
    """Untimed errors against the exact mass of the rounded Cartesian components."""
    import numpy as np
    rows = []
    script = Path(__file__).resolve()
    for sample in SAMPLES:
        values = load(samples, sample)
        threshold = np.abs(values[3]**2 - (values[0]**2 + values[1]**2 + values[2]**2)) <= values[3]**2/4096
        indices = np.linspace(0, values.shape[1]-1, AUDIT).astype(np.int64)
        audit = values[:, indices]
        exact = np.array([exact_mass(audit[:, k]) for k in range(AUDIT)])
        stored = load(samples, sample+'_stored_mass')[indices] if sample != 'dimuon' else None
        np.save(samples.parent/'audit-input.npy', audit)
        for treatment in TREATMENTS:
            output = samples.parent/f'audit-{treatment}.npy'
            subprocess.run([sys.executable, str(script), '--audit-worker', treatment, '--samples', str(samples),
                            '--previous', str(previous), '--file', str(output)], check=True)
            result = np.load(output)
            nonzero = exact != 0
            ulp = np.abs(result-exact)/np.spacing(np.abs(exact))
            relative = np.abs(result[nonzero]-exact[nonzero])/np.abs(exact[nonzero])
            row = dict(sample=sample, treatment=treatment, audited=AUDIT, entries=values.shape[1],
                       recovery_fraction=float(np.mean(threshold)),
                       max_ulp=float(np.max(ulp)), median_ulp=float(np.median(ulp)),
                       max_relative_to_rounded=float(np.max(relative)) if relative.size else 0.)
            if stored is not None:
                positive = stored > 0
                row['max_relative_to_stored'] = (float(np.max(np.abs(result[positive]-stored[positive])/stored[positive]))
                                                 if np.any(positive) else float('nan'))
                row['max_absolute_to_stored'] = float(np.max(np.abs(result-stored)))
            else:
                row['max_relative_to_stored'] = row['max_absolute_to_stored'] = float('nan')
            rows.append(row)
            output.unlink()
        if stored is not None:
            # Natural-coordinate storage returns the stored mass without reconstruction.
            rows.append(dict(sample=sample, treatment='stored_natural', audited=AUDIT, entries=values.shape[1],
                             recovery_fraction=float(np.mean(threshold)),
                             max_ulp=float(np.max(np.abs(stored-exact)/np.spacing(np.abs(exact)))),
                             median_ulp=float(np.median(np.abs(stored-exact)/np.spacing(np.abs(exact)))),
                             max_relative_to_rounded=float('nan'), max_relative_to_stored=0., max_absolute_to_stored=0.))
        (samples.parent/'audit-input.npy').unlink()
    return rows


def audit_worker(args):
    activate(args.audit_worker, args.previous)
    import numpy as np
    values = tuple(np.ascontiguousarray(v) for v in np.load(args.samples.parent/'audit-input.npy'))
    np.save(args.file, np.asarray(evaluator(args.audit_worker, values)()))


def collect(args):
    source = activate_source()
    import lvec
    from common import environment, write_provenance
    info = environment()
    assert Path(lvec.__file__).resolve().parent == source/'lvec'
    target = args.output
    target.mkdir(parents=True, exist_ok=False)
    bank = args.cache/'raw-four-muon.npz'
    write(target/'inputs.csv', [dict(file=bank.name, sha256=hashlib.file_digest(bank.open('rb'), 'sha256').hexdigest())])
    write_provenance(target, info, args)
    provenance = target/'provenance.md'
    provenance.write_text(provenance.read_text().replace(
        'Numerical validation only; no execution-time measurements.',
        'Sequential fresh-process mass-evaluation timing, separate RSS workers, and an untimed exact-reference audit.'))
    (target/'collector.py').write_bytes(Path(__file__).read_bytes())
    samples = target/'samples.npz'
    sizes = prepare(bank, samples)
    write(target/'sizes.csv', [dict(sample=k, entries=v) for k, v in sizes.items()])
    write(target/'accuracy.csv', accuracy(samples, args.previous))
    env = dict(os.environ, **{key: '1' for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
                                                    'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')})
    rows = []
    # Six blocks; each treatment occupies each order position at least once.
    for block in range(6):
        order = TREATMENTS[block % 5:] + TREATMENTS[:block % 5]
        if block >= 5:
            order = order[::-1]
        for sample in (SAMPLES if block % 2 == 0 else SAMPLES[::-1]):
            for rank, treatment in enumerate(order):
                path = target/f'worker-{block}-{sample}-{treatment}.csv'
                subprocess.run([sys.executable, __file__, '--worker', 'time', '--treatment', treatment,
                                '--sample', sample, '--block', str(block), '--order', str(rank),
                                '--samples', str(samples), '--previous', str(args.previous),
                                '--file', str(path)], env=env, check=True)
                with path.open() as stream: rows.extend(csv.DictReader(stream))
            print('light', block+1, sample, flush=True)
    write(target/'timing.csv', rows)
    memory = []
    for treatment in TREATMENTS:
        for repetition in range(3):
            path = target/f'memory-{treatment}-{repetition}.csv'
            subprocess.run([sys.executable, __file__, '--worker', 'memory', '--treatment', treatment,
                            '--sample', 'muon', '--block', str(repetition), '--samples', str(samples),
                            '--previous', str(args.previous), '--file', str(path)], env=env, check=True)
            with path.open() as stream: memory.extend(csv.DictReader(stream))
    write(target/'memory.csv', memory)
    samples.unlink()
    for sample in SAMPLES:
        for treatment in TREATMENTS:
            medians = [statistics.median(float(r['wall_seconds']) for r in rows if r['sample'] == sample
                                         and r['treatment'] == treatment and int(r['block']) == block) for block in range(6)]
            print(sample, treatment, f'{statistics.median(medians)*1e3:.3f} ms', flush=True)
    (target/'COMPLETE').write_text(info['library_sha256']+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', type=Path, default=Path('/tmp/lvec-cms-open-data'))
    parser.add_argument('--output', type=Path, default=PAPER/'results/light-particles-v0.3.5')
    parser.add_argument('--previous', type=Path, default=Path('/tmp/lvec-release-v0.3.3'))
    parser.add_argument('--worker', choices=('time', 'memory'))
    parser.add_argument('--audit-worker', choices=TREATMENTS)
    parser.add_argument('--treatment', choices=TREATMENTS)
    parser.add_argument('--sample', choices=SAMPLES)
    parser.add_argument('--block', type=int, default=0)
    parser.add_argument('--order', type=int, default=0)
    parser.add_argument('--samples', type=Path)
    parser.add_argument('--file', type=Path)
    args = parser.parse_args()
    if args.audit_worker:
        audit_worker(args)
    elif args.worker:
        worker(args)
    else:
        collect(args)
