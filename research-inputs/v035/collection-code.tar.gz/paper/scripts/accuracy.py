"""Measure invariant and boost errors; retain lossless inputs and all outcomes."""
import argparse
from collections import Counter
import csv
from decimal import Decimal, localcontext
from fractions import Fraction
import math
from pathlib import Path
import sys

from common import PAPER, environment, write_provenance
from references import (as_decimal, boost_reference, invariant, rational,
                        root_reference, rounded, valid_beta)
import numpy as np
import vector
from lvec import LVec
from lvec.exceptions import InputError


def invariant_inputs(seed, count):
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(count):
        spatial = rng.normal(size=3)
        energy = np.hypot(np.linalg.norm(spatial), 2.)
        rows.append(('ordinary', (*spatial, energy)))
    # Exactly representable powers isolate cancellation from input rounding.
    for exponent in (-1000, -538, -500, -100, 0, 100, 500, 900, 1000):
        scale = math.ldexp(1., exponent)
        for shift in (0, 10, 26, 52):
            residual = math.ldexp(scale, -shift)
            rows.append(('spacelike_cancellation', (scale, residual, 0., scale)))
            rows.append(('timelike_near_null', (scale, 0., 0., np.nextafter(scale, np.inf))))
        rows.extend([('exact_null', (scale, 0., 0., scale)),
                     ('rest', (0., 0., 0., scale)),
                     ('multi_term_cancellation', (3*scale, 4*scale, 1., 5*scale)),
                     # The small term first: sequential and grouped float64 sums both lose it.
                     ('leading_term_cancellation', (1., 3*scale, 4*scale, 5*scale))])
    rows.extend([('squared_underflow', (1e200, 1e-200, 0., 1e200)),
                 ('subnormal_residual', (1., math.ldexp(1., -538), math.ldexp(1., -538), 1.)),
                 ('zero', (0., 0., 0., 0.))])
    # Remove repeated binary inputs within each family, retaining the first order.
    return list({(family, tuple(float(x).hex() for x in row)): (family, row)
                 for family, row in rows}.values())


def boost_inputs(seed, count):
    rng = np.random.default_rng(seed+1)
    rows = []
    for _ in range(count):
        p = rng.normal(size=3)
        beta = rng.normal(size=3)
        beta *= rng.uniform(0., .95)/np.linalg.norm(beta)
        rows.append(('ordinary', (*p, np.hypot(np.linalg.norm(p), 2.)), tuple(beta)))
    rows.extend([
        ('zero_velocity', (1., 2., 3., 5.), (0., 0., 0.)),
        ('range', (1e308, 0., 0., 1e308), (-.9, 0., 0.)),
        ('true_overflow', (1e308, 0., 0., 1e308), (.9, 0., 0.)),
        ('cancellation', (1e308, -1e308, 1., 1.), (.6, .6, 0.)),
        ('subnormal', (1e-310, 2e-310, 0., 4e-310), (-.9, 0., 0.)),
        ('near_light_speed', (1., 0., 0., 1.), (-np.nextafter(1., 0.), 0., 0.)),
        ('rounded_beta_norm', (2., 3., 1., 4.), (.28, .96, 0.)),
    ])
    return rows


def evaluate_invariants(row, implementation):
    with np.errstate(all='ignore'):
        if implementation == 'numpy':
            x, y, z, energy = np.asarray(row, dtype=float)
            squared = energy*energy-x*x-y*y-z*z
            return squared, np.copysign(np.sqrt(abs(squared)), squared)
        fields = dict(zip(('px', 'py', 'pz', 'E'), (np.array([x]) for x in row)))
        obj = LVec(**fields) if implementation == 'lvec' else vector.array(fields)
        return float(obj.mass2[0]), float(obj.mass[0])


def evaluate_boost(row, beta, implementation):
    with np.errstate(all='ignore'):
        if implementation == 'numpy':
            row, beta = np.asarray(row), np.asarray(beta)
            b2 = np.dot(beta, beta)
            gamma = 1/np.sqrt(1-b2)
            coefficient = (gamma-1)/b2 if b2 else 0.
            spatial = row[:3]+beta*(coefficient*np.dot(beta, row[:3])+gamma*row[3])
            return (*spatial, gamma*(row[3]+np.dot(beta, row[:3])))
        if implementation == 'lvec':
            obj = LVec(*(np.array([x]) for x in row)).boost(*beta)
        else:
            obj = vector.array(dict(zip(('px', 'py', 'pz', 'E'), (np.array([x]) for x in row)))).boost_beta3(
                vector.array(dict(zip(('x','y','z'), (np.array([x]) for x in beta)))))
        return tuple(float(getattr(obj, name)[0]) for name in ('px', 'py', 'pz', 'E'))


def error_metrics(actual, reference, scale):
    """Errors use the unrounded rational/Decimal reference, not its float cast."""
    expected = rounded(reference)
    result = {'reference_float_hex': expected.hex(), 'actual_hex': float(actual).hex(),
              'reference_zero': reference == 0, 'absolute_error': '', 'scaled_error': '',
              'relative_error': '', 'log10_scaled_error': '', 'ulp_error': '',
              'zero_sign_match': '', 'error_bound': '', 'within_error_bound': False,
              'reference_range': 'overflow' if not math.isfinite(expected) else (
                  'exact_zero' if reference == 0 else 'rounded_zero' if expected == 0 else
                  'subnormal' if abs(expected) < np.finfo(float).tiny else 'normal')}
    if not math.isfinite(expected):
        result['status'] = 'expected_overflow' if actual == expected else 'overflow_mismatch'
        result['within_error_bound'] = actual == expected
        return result
    if not math.isfinite(actual):
        result['status'] = 'unexpected_nonfinite'
        return result
    result['status'] = 'finite'
    if expected == 0 and actual == 0:
        result['zero_sign_match'] = math.copysign(1, actual) == math.copysign(1, expected)
    with localcontext() as context:
        context.prec = 800
        ref = as_decimal(reference) if isinstance(reference, Fraction) else reference
        denominator = as_decimal(scale) if isinstance(scale, Fraction) else scale
        error = abs(Decimal.from_float(float(actual))-ref)
        # Relative forward-error bounds alone cannot describe subnormal rounding.
        bound = Decimal.from_float(64*np.finfo(float).eps)*denominator + Decimal.from_float(math.ulp(0.))/2
        result['error_bound'] = f'{bound:.18E}'
        result['within_error_bound'] = error <= bound
        result['absolute_error'] = f'{error:.18E}'
        result['ulp_error'] = f'{abs(Decimal.from_float(float(actual))-Decimal.from_float(expected))/Decimal.from_float(math.ulp(expected)):.10E}'
        if denominator:
            scaled = error/denominator
            result['scaled_error'] = f'{scaled:.18E}'
            if scaled:
                with localcontext() as plotting_context:
                    plotting_context.prec = 50
                    result['log10_scaled_error'] = str(float(scaled.log10()))
        if ref:
            result['relative_error'] = f'{error/abs(ref):.18E}'
    return result


def run(seed, ordinary, boost_count):
    results, domains = [], []
    for index, (family, row) in enumerate(invariant_inputs(seed, ordinary)):
        exact, scale = invariant(row)
        root = root_reference(exact)
        with localcontext() as context:
            context.prec = 800
            condition = as_decimal(scale)/abs(as_decimal(exact)) if exact else None
            root_scale = as_decimal(scale).sqrt()
        with localcontext() as context:
            context.prec = 50
            log_condition = float(condition.log10()) if condition is not None else ''
        for implementation in ('lvec', 'numpy', 'vector'):
            values = evaluate_invariants(row, implementation)
            for observable, actual, reference, denominator in zip(
                    ('mass2', 'mass'), values, (exact, root), (scale, root_scale)):
                results.append(dict(study='invariant', case=index, family=family,
                                    implementation=implementation, observable=observable,
                                    **dict(zip(('px_hex','py_hex','pz_hex','E_hex'), (float(x).hex() for x in row))),
                                    bx_hex='', by_hex='', bz_hex='', log10_condition=log_condition,
                                    **error_metrics(actual, reference, denominator)))
    for index, (family, row, beta) in enumerate(boost_inputs(seed, boost_count)):
        reference = boost_reference(row, beta)
        with localcontext() as context:
            context.prec = 800
            # Transform errors normalized by the largest exact output component.
            scale = max(abs(x) for x in reference)
        for implementation in ('lvec', 'numpy', 'vector'):
            try:
                values = evaluate_boost(row, beta, implementation)
            except (InputError, ValueError, ZeroDivisionError, OverflowError) as error:
                domains.append(dict(case=index, family=family, implementation=implementation,
                                    reference_valid=True, outcome='rejected', detail=str(error)))
                values = [math.nan]*4
            for observable, actual, expected in zip(('px','py','pz','E'), values, reference):
                results.append(dict(study='boost', case=index, family=family,
                                    implementation=implementation, observable=observable,
                                    **dict(zip(('px_hex','py_hex','pz_hex','E_hex'), (float(x).hex() for x in row))),
                                    **dict(zip(('bx_hex','by_hex','bz_hex'), (float(x).hex() for x in beta))),
                                    log10_condition='', **error_metrics(actual, expected, scale)))
    for index, beta in enumerate(((1.,0.,0.), (1.1,0.,0.), (.6,.8,0.), (math.nan,0.,0.))):
        assert not valid_beta(beta)
        for implementation in ('lvec','numpy','vector'):
            try:
                values = evaluate_boost((0.,0.,0.,1.), beta, implementation)
                outcome = 'returned_nonfinite' if not np.all(np.isfinite(values)) else 'returned_finite'
                detail = repr(tuple(float(x).hex() for x in values))
            except (InputError, ValueError, ZeroDivisionError, OverflowError) as error:
                outcome, detail = 'rejected', str(error)
            domains.append(dict(case=index, family='invalid_beta', implementation=implementation,
                                reference_valid=False, outcome=outcome, detail=repr(beta)+'; '+detail))
    return results, domains


def write_csv(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=PAPER/'results'/'accuracy')
    parser.add_argument('--ordinary', type=int, default=256)
    parser.add_argument('--boost-count', type=int, default=64)
    parser.add_argument('--seed', type=int, default=20261101)
    args = parser.parse_args()
    if args.ordinary < 1 or args.boost_count < 1 or args.seed < 0:
        parser.error('counts must be positive and seed nonnegative')
    from common import accurate_invariants
    accurate_invariants()
    info = environment()
    write_provenance(args.output, info, vars(args))
    (args.output/'summary.md').write_text('# No completed result for this invocation\n\nReplaced only after the study completes.\n')
    rows, domains = run(args.seed, args.ordinary, args.boost_count)
    write_csv(args.output/'errors.csv', rows)
    write_csv(args.output/'domains.csv', domains)
    lines = ['# Numerical accuracy study', '',
             'References describe the supplied float64 components. Invariants use exact',
             'rational products; roots and boosts agree at float64 output with 400 and',
             '800 decimal digits. Direct NumPy uses straightforward float64 expressions.', '',
             'Both libraries are evaluated on one-element dense arrays. This isolates',
             'arithmetic behavior and is not a scalar-API or throughput measurement.', '',
             '| Study | Implementation | Finite outputs | Unexpected nonfinite | Expected overflow | Wrong overflow result |',
             '| --- | --- | ---: | ---: | ---: | ---: |']
    for study in ('invariant','boost'):
        for name in ('lvec','numpy','vector'):
            selected = [r for r in rows if r['study']==study and r['implementation']==name]
            counts = Counter(r['status'] for r in selected)
            lines.append(f"| {study} | {name} | {counts['finite']} | {counts['unexpected_nonfinite']} | {counts['expected_overflow']} | {counts['overflow_mismatch']} |")
    failures = [r for r in rows if r['implementation']=='lvec' and not r['within_error_bound']]
    failures += [r for r in domains if r['implementation']=='lvec' and not r['reference_valid'] and r['outcome']!='rejected']
    lines += ['', f'LVec validation failures: {len(failures)}.', '',
              r'The finite-output bound is $\lvert\Delta\rvert\le64\epsilon S+2^{-1075}$,',
              r'where $S=E^2+p_x^2+p_y^2+p_z^2$ for the squared invariant, $\sqrt S$',
              'for signed mass, and the largest absolute reference component for a boost.',
              'The absolute term accounts for rounding on the subnormal output grid.',
              'Range and invalid-domain handling are checked separately. This is not a',
              'correct-rounding guarantee. Error data include exact-zero references,',
              'underflow, signed zero, and unfavorable outcomes for every implementation.', '',
              'These are deterministic ordinary and constructed stress inputs, not an',
              'estimate of failure frequency in experimental data. No timings were collected.', '']
    (args.output/'summary.md').write_text('\n'.join(lines))
    print('\n'.join(lines))
    if failures:
        raise SystemExit('Validation failed; artifacts retained for inspection')


if __name__ == '__main__':
    main()
