"""Source overrides must support both the shared release and distinct histories."""
import hashlib
from pathlib import Path
import sys
import tarfile

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import study_source as source


@pytest.fixture
def sources(tmp_path, monkeypatch):
    monkeypatch.setattr(source, 'PAPER', tmp_path)
    for name in ('LVEC_PAPER_SOURCE', 'LVEC_PAPER_MANUAL_SOURCE', 'LVEC_PAPER_EVALUATED_SOURCE'):
        monkeypatch.delenv(name, raising=False)
    paths = {}
    for name in ('old', 'release', 'wrong'):
        folder = tmp_path / name
        (folder / 'lvec').mkdir(parents=True)
        (folder / 'lvec/__init__.py').write_text(f'__version__ = "{name}"\n')
        paths[name] = folder
    return tmp_path, paths


def manifest(root, paths, roles, name='study-source.toml'):
    lines = []
    for role, label in roles.items():
        bundle = root / (label + '.tar.gz')
        with tarfile.open(bundle, 'w:gz') as archive:
            archive.add(paths[label], arcname='candidate')
        lines += [f'[{role}]', f'library_sha256 = "{source.fingerprint(paths[label] / "lvec")}"',
                  f'bundle = "{bundle.name}"', 'prefix = "candidate"',
                  f'bundle_sha256 = "{hashlib.sha256(bundle.read_bytes()).hexdigest()}"', '']
    target = root / name
    target.write_text('\n'.join(lines))
    return target


def test_shared_release_override_works_for_complete_build(sources, monkeypatch):
    root, paths = sources
    manifest(root, paths, dict(evaluated='release', manual='release'))
    monkeypatch.setenv('LVEC_PAPER_SOURCE', str(paths['release']))
    assert source.resolve_source() == source.resolve_source(role='manual') == paths['release']


def test_role_overrides_take_precedence_over_shared_override(sources, monkeypatch):
    root, paths = sources
    manifest(root, paths, dict(evaluated='old', manual='release'))
    monkeypatch.setenv('LVEC_PAPER_SOURCE', str(paths['wrong']))
    monkeypatch.setenv('LVEC_PAPER_EVALUATED_SOURCE', str(paths['old']))
    monkeypatch.setenv('LVEC_PAPER_MANUAL_SOURCE', str(paths['release']))
    assert source.resolve_source() == paths['old']
    assert source.resolve_source(role='manual') == paths['release']


def test_explicit_source_has_highest_precedence(sources, monkeypatch):
    root, paths = sources
    manifest(root, paths, dict(evaluated='release', manual='release'))
    monkeypatch.setenv('LVEC_PAPER_EVALUATED_SOURCE', str(paths['wrong']))
    assert source.resolve_source(paths['release']) == paths['release']


@pytest.mark.parametrize('role', ['evaluated', 'manual'])
def test_wrong_source_rejected(sources, role):
    root, paths = sources
    manifest(root, paths, dict(evaluated='release', manual='release'))
    with pytest.raises(RuntimeError, match='fingerprint mismatch'):
        source.resolve_source(paths['wrong'], role=role)


def test_source_cache_is_separated_by_fingerprint(sources):
    root, paths = sources
    old = manifest(root, paths, dict(evaluated='old'), 'old.toml')
    new = manifest(root, paths, dict(evaluated='release'), 'new.toml')
    first = source.resolve_source(metadata_file=old)
    second = source.resolve_source(metadata_file=new)
    assert first != second
    assert source.fingerprint(first / 'lvec') == source.fingerprint(paths['old'] / 'lvec')
    assert source.fingerprint(second / 'lvec') == source.fingerprint(paths['release'] / 'lvec')
