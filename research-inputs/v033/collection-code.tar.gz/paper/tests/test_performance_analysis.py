"""Check independent process weighting and the recovery diagnostic boundary."""
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from performance import summaries
from recovery import diagnose, prepare, fixture


def test_process_medians_are_equally_weighted():
    rows=[dict(layout='numpy',size=1,case='test',process=p,seconds=value)
          for p,values in enumerate(([1.,1.,100.],[3.],[8.,8.,8.,8.,8.])) for value in values]
    summary=summaries(rows)[0]
    assert summary['median_seconds']==3.
    assert summary['mad_seconds']==2.
    assert summary['processes']==3


def test_recovery_is_observed_and_instrumentation_is_restored():
    for layout in ['numpy','jagged']:
        for operation in ['mass2','boost']:
            for fraction in [0.,.0001,.01,.1,1.]:
                call,check,digest=prepare(operation,10000,fraction,20261101,layout)
                actual,counts=diagnose(call);check(actual)
                observed=counts['selected_invariant_entries']+counts['decimal_entries']
                assert observed==round(10000*fraction)
                assert counts['compensated_entries']==0
                if operation=='mass2':assert counts['integer_entries']==observed
                else:assert counts['decimal_entries']==observed
                check(call())  # Same result with real, unwrapped functions.


def test_layouts_retain_identical_binary_inputs():
    for operation in ['mass2','boost']:
        dense,mask,counts,hash_a=fixture(operation,10000,.01,20261101,'numpy')
        jagged,_,_,hash_b=fixture(operation,10000,.01,20261101,'jagged')
        import awkward as ak
        assert hash_a==hash_b and mask.sum()==100 and counts.sum()==10000 and counts[0]==0
        for a,b in zip(dense,jagged):np.testing.assert_array_equal(a,ak.to_numpy(ak.flatten(b)))
