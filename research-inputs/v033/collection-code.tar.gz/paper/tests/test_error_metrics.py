"""Check that measurement classifications handle range and quantization."""
from decimal import Decimal
from fractions import Fraction
import math
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from accuracy import error_metrics


def test_underflow_bound_includes_half_a_subnormal_step():
    tiny=Fraction(1,2**2000)
    good=error_metrics(0.,tiny,tiny)
    assert good['reference_range']=='rounded_zero'
    assert good['within_error_bound']
    assert Decimal(good['scaled_error'])==1  # Large relative error can be unavoidable.
    bad=error_metrics(math.ulp(0.),tiny,tiny)
    assert not bad['within_error_bound']


def test_zero_sign_is_recorded_without_redefining_absolute_error():
    result=error_metrics(0.,-Fraction(1,2**2000),Fraction(1,2**2000))
    assert result['zero_sign_match'] is False
    assert result['reference_float_hex'].startswith('-')


def test_expected_and_unexpected_nonfinite_are_distinct():
    huge=Fraction(10)**400
    assert error_metrics(math.inf,huge,huge)['status']=='expected_overflow'
    assert error_metrics(math.nan,huge,huge)['status']=='overflow_mismatch'
    assert error_metrics(math.inf,Fraction(1),Fraction(1))['status']=='unexpected_nonfinite'
    assert not error_metrics(math.inf,Fraction(1),Fraction(1))['within_error_bound']


def test_errors_use_exact_reference_instead_of_rounded_float():
    result=error_metrics(float(Fraction(1,10)),Fraction(1,10),Fraction(1))
    assert Decimal(result['absolute_error'])>0
    assert Decimal(result['ulp_error'])==0
    assert result['within_error_bound']
