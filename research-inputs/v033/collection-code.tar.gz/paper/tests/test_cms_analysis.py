"""Analytic four-muon anchors, true event grouping, and deterministic pairing."""
from pathlib import Path
import sys
import numpy as np
import pytest
import awkward as ak

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from cms_analysis import calculate,check,scalar_reference,Z_MASS
from cms_data import FIELDS,save_cache,load_cache


def events():
    m=.1056583755
    q=np.sqrt((Z_MASS/2)**2-m*m);r=np.sqrt(20.**2-m*m)
    nominal=[(q,0.,1),(q,np.pi,-1),(r,.7,1),(r,.7+np.pi,-1)]
    samples=[[],nominal,nominal+[(6.,2.4,1)],[(4.,0.,1)]+nominal[1:]]
    data={'nMuon':ak.Array(np.array([len(x) for x in samples],dtype=np.uint32)),
          'run':ak.Array([1,1,1,1]),'luminosityBlock':ak.Array([7,7,7,7]),
          'event':ak.Array(np.array([2**60+i for i in range(4)],dtype=np.uint64))}
    for field in FIELDS:
        values=[]
        for sample in samples:
            row=[]
            for pt,phi,charge in sample:
                row.append({'pt':pt,'phi':phi,'eta':0.,'mass':m,'charge':charge,
                            'dxy':.001,'dz':.002,'dxyErr':.01,'dzErr':.01,'pfRelIso04_all':.1}[field])
            values.append(row)
        data['Muon_'+field]=ak.Array(values)
    return data


@pytest.mark.parametrize('backend',['lvec','vector','vector_coordinates','components'])
def test_analytic_parent_mass_and_disjoint_source_indices(backend):
    data=events();actual=calculate(data,backend,'rest_frame',True)
    check(actual,calculate(data,'components','rest_frame',True))
    np.testing.assert_allclose(ak.to_numpy(actual['masses']),Z_MASS+40.,rtol=2e-14)
    np.testing.assert_allclose(ak.to_numpy(actual['cosine']),np.cos(.7),rtol=2e-14)
    assert ak.to_list(actual['event_positions'])==[1,2]
    assert ak.to_list(actual['track_indices'])==[[0,1,2,3],[0,1,2,3]]
    oracle=scalar_reference(data)
    assert [r['event'] for r in oracle]==[1,2]
    assert [r['indices'] for r in oracle]==[[0,1,2,3],[0,1,2,3]]
    assert int(actual['counts'][-1])==2


@pytest.mark.parametrize('backend',['lvec','vector','vector_coordinates','components'])
def test_zero_eligible_events_preserve_empty_outputs(backend):
    data={k:v[:1] for k,v in events().items()}
    for scenario in ('pairs','four_muons','rest_frame'):
        actual=calculate(data,backend,scenario,True)
        check(actual,calculate(data,'components',scenario,True))
        assert actual['counts'].tolist()==[1,0,0,0,0,0]


def test_cache_preserves_identifiers_and_real_event_lengths(tmp_path):
    data=events();path=tmp_path/'data.npz';save_cache(path,data);restored=load_cache(path)
    for key in data:assert ak.to_list(data[key])==ak.to_list(restored[key])
    assert ak.to_numpy(restored['event']).dtype==np.dtype('uint64')
    assert ak.to_list(ak.num(restored['Muon_pt']))==[0,4,5,4]


def test_zero_impact_parameter_uncertainty_is_rejected_without_warning():
    data=events()
    data['Muon_dxyErr']=data['Muon_dxyErr']*0
    data['Muon_dzErr']=data['Muon_dzErr']*0
    with np.errstate(all='raise'):
        result=calculate(data,'components','four_muons')
    assert result['counts'][2]==0 and result['counts'][-1]==0
