"""Order balance is required for each case, independent of shuffled positions."""
from pathlib import Path
import sys
from itertools import combinations
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from native_awkward_study import orders_for


@pytest.mark.parametrize('variants',[('baseline','candidate','vector'),('baseline','view','arithmetic','candidate')])
def test_every_fixed_case_has_balanced_positions_and_relative_orders(variants):
    orders=orders_for(variants)
    for variant in variants:
        positions=[sum(order.index(variant)==position for order in orders) for position in range(len(variants))]
        assert len(set(positions))==1
    for a,b in combinations(variants,2):
        assert sum(order.index(a)<order.index(b) for order in orders)==len(orders)//2


def test_four_treatment_orders_balance_preceding_treatment():
    variants=('baseline','view','arithmetic','candidate')
    pairs=[pair for order in orders_for(variants) for pair in zip(order,order[1:])]
    assert len(set(pairs))==12
    assert all(a!=b for a,b in pairs)
