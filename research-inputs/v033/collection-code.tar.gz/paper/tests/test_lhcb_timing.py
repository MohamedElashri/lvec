"""Verify paired process weighting independently of the raw sample counts."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from lhcb_benchmark import summarize
from performance import write_csv,read_csv


def test_paired_ratios_are_not_ratios_of_pooled_medians(tmp_path):
    rows=[]
    for process,(own,other,repeats) in enumerate(((1,2,3),(10,10,1),(100,300,5))):
        for implementation,value in [('lvec',own),('vector',other)]:
            for sample in range(repeats):
                rows.append(dict(stage='resident',polarity='down',size=10,layout='numpy',
                                 scenario='analysis',implementation=implementation,process=process,
                                 sample=sample,wall_seconds=value,cpu_seconds=value,input_candidates=10,
                                 pid_candidates=2,window_candidates=1))
    write_csv(tmp_path/'samples.csv',rows)
    summarize(tmp_path)
    paired=read_csv(tmp_path/'paired-ratios.csv')[0]
    assert float(paired['vector_over_lvec'])==2
    assert float(paired['ratio_mad'])==1
    assert int(paired['paired_processes'])==3
    summaries=read_csv(tmp_path/'summary.csv')
    assert {x['implementation']:float(x['median_seconds']) for x in summaries}=={'lvec':10,'vector':10}
