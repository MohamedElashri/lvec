from collections import Counter
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from complete_study import orders,V3,V5,cases


def test_balanced_design():
    for variants in (V3,V5):
        rows=orders(variants)
        assert len(set(rows))==len(rows)
        for position in range(len(variants)):
            counts=Counter(row[position] for row in rows)
            assert set(counts)==set(variants)
            assert len(set(counts.values()))==1
        predecessors=Counter((a,b) for row in rows for a,b in zip(row,row[1:]))
        assert len(predecessors)==len(variants)*(len(variants)-1)
        assert len(set(predecessors.values()))==1


def test_fixed_case_boundaries():
    assert len(cases('lhcb'))==8
    assert len(cases('cms'))==6
    assert all(c['scenario']=='pairs' for c in cases('cms') if c['bank'].startswith('prefix'))
