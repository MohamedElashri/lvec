"""Independent anchor cases for the paper's reference calculations."""
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
import sys

import numpy as np
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from references import (boost_reference, invariant, lorentz_matrices,
                        matrix_boost, root_reference, two_body_constants, valid_beta)


@pytest.mark.parametrize('row,expected', [
    ((3.,4.,0.,5.),0), ((3.,4.,1.,5.),-1), ((0.,0.,0.,5.),25),
    ((1e200,1.,0.,1e200),-1),
])
def test_exact_known_invariants(row,expected):
    assert invariant(row)[0]==expected


def test_signed_roots_and_range():
    assert root_reference(Fraction(-9))==Decimal(-3)
    assert float(root_reference(Fraction(10)**400))==1e200
    assert float(root_reference(Fraction(1,10**400)))==1e-200


def test_beta_domain_uses_exact_supplied_floats():
    assert valid_beta((.28,.96,0.))
    assert not valid_beta((.6,.8,0.))
    assert not valid_beta((float('nan'),0.,0.))
    with pytest.raises(ValueError):
        boost_reference((0.,0.,0.,1.),(1.,0.,0.))


def test_boost_analytic_rest_case():
    # beta=0.6 is a binary approximation; agreement is judged after rounding.
    actual=np.array([float(x) for x in boost_reference((0.,0.,0.,2.),(.6,0.,0.))])
    np.testing.assert_allclose(actual,[1.5,0.,0.,2.5],rtol=2e-16,atol=0)
    assert tuple(float(x) for x in boost_reference((1.,2.,3.,5.),(0.,0.,0.)))==(1.,2.,3.,5.)


def test_independent_matrix_lorentz_identity_and_inverse():
    beta=np.array([[0.,0.,0.],[.6,0.,0.],[.1,-.2,.3]])
    matrices=lorentz_matrices(beta)
    metric=np.diag([1.,-1.,-1.,-1.])
    np.testing.assert_allclose(np.swapaxes(matrices,1,2)@metric@matrices,
                               np.broadcast_to(metric,matrices.shape),atol=5e-16,rtol=5e-16)
    np.testing.assert_allclose(lorentz_matrices(-beta)@matrices,
                               np.broadcast_to(np.eye(4),matrices.shape),atol=5e-16,rtol=5e-16)
    rows=np.array([[0.,0.,0.,2.],[1.,2.,3.,5.],[-2.,.5,1.,4.]])
    decimal=np.array([[float(x) for x in boost_reference(row,b)] for row,b in zip(rows,beta)])
    np.testing.assert_allclose(matrix_boost(rows,beta),decimal,atol=1e-15,rtol=5e-16)


def test_two_body_phase_space_and_threshold():
    q,ea,eb=two_body_constants()
    assert ea==2.575 and eb==2.425 and ea+eb==5.
    np.testing.assert_allclose([ea*ea-q*q,eb*eb-q*q],[1.,.25],rtol=2e-14,atol=0)
    q,ea,eb=two_body_constants(2.,0.,0.)
    assert (q,ea,eb)==(1.,1.,1.)
    with pytest.raises(ValueError):
        two_body_constants(1.,1.,.5)
