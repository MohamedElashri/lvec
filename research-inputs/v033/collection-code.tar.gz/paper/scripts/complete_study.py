"""Fresh-process, balanced collision-data study. No raw data enter the repository."""
import argparse
import csv
from datetime import datetime,timezone
import gc
import hashlib
import importlib.metadata
import itertools
import os
from pathlib import Path
import platform
import resource
import statistics
import subprocess
import sys
import time

import common

THREADS=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')
V3=('released','candidate','vector')
V5=(*V3,'vector_coordinates','components')


def orders(variants):
    if len(variants)==3:return list(itertools.permutations(variants))
    if len(variants)==5:
        base=(0,1,4,2,3)
        first=[tuple(variants[(x+shift)%5] for x in base) for shift in range(5)]
        return first+[tuple(reversed(row)) for row in first]
    raise ValueError('Use three or five treatments')


def cases(suite):
    if suite=='lhcb':
        return [dict(polarity=p,chunk=n,layout='awkward_native') for p in ('down','up') for n in (25000,100000,500000)]+[
            dict(polarity=p,chunk=100000,layout='numpy') for p in ('down','up')]
    return [dict(bank=f'prefix-{n}',scenario='pairs') for n in (100000,1000000)]+[
        dict(bank=b,scenario=s) for b in ('raw-four-muon','eligible-four-muon') for s in ('four_muons','rest_frame')]


def write(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))


def setup(source):
    sys.path.insert(0,str(source.resolve()))
    import lvec
    assert Path(lvec.__file__).resolve().parent==source.resolve()/'lvec'
    if hasattr(os,'sched_getaffinity'):
        allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,allowed[:2])
    for name,value in {'numpy':'2.5.4','awkward':'2.14.0','vector':'1.9.0','uproot':'5.7.7'}.items():
        assert importlib.metadata.version(name)==value,(name,importlib.metadata.version(name))
    assert platform.python_version()=='3.13.12'


def lhcb_call(args,case):
    import numpy as np
    import lhcb_analysis as analysis
    from lhcb_data import chunks,FILES,count
    from component_vectors import Components
    if args.variant=='components':
        def construct(spatial,energy,implementation,layout):return [Components(*p,e) for p,e in zip(spatial,energy)]
        analysis.construct=construct
    implementation='vector' if args.variant=='vector' else 'lvec'
    def call():
        total=None
        for columns in chunks(args.lhcb_cache/FILES[case['polarity']]['name'],case['chunk']):
            if args.variant=='reader':result={'counts':np.array([count(columns)],dtype=np.int64)}
            else:result=analysis.calculate(columns,implementation,case['layout'],'analysis')
            total=analysis.add_results(total,result)
        return total
    return call


def cms_call(args,case):
    from cms_data import load_cache
    from cms_analysis import calculate
    columns=load_cache(args.cms_cache/f"{case['bank']}.npz")
    backend='lvec' if args.variant in ('released','candidate') else args.variant
    return lambda:calculate(columns,backend,case['scenario'])


def assert_golden(args,case,actual):
    import numpy as np
    if args.suite=='lhcb':
        from lhcb_data import FILES
        if args.variant=='reader':assert int(actual['counts'][0])==FILES[case['polarity']]['entries'];return
        counts={'down':(5135823,14178,10500),'up':(3420295,9717,7339)}
        # Other observables are checked against independent reference before collection.
        np.testing.assert_array_equal(actual['counts'],counts[case['polarity']])
        golden=read(common.PAPER/'results/lhcb/histograms.csv')
        for name,value in actual.items():
            if name=='counts':continue
            rows=[r for r in golden if r['polarity']==case['polarity'] and r['observable']==name]
            assert len(rows)==value.size,(name,len(rows),value.size)
            expected=np.zeros_like(value)
            for r in rows:
                index=int(r['bin_x']) if value.ndim==1 else (int(r['bin_x']),int(r['bin_y']))
                expected[index]=int(r['count'])
            np.testing.assert_array_equal(value,expected,err_msg=name)
    else:
        # All treatments independently checked against the component implementation.
        from cms_analysis import calculate,check
        from cms_data import load_cache
        columns=load_cache(args.cms_cache/f"{case['bank']}.npz")
        check(actual,calculate(columns,'components',case['scenario']))


def worker(args):
    setup(args.source);case=cases(args.suite)[args.case]
    call=lhcb_call(args,case) if args.suite=='lhcb' else cms_call(args,case)
    rows=[]
    if args.mode=='memory':
        actual=call()
        peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if sys.platform!='darwin':peak*=1024
        assert_golden(args,case,actual)
        rows=[dict(suite=args.suite,case=args.case,variant=args.variant,block=args.block,peak_rss_bytes=int(peak),**case)]
    else:
        expected=call();assert_golden(args,case,expected)
        enabled=gc.isenabled();gc.disable()
        try:
            loops=1;large=args.suite=='lhcb' or case['bank']=='raw-four-muon'
            if not large:
                while True:
                    start=time.perf_counter()
                    for _ in range(loops):call()
                    duration=time.perf_counter()-start
                    if duration>=.03:break
                    loops*=max(2,min(8,int(.03/max(duration,1e-12))+1))
            for sample in range(1 if large else 5):
                load=os.getloadavg()[0];cpu=time.process_time();start=time.perf_counter()
                for _ in range(loops):actual=call()
                wall=time.perf_counter()-start;cpu=time.process_time()-cpu
                rows.append(dict(suite=args.suite,case=args.case,variant=args.variant,block=args.block,order=args.order,
                    sample=sample,loops=loops,wall_seconds=wall/loops,cpu_seconds=cpu/loops,load_start=load,load_end=os.getloadavg()[0],**case))
        finally:
            if enabled:gc.enable()
        import numpy as np
        for key in expected:np.testing.assert_array_equal(actual[key],expected[key])
    write(args.output,rows)


def provenance(args):
    args.output.mkdir(parents=True,exist_ok=True)
    cpu=platform.processor()
    if Path('/proc/cpuinfo').exists():
        text=Path('/proc/cpuinfo').read_text();(args.output/'cpuinfo.txt').write_text(text)
        cpu=next((s.split(':',1)[1].strip() for s in text.splitlines() if s.startswith(('model name','CPU part'))),cpu)
    else:
        result=subprocess.run(['sysctl','-n','machdep.cpu.brand_string'],capture_output=True,text=True);cpu=result.stdout.strip()
    info=dict(utc=datetime.now(timezone.utc).isoformat(),platform=platform.platform(),machine=platform.machine(),cpu=cpu,
              python=platform.python_version(),logical_cpus=os.cpu_count(),load=os.getloadavg(),
              affinity=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else 'not supported',
              baseline_library_sha256=common.fingerprint(args.baseline/'lvec'),candidate_library_sha256=common.fingerprint(args.candidate/'lvec'),
              scripts_sha256=common.fingerprint(common.PAPER/'scripts'),arguments=str(args))
    (args.output/'provenance.md').write_text('# Host and source\n\n'+''.join(f'- {k}: `{v}`\n' for k,v in info.items())+
        '\nAll numerical-library thread limits are one; Linux workers use the first two allowed CPUs.\n')
    (args.output/'environment.txt').write_text(''.join(f'{d.metadata["Name"]}=={d.version}\n' for d in sorted(importlib.metadata.distributions(),key=lambda d:d.metadata['Name'].lower())))


def run(args):
    provenance(args);env=os.environ.copy();env.update({key:'1' for key in THREADS});env['PYTHONHASHSEED']='0'
    variants=V3 if args.suite=='lhcb' else V5
    tasks=[]
    for case in range(len(cases(args.suite))):
        if args.mode=='memory':sequence=[(b,0,v) for b in range(3) for v in variants]
        elif args.ancillary:
            assert args.suite=='lhcb';sequence=[(b,i,v) for b in range(3) for i,v in enumerate(('components','reader') if b%2==0 else ('reader','components'))]
        else:sequence=[(b,i,v) for b,row in enumerate(orders(variants)) for i,v in enumerate(row)]
        tasks.extend((case,*s) for s in sequence)
    for index,(case,block,order,variant) in enumerate(tasks):
        destination=args.output/f'workers/{args.mode}-{case}-{block}-{variant}.csv'
        if destination.exists():continue
        source=args.baseline if variant=='released' else args.candidate
        command=[sys.executable,str(Path(__file__).resolve()),'worker','--suite',args.suite,'--mode',args.mode,
                 '--source',str(source),'--case',str(case),'--block',str(block),'--order',str(order),'--variant',variant,
                 '--lhcb-cache',str(args.lhcb_cache),'--cms-cache',str(args.cms_cache),'--output',str(destination)]
        start=time.monotonic();completed=subprocess.run(command,env=env,capture_output=True,text=True)
        if completed.returncode:raise RuntimeError(f'{command}\n{completed.stdout}\n{completed.stderr}')
        print(f'{args.suite} {args.mode} {index+1}/{len(tasks)}: case {case}, {variant}, block {block}, {time.monotonic()-start:.1f} s',flush=True)
    rows=[r for case,block,order,variant in tasks for r in read(args.output/f'workers/{args.mode}-{case}-{block}-{variant}.csv')]
    write(args.output/('memory.csv' if args.mode=='memory' else 'samples.csv'),rows)
    summarize(args.output)


def summarize(output):
    path=output/'samples.csv'
    if not path.exists():return
    rows=read(path);groups={}
    for row in rows:groups.setdefault((row['suite'],row['case'],row['variant']),{}).setdefault(row['block'],[]).append(row)
    centers={};summaries=[]
    for key,blocks in groups.items():
        medians=[statistics.median(float(r['wall_seconds']) for r in values) for values in blocks.values()]
        center=statistics.median(medians);mad=statistics.median(abs(x-center) for x in medians)
        centers[key]={b:statistics.median(float(r['wall_seconds']) for r in values) for b,values in blocks.items()}
        summaries.append(dict(suite=key[0],case=key[1],variant=key[2],processes=len(medians),median_seconds=center,mad_seconds=mad,
                              median_cpu_seconds=statistics.median(statistics.median(float(r['cpu_seconds']) for r in v) for v in blocks.values())))
    write(output/'summary.csv',summaries);ratios=[]
    for key,values in centers.items():
        suite,case,variant=key
        if variant=='candidate':continue
        candidate=centers.get((suite,case,'candidate'))
        if candidate is None:continue
        paired=[v/candidate[b] for b,v in values.items() if b in candidate]
        if not paired:continue
        median=statistics.median(paired)
        ratios.append(dict(suite=suite,case=case,numerator=variant,denominator='candidate',paired_blocks=len(paired),median_ratio=median,
                           mad_ratio=statistics.median(abs(x-median) for x in paired),minimum=min(paired),maximum=max(paired)))
    if ratios:write(output/'ratios.csv',ratios)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=('run','worker','summarize'))
    p.add_argument('--suite',choices=('lhcb','cms'),default='lhcb');p.add_argument('--mode',choices=('time','memory'),default='time')
    p.add_argument('--baseline',type=Path,default=Path('/tmp/lvec-paper-v0.3.1'));p.add_argument('--candidate',type=Path,default=Path('/tmp/lvec-native-awkward'))
    p.add_argument('--source',type=Path);p.add_argument('--lhcb-cache',type=Path,default=Path('/tmp/lvec-lhcb-open-data'))
    p.add_argument('--cms-cache',type=Path,default=Path('/tmp/lvec-cms-open-data'));p.add_argument('--output',type=Path,required=True)
    p.add_argument('--variant',default='candidate');p.add_argument('--case',type=int,default=0);p.add_argument('--block',type=int,default=0);p.add_argument('--order',type=int,default=0)
    p.add_argument('--ancillary',action='store_true');args=p.parse_args()
    if args.command=='worker':worker(args)
    elif args.command=='run':run(args)
    else:summarize(args.output)


if __name__=='__main__':main()
