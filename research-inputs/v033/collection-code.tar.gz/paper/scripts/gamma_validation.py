"""Isolated gamma timings: balanced fresh processes, without persistent caches.

This diagnostic is separate from the frozen collision-workflow measurements.
"""
import argparse
import csv
import hashlib
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

PAPER = Path(__file__).resolve().parents[1]


def worker(source, output):
    sys.path.insert(0, str(source.resolve()))
    import awkward as ak
    import numpy as np
    from lvec import LVec
    import lvec.awkward as lawk
    from study_source import fingerprint
    rng = np.random.default_rng(410)
    xyz = rng.normal(size=(100000, 3))
    energy = np.sqrt(4 + np.sum(xyz * xyz, axis=1))
    fields = dict(zip(('px', 'py', 'pz', 'E'), (*xyz.T, energy)))
    jagged = {name: ak.unflatten(values, 10) for name, values in fields.items()}
    cases = [('scalar', LVec(.3, .4, .5, 2., max_cache_size=0, cache_stats=False), 10000),
             ('numpy', LVec(**fields, max_cache_size=0, cache_stats=False), 300),
             ('owned_awkward', LVec(**jagged, max_cache_size=0, cache_stats=False), 100),
             ('native_awkward', lawk.zip(jagged), 100)]
    rows = []
    for name, value, loops in cases:
        result = value.gamma
        expected = 2 / np.sqrt(4 - .5) if name == 'scalar' else energy / 2
        flat = result if name in ('scalar', 'numpy') else ak.to_numpy(ak.flatten(result))
        np.testing.assert_allclose(flat, expected, rtol=2e-14)
        for _ in range(5):
            value.gamma
        start = time.perf_counter()
        for _ in range(loops):
            value.gamma
        elapsed = time.perf_counter() - start
        rows.append(dict(case=name, loops=loops, seconds_per_call=elapsed/loops,
                         library_sha256=fingerprint(source / 'lvec')))
    with output.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original', type=Path)
    parser.add_argument('--corrected', type=Path)
    parser.add_argument('--worker', type=Path)
    parser.add_argument('--output', type=Path, default=PAPER / 'results/review-round-2/gamma-runtime.csv')
    args = parser.parse_args()
    if args.worker:
        worker(args.worker, args.output)
        return
    assert args.original and args.corrected
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for block in range(6):
        variants = ('original', 'corrected') if block % 2 == 0 else ('corrected', 'original')
        for variant in variants:
            temporary = args.output.with_name('gamma-worker.csv')
            subprocess.run([sys.executable, __file__, '--worker', str(getattr(args, variant)),
                            '--output', str(temporary)], check=True)
            with temporary.open() as stream:
                rows.extend(dict(block=block, variant=variant, **row) for row in csv.DictReader(stream))
            temporary.unlink()
    with args.output.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    report = ['# Isolated gamma runtime check', '',
              f'Host: {platform.platform()}, {platform.machine()}.', '',
              'Six balanced process blocks. Inputs and construction are outside timing. '
              'Each process validates ordinary outputs before timing. Persistent caches are disabled. '
              'Dense and jagged inputs contain 100,000 momenta. Results describe this host only.', '',
              '| Layout | Original (ms) | Corrected (ms) | Corrected / original |',
              '| --- | ---: | ---: | ---: |']
    for case in dict.fromkeys(r['case'] for r in rows):
        times = {v: [float(r['seconds_per_call']) for r in rows if r['case'] == case and r['variant'] == v]
                 for v in ('original', 'corrected')}
        ratios = [b/a for a, b in zip(times['original'], times['corrected'])]
        report.append(f'| {case} | {1000*statistics.median(times["original"]):.5f} | '
                      f'{1000*statistics.median(times["corrected"]):.5f} | {statistics.median(ratios):.3f} |')
    report += ['', 'Source fingerprints are retained per observation. These measurements do not replace '
               'or extend the frozen collision-study timing tables.', '']
    args.output.with_suffix('.md').write_text('\n'.join(report))
    print('\n'.join(report))


if __name__ == '__main__':
    main()
