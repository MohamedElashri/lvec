"""Equivalent public-API analyses of LHCb B->hhh collision candidates.

All inputs are flat candidate rows, not artificially grouped collision events.
ROOT stores MeV/c; this analysis uses GeV and c=1. Cuts are illustrative.
"""
from itertools import product

import awkward as ak
import numpy as np
import vector

from common import ROOT
from lhcb_data import KAON,PION,count,pid,select
from lvec import LVec
from lvec.awkward import zip as native_zip

MASS_EDGES=np.linspace(4.7,6.2,151)
DALITZ_EDGES=np.linspace(0,27,81)
ANGLE_EDGES=np.linspace(-1,1,81)
SCENARIOS=('inclusive','select_late','select_early','dalitz','rest_frame','hypotheses','analysis')
LAYOUTS=('numpy','awkward_owned','awkward_native')


def flat(value):return ak.to_numpy(value) if isinstance(value,ak.Array) else np.asarray(value)


def momenta(columns):
    return [tuple(np.asarray(columns[f'H{i}_P{axis}'],dtype=np.float64)*.001 for axis in 'XYZ') for i in (1,2,3)]


def energies(spatial,masses):
    return [np.sqrt(sum(x*x for x in p)+m*m) for p,m in zip(spatial,masses)]


def construct(spatial,energy,implementation,layout):
    objects=[]
    for p,e in zip(spatial,energy):
        fields=dict(zip(('px','py','pz','E'),(*p,e)))
        if layout!='numpy':fields={name:ak.Array(x) for name,x in fields.items()}
        if implementation=='lvec':
            obj=native_zip(fields) if layout=='awkward_native' else LVec(**fields)
        else:obj=vector.array(fields) if layout=='numpy' else vector.zip(fields)
        objects.append(obj)
    return objects


def signed_norm(spatial,energy):
    squared=energy*energy-sum(x*x for x in spatial)
    return np.copysign(np.sqrt(abs(squared)),squared)


def histogram(values,edges):return np.histogram(values,bins=edges)[0]


def result_hist(mass,mask,columns):
    mass=mass[mask]
    charges=sum(columns[f'H{i}_Charge'] for i in (1,2,3))[mask]
    return {'mass':histogram(mass,MASS_EDGES),
            'positive':histogram(mass[charges==1],MASS_EDGES),
            'negative':histogram(mass[charges==-1],MASS_EDGES),
            'counts':np.array([count(columns),int(mask.sum()),int(np.count_nonzero((mass>5.15)&(mass<5.45)))])}


def calculate(columns,implementation,layout,scenario,return_details=False):
    if scenario not in SCENARIOS:raise ValueError(scenario)
    original=count(columns)
    if scenario in ('select_early','dalitz','rest_frame','hypotheses','analysis'):
        columns=select(columns,pid(columns))
    spatial=momenta(columns)
    es=energies(spatial,(KAON,KAON,KAON))
    daughters=construct(spatial,es,implementation,layout)
    parent=daughters[0]+daughters[1]+daughters[2]
    mass=flat(parent.mass)
    mask=pid(columns) if scenario=='select_late' else np.ones(count(columns),bool)
    result=result_hist(mass,mask,columns)
    result['counts'][0]=original
    if scenario in ('dalitz','analysis'):
        charges=[columns[f'H{i}_Charge'] for i in (1,2,3)]
        q=sum(charges)
        valid=np.abs(q)==1
        pairs=[flat((daughters[i]+daughters[j]).mass2) for i,j in ((0,1),(0,2),(1,2))]
        opposite=[charges[i]*charges[j]<0 for i,j in ((0,1),(0,2),(1,2))]
        valid &= sum(x.astype(int) for x in opposite)==2
        # Sort the two opposite-sign pair invariants, not the same-sign pair.
        os_pairs=np.sort(np.stack([np.where(m,s,np.inf) for m,s in zip(opposite,pairs)]),axis=0)[:2]
        window=valid&(mass>5.15)&(mass<5.45)
        for label,sign in [('positive',1),('negative',-1)]:
            chosen=window&(q==sign)
            result['dalitz_'+label]=np.histogram2d(os_pairs[0,chosen],os_pairs[1,chosen],bins=(DALITZ_EDGES,DALITZ_EDGES))[0].astype(np.int64)
        if return_details:result.update(masses=mass,low=os_pairs[0],high=os_pairs[1],window=window)
    if scenario in ('rest_frame','analysis'):
        chosen=(mass>5.15)&(mass<5.45)
        p=parent[chosen];a=daughters[0][chosen];b=daughters[1][chosen]
        a=a.boostCM_of_p4(p);b=b.boostCM_of_p4(p)
        va=[flat(getattr(a,name)) for name in ('px','py','pz')]
        vb=[flat(getattr(b,name)) for name in ('px','py','pz')]
        cosine=sum(x*y for x,y in zip(va,vb))/(np.sqrt(sum(x*x for x in va))*np.sqrt(sum(x*x for x in vb)))
        result['opening']=histogram(np.clip(cosine,-1,1),ANGLE_EDGES)
        result['energy']=histogram(flat(a.E),np.linspace(0,5.5,111))
        if return_details:result.update(cosine=cosine,rest_energy=flat(a.E))
    if scenario=='hypotheses':
        # Retain the physical KKK spectrum while scanning all eight K/pi assignments.
        for hypothesis in product((PION,KAON),repeat=3):
            tracks=construct(spatial,energies(spatial,hypothesis),implementation,layout)
            label=''.join('K' if m==KAON else 'pi' for m in hypothesis)
            result['hypothesis_'+label]=histogram(flat((tracks[0]+tracks[1]+tracks[2]).mass),np.linspace(0,7,141))
    if return_details and 'masses' not in result:result['masses']=mass
    return result


def reference(columns,scenario,return_details=False):
    """Independent component arithmetic; no vector classes or LVec helpers."""
    original=count(columns)
    if scenario in ('select_early','dalitz','rest_frame','hypotheses','analysis'):columns=select(columns,pid(columns))
    spatial=momenta(columns);es=energies(spatial,(KAON,)*3)
    total=tuple(sum(p[k] for p in spatial) for k in range(3));energy=sum(es)
    mass=signed_norm(total,energy)
    mask=pid(columns) if scenario=='select_late' else np.ones(count(columns),bool)
    result=result_hist(mass,mask,columns);result['counts'][0]=original
    if scenario in ('dalitz','analysis'):
        q=[columns[f'H{i}_Charge'] for i in (1,2,3)];charge=sum(q)
        pair_values=[(es[i]+es[j])**2-sum((spatial[i][k]+spatial[j][k])**2 for k in range(3)) for i,j in ((0,1),(0,2),(1,2))]
        low=np.full(count(columns),np.nan);high=low.copy()
        # Determine the odd-charge track, then explicitly form its two pairings.
        for odd in range(3):
            where=(q[odd]==-charge)&(np.abs(charge)==1)
            indices=[k for k,(i,j) in enumerate(((0,1),(0,2),(1,2))) if odd in (i,j)]
            a,b=(pair_values[k] for k in indices)
            low[where]=np.minimum(a,b)[where];high[where]=np.maximum(a,b)[where]
        window=np.isfinite(low)&(mass>5.15)&(mass<5.45)
        for label,sign in [('positive',1),('negative',-1)]:
            chosen=window&(charge==sign)
            result['dalitz_'+label]=np.histogram2d(low[chosen],high[chosen],bins=(DALITZ_EDGES,DALITZ_EDGES))[0].astype(np.int64)
        if return_details:result.update(masses=mass,low=low,high=high,window=window)
    if scenario in ('rest_frame','analysis'):
        chosen=(mass>5.15)&(mass<5.45)
        m=mass[chosen];e=energy[chosen];p=[x[chosen] for x in total]
        # In the parent rest frame E_i*=p_i.P/M. Spatial scalar products follow
        # p1*.p2*=E1*E2* - (p1.p2), independent of an explicit boost implementation.
        a=(es[0][chosen]*e-sum(spatial[0][k][chosen]*p[k] for k in range(3)))/m
        b=(es[1][chosen]*e-sum(spatial[1][k][chosen]*p[k] for k in range(3)))/m
        dot=es[0][chosen]*es[1][chosen]-sum(spatial[0][k][chosen]*spatial[1][k][chosen] for k in range(3))
        cosine=(a*b-dot)/(np.sqrt(np.maximum(0,a*a-KAON**2))*np.sqrt(np.maximum(0,b*b-KAON**2)))
        result['opening']=histogram(np.clip(cosine,-1,1),ANGLE_EDGES)
        result['energy']=histogram(a,np.linspace(0,5.5,111))
        if return_details:result.update(cosine=cosine,rest_energy=a)
    if scenario=='hypotheses':
        for hypothesis in product((PION,KAON),repeat=3):
            e=sum(energies(spatial,hypothesis));label=''.join('K' if m==KAON else 'pi' for m in hypothesis)
            result['hypothesis_'+label]=histogram(signed_norm(total,e),np.linspace(0,7,141))
    if return_details and 'masses' not in result:result['masses']=mass
    return result


def check(actual,expected):
    assert set(actual)==set(expected),(set(actual),set(expected))
    for name in actual:
        if name in ('masses','low','high','cosine','rest_energy'):
            np.testing.assert_allclose(actual[name],expected[name],rtol=2e-8,atol=2e-9,equal_nan=True)
        else:np.testing.assert_array_equal(actual[name],expected[name],err_msg=name)


def add_results(total,result):
    if total is None:return {k:v.copy() for k,v in result.items()}
    for key in total:total[key]+=result[key]
    return total
