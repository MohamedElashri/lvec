"""Resolve the evaluated library from its verified source bundle or an explicit path."""
import hashlib
import os
from pathlib import Path, PurePosixPath
import sys
import tarfile
import tomllib

PAPER = Path(__file__).resolve().parents[1]


def fingerprint(directory):
    digest = hashlib.sha256()
    for path in sorted(directory.glob('*.py')):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def resolve_source(source=None, *, role='evaluated', metadata_file=None):
    manifest = Path(metadata_file) if metadata_file else PAPER / 'study-source.toml'
    metadata = tomllib.loads(manifest.read_text())[role]
    explicit = source or os.environ.get(f'LVEC_PAPER_{role.upper()}_SOURCE') or os.environ.get('LVEC_PAPER_SOURCE')
    if explicit:
        selected = Path(explicit).resolve()
    else:
        bundle = PAPER / metadata.get('bundle', 'results/complete/complete-study-input.tar.gz')
        if hashlib.sha256(bundle.read_bytes()).hexdigest() != metadata['bundle_sha256']:
            raise RuntimeError('Frozen source bundle checksum mismatch')
        prefix = metadata.get('prefix', 'candidate')
        cache = PAPER / f'tmp/{role}-source' / metadata['library_sha256'][:12]
        selected = cache / prefix
        if not selected.exists():
            cache.mkdir(parents=True, exist_ok=True)
            with tarfile.open(bundle) as archive:
                members = [m for m in archive if PurePosixPath(m.name).parts[0] == prefix]
                archive.extractall(cache, members=members, filter='data')
    if fingerprint(selected / 'lvec') != metadata['library_sha256']:
        raise RuntimeError(f'Evaluated library fingerprint mismatch: {selected}')
    return selected.resolve()


def activate_source(source=None, *, role='evaluated', metadata_file=None):
    selected = resolve_source(source, role=role, metadata_file=metadata_file)
    sys.path.insert(0, str(selected))
    return selected


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=('evaluated', 'manual'), default='evaluated')
    parser.add_argument('--source', type=Path)
    parser.add_argument('--metadata', type=Path)
    args = parser.parse_args()
    print(resolve_source(args.source, role=args.role, metadata_file=args.metadata))
