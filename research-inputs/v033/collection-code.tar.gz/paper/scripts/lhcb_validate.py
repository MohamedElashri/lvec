"""Validate all collision candidates and save physical analysis products."""
import argparse
import csv
from decimal import localcontext
from fractions import Fraction
from pathlib import Path

from common import PAPER,environment,write_provenance
from lhcb_data import CACHE,FILES,READ_BRANCHES,chunks,count,pid,select
from lhcb_analysis import (SCENARIOS,LAYOUTS,calculate,reference,check,add_results,
                           momenta,energies,KAON,MASS_EDGES,DALITZ_EDGES,ANGLE_EDGES)
from references import invariant,root_reference,as_decimal,rational
import numpy as np


def audit(columns,polarity,offset):
    """Exact norm of the actual rounded parent components, without vector helpers."""
    spatial=momenta(columns);es=energies(spatial,(KAON,)*3)
    components=[sum(p[k] for p in spatial) for k in range(3)]+[sum(es)]
    from lvec import LVec
    import vector
    objects={'lvec':LVec(*components),'vector':vector.array(dict(zip(('px','py','pz','E'),components)))}
    indices=np.linspace(0,count(columns)-1,8,dtype=int)
    rows=[]
    for index in indices:
        point=tuple(float(x[index]) for x in components)
        exact,scale=invariant(point);root=root_reference(exact)
        for name,obj in objects.items():
            value=float(obj.mass[index])
            residual=abs(rational(value)*abs(rational(value))-exact)
            scaled=float(residual/scale)
            assert scaled<=64*np.finfo(float).eps,(polarity,offset,index,name,scaled)
            with localcontext() as context:
                context.prec=800
                error=float(abs(as_decimal(value)-root))
            rows.append(dict(polarity=polarity,entry=offset+index,implementation=name,
                             **dict(zip(('px_hex','py_hex','pz_hex','E_hex'),(x.hex() for x in point))),
                             mass=value,reference_mass=float(root),absolute_mass_error_GeV=error,
                             squared_residual_over_scale=scaled))
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache',type=Path,default=CACHE)
    parser.add_argument('--output',type=Path,default=PAPER/'results/lhcb')
    parser.add_argument('--step',type=int,default=100000)
    parser.add_argument('--limit',type=int)
    args=parser.parse_args();info=environment()
    write_provenance(args.output,info,vars(args))
    products={};cutflow=[];audits=[];checks=0
    for polarity,metadata in FILES.items():
        total=None;offset=0;selected_parts=[];max_mass_error=0.;max_angle_error=0.
        for chunk in chunks(args.cache/metadata['name'],args.step):
            if args.limit is not None:
                if offset>=args.limit:break
                chunk={k:v[:args.limit-offset] for k,v in chunk.items()}
            for name in READ_BRANCHES:assert np.all(np.isfinite(chunk[name])),name
            for i in (1,2,3):assert set(np.unique(chunk[f'H{i}_Charge']))<={-1,1}
            for scenario in SCENARIOS:
                expected=reference(chunk,scenario)
                for layout in LAYOUTS:
                    for implementation in ('lvec','vector'):
                        result=calculate(chunk,implementation,layout,scenario)
                        check(result,expected);checks+=1
            # Numerical details and a Dalitz identity are checked independently of bins.
            expected=reference(chunk,'analysis',True)
            actual=calculate(chunk,'lvec','numpy','analysis',True)
            check(actual,expected)
            if len(actual['masses']):max_mass_error=max(max_mass_error,float(np.max(abs(actual['masses']-expected['masses']))))
            if len(actual['cosine']):max_angle_error=max(max_angle_error,float(np.max(abs(actual['cosine']-expected['cosine']))))
            plain={k:v for k,v in actual.items() if k not in ('masses','low','high','window','cosine','rest_energy')}
            total=add_results(total,plain)
            selected_parts.append(select(chunk,pid(chunk)))
            audits.extend(audit(chunk,polarity,offset))
            offset+=count(chunk)
            print(f'Validated {polarity}: {offset:,} candidates',flush=True)
        if args.limit is None:assert offset==metadata['entries']
        bank={name:np.concatenate([p[name] for p in selected_parts]) for name in READ_BRANCHES}
        # Reusable derived inputs live beside the authenticated ROOT cache, not in Git.
        if args.limit is None:np.savez(args.cache/f'pid-selected-{polarity}.npz',**bank)
        products[polarity]=total
        cutflow.append(dict(polarity=polarity,candidates=offset,pid_selected=int(total['counts'][1]),
                            parent_window=int(total['counts'][2]),
                            positive_dalitz=int(total['dalitz_positive'].sum()),negative_dalitz=int(total['dalitz_negative'].sum()),
                            max_parent_mass_difference_GeV=max_mass_error,max_opening_cosine_difference=max_angle_error))
    for filename,rows in [('cutflow.csv',cutflow),('exact-audits.csv',audits)]:
        with (args.output/filename).open('w',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    histogram_rows=[]
    for polarity,result in products.items():
        for name,values in result.items():
            if name=='counts':continue
            for index,value in np.ndenumerate(values):
                histogram_rows.append(dict(polarity=polarity,observable=name,bin_x=index[0],bin_y=index[1] if len(index)>1 else -1,count=int(value)))
    with (args.output/'histograms.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(histogram_rows[0]));writer.writeheader();writer.writerows(histogram_rows)
    lines=['# LHCb collision-data validation','',f'Completed {checks} implementation/layout/scenario/chunk comparisons with exact histogram agreement.',
           f'Collected {len(audits)} independent rational/Decimal spot-audit observations.','',
           '| Polarity | Candidates | PID selected | Parent window | Positive Dalitz | Negative Dalitz |',
           '| --- | ---: | ---: | ---: | ---: | ---: |']
    for r in cutflow:lines.append(f"| {r['polarity']} | {r['candidates']} | {r['pid_selected']} | {r['parent_window']} | {r['positive_dalitz']} | {r['negative_dalitz']} |")
    lines+=['','These are candidate counts under fixed illustrative cuts, not fitted signal yields or a CP-asymmetry measurement.','']
    (args.output/'validation.md').write_text('\n'.join(lines))
    print('\n'.join(lines))


if __name__=='__main__':main()
