"""Read-only third-referee diagnostics, separate from passing regressions.

Exit status records successful execution, not API conformance. Counterexamples
are retained without changing production code or previous observations.
"""
import argparse
from collections import Counter, defaultdict
import csv
from fractions import Fraction
import math
import os
from pathlib import Path
import struct

from study_source import PAPER, activate_source, fingerprint, resolve_source


def write(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def certify_root(squared, value):
    """Certify nearest-even rounding by exact rational midpoint comparisons.

    Does not import the library's integer-root or rounding implementation.
    """
    if squared == 0:
        return value == 0 and math.copysign(1., value) > 0
    if math.copysign(1., value) != (1. if squared > 0 else -1.):
        return False
    magnitude = abs(value)
    exact = abs(squared)
    largest = float.fromhex('0x1.fffffffffffffp+1023')
    overflow_midpoint = (Fraction(largest) + Fraction(1 << 1024)) / 2
    if math.isinf(magnitude):
        return exact >= overflow_midpoint**2
    if math.isnan(magnitude):
        return False
    import numpy as np
    lower = Fraction(float(np.nextafter(magnitude, 0.)))
    upper = Fraction(1 << 1024) if magnitude == largest else Fraction(float(np.nextafter(magnitude, math.inf)))
    middle = Fraction(magnitude)
    lo, hi = ((lower + middle)/2)**2, ((middle + upper)/2)**2
    even = not (struct.unpack('>Q', struct.pack('>d', magnitude))[0] & 1)
    return lo <= exact <= hi if even else lo < exact < hi


def check_orders(output):
    checked = 0
    for host in ('m1-macos', 'x86_64-linux', 'aarch64-linux'):
        for suite, count, blocks in [('lhcb', 3, 6), ('cms', 5, 10)]:
            with (PAPER / f'results/complete/{host}/{suite}-time/samples.csv').open() as stream:
                observations = list(csv.DictReader(stream))
            groups = defaultdict(dict)
            for row in observations:
                key = (row['case'], int(row['block']))
                position = int(row['order'])
                if row['variant'] in groups[key]:
                    assert groups[key][row['variant']] == position
                groups[key][row['variant']] = position
            for case in {key[0] for key in groups}:
                selected = [values for (c, _), values in groups.items() if c == case]
                assert len(selected) == blocks and all(len(v) == count for v in selected)
                positions = Counter((v, pos) for row in selected for v, pos in row.items())
                sequences = [sorted(row, key=row.get) for row in selected]
                predecessors = Counter(pair for order in sequences for pair in zip(order, order[1:]))
                assert set(positions.values()) == {2} and len(positions) == count*count
                assert set(predecessors.values()) == {2} and len(predecessors) == count*(count-1)
                checked += 1
    text = (f'{checked} retained host/workload configurations have balanced treatment positions and immediate predecessors.\n'
            'Every treatment occupies every position twice; every ordered predecessor pair occurs twice.\n'
            'Repeated within-process samples are collapsed before checking the design.\n')
    (output / 'order-check.txt').write_text(text)
    return checked


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=('manual', 'evaluated'), default='manual')
    parser.add_argument('--output', type=Path, default=PAPER / 'results/review-round-3')
    args = parser.parse_args()
    historical = PAPER / 'results/review-round-3/study-source.toml'
    source = activate_source(role=args.role, metadata_file=historical)
    import awkward as ak
    import numpy as np
    import lvec
    import lvec.awkward as lawk
    from references import invariant, root_reference, as_decimal
    from accuracy import invariant_inputs, error_metrics
    from decimal import localcontext

    args.output.mkdir(parents=True, exist_ok=True)
    lines = [f'Third-review probes: {args.role} source',
             f'Library SHA256: {fingerprint(source / "lvec")}',
             'Production source and previous results are not modified.', '']

    def first(value):
        if isinstance(value, ak.Array):
            return ak.to_numpy(ak.flatten(value, axis=None))[0].item()
        return np.asarray(value).flat[0].item()

    def inputs(row):
        nested = dict(zip(('px', 'py', 'pz', 'E'),
                          (ak.Array([[x]*17, [], None]) for x in row)))
        return [('scalar', lvec.LVec(*row)),
                ('NumPy-17', lvec.LVec(*(np.full(17, x) for x in row))),
                ('owned Awkward', lvec.LVec(*(ak.Array([[x]*17, [], None]) for x in row))),
                ('native Awkward', lawk.zip(nested))]

    validation = []
    for label, row in [('timelike', (.58, .8146164741766521, 0., 1.)),
                       ('spacelike', (.6, .8, 0., 1.))]:
        squared = invariant(row)[0]
        p2 = sum(Fraction(x)**2 for x in row[:3])
        scale = max(Fraction(row[3])**2, p2)
        for layout, value in inputs(row):
            for tolerance in (0., 1e-18, 1e-16, 1e-12):
                expected = row[3] >= 0 and squared >= -Fraction(tolerance)*scale
                actual = first(value.is_physical(rtol=tolerance, atol=0.))
                try:
                    value.validate_particle(rtol=tolerance, atol=0.)
                    raised = False
                except lvec.exceptions.InputError:
                    raised = True
                validation.append(dict(case=label, layout=layout,
                                       input_hex=' '.join(x.hex() for x in row),
                                       exact_mass2=float(squared), rtol=tolerance,
                                       expected=expected, actual=actual,
                                       validate_particle_raised=raised, matches=actual == expected))
    write(args.output / f'particle-validation-{args.role}.csv', validation)
    wrong = sum(not r['matches'] for r in validation)
    lines += [f'Particle-validation equation mismatches: {wrong}/{len(validation)}.',
              'Timelike supplied components (.58, .8146164741766521, 0., 1.):']
    for r in validation:
        if r['case'] == 'timelike' and r['layout'] == 'scalar':
            lines.append(f'  rtol={r["rtol"]}: expected={r["expected"]}, actual={r["actual"]}, '
                         f'validate_particle raised InputError={r["validate_particle_raised"]}')

    factories = []
    for x, y in [(1., 1e-10), (.6, .8)]:
        radicand = Fraction(x)**2 + Fraction(y)**2 - 1
        expected = float(root_reference(radicand))
        assert radicand > 0 and certify_root(radicand, expected)
        fields = dict(x=x, y=y, z=0., mass=-1.)
        columns = {k: np.full(17, v) for k, v in fields.items()}
        nested = {k: ak.Array([[v]*17, [], None]) for k, v in fields.items()}
        values = [('scalar factory', lvec.obj(**fields)),
                  ('named factory', lvec.LVec.from_xyztau(x, y, 0., -1.)),
                  ('NumPy factory', lvec.array(columns)),
                  ('owned Awkward factory', lvec.zip(nested)),
                  ('native Awkward factory', lawk.zip(nested))]
        for layout, value in values:
            actual = first(value.E)
            factories.append(dict(layout=layout, x_hex=x.hex(), y_hex=y.hex(), mass=-1.,
                                  reference_energy=expected, actual_energy=actual,
                                  matches=math.isclose(actual, expected, rel_tol=3e-15)))
    write(args.output / f'signed-factories-{args.role}.csv', factories)
    lines += ['', f'Signed-mass factory energy mismatches: {sum(not r["matches"] for r in factories)}/{len(factories)}.']
    for row in factories:
        if row['layout'] == 'scalar factory':
            lines.append(f'  x={float.fromhex(row["x_hex"])}, y={float.fromhex(row["y_hex"])}, z=0, '
                         f'mass=-1: expected E={row["reference_energy"]}, actual E={row["actual_energy"]}')

    gamma = []
    for row in [(1., 1e-10, 0., 1.), (.6, .8, 0., 1.), (.28, .96, 0., 1.)]:
        squared = invariant(row)[0]
        expected = math.nan if squared < 0 else row[3] / float(root_reference(squared))
        for layout, value in inputs(row):
            actual = first(value.gamma)
            match = math.isnan(actual) if math.isnan(expected) else math.isclose(actual, expected, rel_tol=3e-15)
            gamma.append(dict(layout=layout, input_hex=' '.join(x.hex() for x in row),
                              expected=expected, actual=actual, matches=match))
    write(args.output / f'gamma-recheck-{args.role}.csv', gamma)
    lines += ['', f'Previous gamma counterexample mismatches: {sum(not r["matches"] for r in gamma)}/{len(gamma)}.']

    fixtures = invariant_inputs(20261101, 256)
    differences = failures = rounding_failures = 0
    bulk = lvec.LVec(*(np.array([row[k] for _, row in fixtures]) for k in range(4)))
    bulk_results = {'mass2': bulk.mass2, 'mass': bulk.mass}
    for index, (family, row) in enumerate(fixtures):
        small = lvec.LVec(*(np.array([x]) for x in row))
        exact, scale = invariant(row)
        with localcontext() as context:
            context.prec = 800
            root = root_reference(exact)
            mass_scale = as_decimal(scale).sqrt()
        rounding_failures += not certify_root(exact, float(root))
        for observable, reference, denominator in [('mass2', exact, scale), ('mass', root, mass_scale)]:
            a, b = float(getattr(small, observable)[0]), float(bulk_results[observable][index])
            differences += a.hex() != b.hex()
            failures += not error_metrics(b, reference, denominator)['within_error_bound']
    lines += ['', f'Fixture layout check: {len(fixtures)} original invariant fixtures in one-element and mixed bulk arrays.',
              f'  Output differences: {differences}/662. Bulk acceptance-criterion failures: {failures}/662.',
              f'  Exact rational midpoint certifications of reference roots: {len(fixtures)-rounding_failures}/{len(fixtures)}.']

    with (PAPER / 'results/accuracy/errors.csv').open() as stream:
        errors = list(csv.DictReader(stream))
    lines += ['', 'Retained ordinary-fixture maximum reference-ULP residuals:']
    for study in ('invariant', 'boost'):
        maxima = {name: max(float(r['ulp_error']) for r in errors if r['study'] == study
                            and r['family'] == 'ordinary' and r['implementation'] == name)
                  for name in ('lvec', 'vector', 'numpy')}
        lines.append(f'  {study}: {maxima}')
    lines += ['', 'Shared LVEC_PAPER_SOURCE override across the two build roles:']
    paths = {role: resolve_source(role=role, metadata_file=historical) for role in ('evaluated', 'manual')}
    saved_override = os.environ.get('LVEC_PAPER_SOURCE')
    try:
        for selected, path in paths.items():
            os.environ['LVEC_PAPER_SOURCE'] = str(path)
            accepted = []
            for role in ('evaluated', 'manual'):
                try:
                    resolve_source(role=role, metadata_file=historical)
                    accepted.append(True)
                except RuntimeError as error:
                    assert 'fingerprint mismatch' in str(error)
                    accepted.append(False)
            lines.append(f'  {selected} override: evaluated role={accepted[0]}, manual role={accepted[1]}. '
                         f'Both build roles accept it={all(accepted)}')
    finally:
        if saved_override is None:
            os.environ.pop('LVEC_PAPER_SOURCE', None)
        else:
            os.environ['LVEC_PAPER_SOURCE'] = saved_override
    lines += ['', f'Retained ordering audit: all {check_orders(args.output)} host/workload configurations pass.']
    lines += ['', 'This diagnostic reports counterexamples. A successful command exit is not a conformance pass.', '']
    report = '\n'.join(lines)
    (args.output / f'probes-{args.role}.txt').write_text(report)
    print(report)


if __name__ == '__main__':
    main()
