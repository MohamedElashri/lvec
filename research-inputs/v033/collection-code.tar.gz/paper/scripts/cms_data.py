"""Verified CMS reduced NanoAOD input and deterministic jagged caches."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from pathlib import Path
import urllib.request
import zlib

import awkward as ak
import numpy as np
import uproot

PAPER=Path(__file__).resolve().parents[1]
CACHE=Path('/tmp/lvec-cms-open-data')
NAME='Run2012B_DoubleMuParked.root'
URL='https://eospublic.cern.ch/eos/opendata/cms/derived-data/AOD2NanoAODOutreachTool/ForHiggsTo4Leptons/'+NAME
SIZE=3179316378
ENTRIES=26084708
ADLER32='daa50fff'
SHA256='5609eadf65920ed39d1c8e2932a29e3353636c35a47023110e3fae31de0b9d93'
FIELDS=('pt','eta','phi','mass','charge','dxy','dxyErr','dz','dzErr','pfRelIso04_all')
BRANCHES=['run','luminosityBlock','event','nMuon']+['Muon_'+name for name in FIELDS]


def verify(path):
    assert path.stat().st_size==SIZE
    h=hashlib.sha256();adler=1
    with path.open('rb') as stream:
        while block:=stream.read(4*1024*1024):h.update(block);adler=zlib.adler32(block,adler)
    assert f'{adler:08x}'==ADLER32
    assert h.hexdigest()==SHA256
    with uproot.open(path) as file:
        assert file['Events'].num_entries==ENTRIES
        assert set(BRANCHES)<=set(file['Events'].keys())
    return h.hexdigest()


def chunks(path,step=100000,stop=None):
    with ThreadPoolExecutor(1) as decomp,ThreadPoolExecutor(1) as interp:
        with uproot.open(path,array_cache=None,object_cache=None,
                         decompression_executor=decomp,interpretation_executor=interp) as file:
            yield from file['Events'].iterate(BRANCHES,step_size=step,entry_stop=stop,library='ak',how=dict)


def read(path,stop):
    return {key:ak.concatenate([c[key] for c in parts]) for key in BRANCHES} if (parts:=list(chunks(path,stop,stop))) else {}


def save_cache(path,columns):
    values={key:ak.to_numpy(value) for key,value in columns.items() if not key.startswith('Muon_')}
    values.update({key:ak.to_numpy(ak.flatten(value)) for key,value in columns.items() if key.startswith('Muon_')})
    np.savez(path,**values)


def load_cache(path):
    with np.load(path,allow_pickle=False) as bank:
        n=bank['nMuon']
        return {key:ak.unflatten(bank[key],n) if key.startswith('Muon_') else ak.Array(bank[key]) for key in bank.files}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,default=CACHE)
    p.add_argument('--download',action='store_true');args=p.parse_args();args.cache.mkdir(parents=True,exist_ok=True)
    path=args.cache/NAME;temporary=path.with_suffix('.root.part')
    if not path.exists():
        if not temporary.exists() and args.download:
            with urllib.request.urlopen(URL,timeout=60) as response,temporary.open('wb') as stream:
                while block:=response.read(4*1024*1024):stream.write(block)
        digest=verify(temporary);temporary.rename(path)
    else:digest=verify(path)
    (PAPER/'cms-data.toml').write_text('record = "https://opendata.cern.ch/record/12365"\n'+
        'doi = "10.7483/OPENDATA.CMS.04XV.ESBR"\nlicense = "CC0-1.0"\n'+
        'analysis_commit = "ffbe653cd2774f9b30acfff77de0882fcf3d7feb"\n'+
        'metadata_commit = "836442f1b68c255295d6c6baf9f5b2bb90c8dd59"\n'+
        f'filename = "{NAME}"\nurl = "{URL}"\nbytes = {SIZE}\nevents = {ENTRIES}\n'+
        f'adler32 = "{ADLER32}"\nsha256 = "{digest}"\n'+
        'checksum_provenance = "Adler32 and size published by CERN; SHA256 computed from verified file"\n'+
        'momentum_unit = "GeV, c=1"\nstored_coordinate_type = "float32"\nanalysis_type = "float64"\n')
    for n in (100000,1000000):
        target=args.cache/f'prefix-{n}.npz'
        if not target.exists():save_cache(target,read(path,n))
    print('Verified',ENTRIES,'CMS collision events; SHA256',digest,flush=True)


if __name__=='__main__':main()
