"""Authenticated LHCb collision inputs, local ROOT reading, and unit conversion."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from pathlib import Path
import urllib.request
import zlib

import numpy as np
import uproot

PAPER=Path(__file__).resolve().parents[1]
CACHE=Path('/tmp/lvec-lhcb-open-data')
NOTEBOOK_COMMIT='80d64a3796e593fc8f9b257e85f32ae2e54f131f'
FILES={
 'down':dict(name='B2HHH_MagnetDown.root',size=666484974,entries=5135823,
             sha256='b98651b24f825979053544c37010cf7ef9ce5c56ee62357c7e4ae2c392068379',adler32='b25f68bf'),
 'up':dict(name='B2HHH_MagnetUp.root',size=444723234,entries=3420295,
           sha256='c42ad9e47931e1404bf94ad82ea22a0acd10bc9cfbb58e77a6b0fff08ead7859',adler32='0568274c')}
BASE='https://eospublic.cern.ch/eos/opendata/lhcb/AntimatterMatters2017/data/'
BRANCHES=['B_FlightDistance','B_VertexChi2']+[f'H{i}_{name}' for i in (1,2,3)
          for name in ('PX','PY','PZ','ProbK','ProbPi','Charge','IPChi2','isMuon')]
READ_BRANCHES=[name for name in BRANCHES if name.startswith('H') and not name.endswith('_IPChi2')]
KAON=.493677
PION=.13957039


def verify(path,metadata):
    if path.stat().st_size!=metadata['size']:raise ValueError(f'Wrong file size: {path}')
    sha=hashlib.sha256();adler=1
    with path.open('rb') as stream:
        while block:=stream.read(4*1024*1024):sha.update(block);adler=zlib.adler32(block,adler)
    if sha.hexdigest()!=metadata['sha256'] or f'{adler:08x}'!=metadata['adler32']:
        raise ValueError(f'Published checksums do not match: {path}')
    with uproot.open(path) as file:
        tree=file['DecayTree']
        assert tree.num_entries==metadata['entries']
        assert set(BRANCHES)==set(tree.keys())
    return sha.hexdigest()


def read(path,stop=None):
    # Explicit, equal reader parallelism and no retained Uproot array cache.
    with ThreadPoolExecutor(1) as decompression,ThreadPoolExecutor(1) as interpretation:
        with uproot.open(path,array_cache=None,object_cache=None,
                         decompression_executor=decompression,interpretation_executor=interpretation) as file:
            return file['DecayTree'].arrays(READ_BRANCHES,entry_stop=stop,library='np')


def chunks(path,step):
    with ThreadPoolExecutor(1) as decompression,ThreadPoolExecutor(1) as interpretation:
        with uproot.open(path,array_cache=None,object_cache=None,
                         decompression_executor=decompression,interpretation_executor=interpretation) as file:
            yield from file['DecayTree'].iterate(READ_BRANCHES,step_size=step,library='np')


def count(columns):return len(columns['H1_PX'])


def pid(columns,threshold=.5):
    selected=np.ones(count(columns),dtype=bool)
    for i in (1,2,3):
        selected &= (columns[f'H{i}_ProbK']>threshold)&(columns[f'H{i}_ProbPi']<.5)&(columns[f'H{i}_isMuon']==0)
    return selected


def select(columns,mask):return {name:values[mask] for name,values in columns.items()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache',type=Path,default=CACHE)
    parser.add_argument('--download',action='store_true')
    args=parser.parse_args();args.cache.mkdir(parents=True,exist_ok=True)
    lines=['# CERN record 4900; both files are collision data, not phase-space simulation.',
           'record = "https://opendata.cern.ch/record/4900"',
           'doi = "10.7483/OPENDATA.LHCB.AOF7.JH09"',
           'notebook_doi = "10.7483/OPENDATA.LHCB.K6BL.RF22"',
           f'notebook_commit = "{NOTEBOOK_COMMIT}"','tree = "DecayTree"',
           'input_momentum_unit = "MeV/c"','analysis_unit = "GeV, c=1"',
           'reader = "uproot==5.7.7"','collision_identifiers_available = false','']
    for polarity,metadata in FILES.items():
        path=args.cache/metadata['name']
        if not path.exists() and args.download:
            temporary=path.with_suffix('.root.part')
            with urllib.request.urlopen(BASE+metadata['name'],timeout=60) as response,temporary.open('wb') as stream:
                while block:=response.read(4*1024*1024):stream.write(block)
            verify(temporary,metadata);temporary.rename(path)
        verify(path,metadata)
        lines.extend([f'[files.{polarity}]',f'filename = "{metadata["name"]}"',
                      f'url = "{BASE+metadata["name"]}"',f'sha256 = "{metadata["sha256"]}"',
                      f'adler32 = "{metadata["adler32"]}"',f'bytes = {metadata["size"]}',
                      f'candidates = {metadata["entries"]}',''])
        print('Verified',polarity,metadata['entries'],'candidate entries',flush=True)
    (PAPER/'lhcb-data.toml').write_text('\n'.join(lines))


if __name__=='__main__':main()
