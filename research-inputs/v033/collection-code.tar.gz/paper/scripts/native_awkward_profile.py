"""Profile the native adapter on real LHCb inputs; profiling is not a benchmark."""
import argparse
import cProfile
import csv
from pathlib import Path
import pstats
import sys

import common


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=common.ROOT)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--repeats',type=int,default=8)
    parser.add_argument('--ablation',choices=['none','restore_view','restore_arithmetic'],default='none')
    args=parser.parse_args()
    sys.path.insert(0,str(args.source.resolve()))
    import numpy as np
    import lvec
    from native_awkward_study import apply_ablation
    from lhcb_data import CACHE,READ_BRANCHES
    from lhcb_analysis import calculate,reference,check
    assert Path(lvec.__file__).resolve().parent==args.source.resolve()/'lvec'
    apply_ablation(args.ablation)
    args.output.mkdir(parents=True,exist_ok=False)
    with np.load(CACHE/'pid-selected-down.npz',allow_pickle=False) as bank:
        columns={k:bank[k] for k in READ_BRANCHES}
    rows=[]
    for layout in (('awkward_native',) if args.ablation!='none' else ('numpy','awkward_owned','awkward_native')):
        for scenario in ('dalitz','rest_frame','hypotheses','analysis'):
            call=lambda:calculate(columns,'lvec',layout,scenario)
            expected=reference(columns,scenario)
            check(call(),expected)
            profile=cProfile.Profile()
            profile.enable()
            for _ in range(args.repeats):call()
            profile.disable()
            check(call(),expected)
            with (args.output/f'{layout}-{scenario}.txt').open('w') as stream:
                stats=pstats.Stats(profile,stream=stream)
                stats.strip_dirs().sort_stats('cumulative').print_stats(45)
            stats=pstats.Stats(profile)
            for (filename,line,function),(primitive,total,self_time,cumulative,callers) in stats.stats.items():
                rows.append(dict(layout=layout,scenario=scenario,file=filename,line=line,function=function,
                                 primitive_calls=primitive,total_calls=total,self_seconds=self_time,
                                 cumulative_seconds=cumulative,repeats=args.repeats))
            print(layout,scenario,flush=True)
    with (args.output/'functions.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (args.output/'provenance.md').write_text('# Diagnostic profiling\n\n'+
        f'Source: `{args.source.resolve()}`\n\nLibrary SHA256: `{common.fingerprint(args.source/"lvec")}`\n\n'+
        f'Ablation: `{args.ablation}`\n\n'+
        'Complete magnet-down PID-selected inputs; independent histogram checks pass.\n'+
        'cProfile instrumentation changes runtime. Cumulative times overlap and must not be summed.\n')


if __name__=='__main__':main()
