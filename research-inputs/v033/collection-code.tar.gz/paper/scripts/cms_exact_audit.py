"""Exact invariants for every selected CMS candidate in the full-file bank."""
import argparse
import csv
from pathlib import Path
import sys

import common
import numpy as np
from references import invariant,root_reference


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=Path('/tmp/lvec-native-awkward'))
    p.add_argument('--cache',type=Path,default=Path('/tmp/lvec-cms-open-data'));p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();sys.path.insert(0,str(args.source.resolve()))
    import lvec
    assert Path(lvec.__file__).resolve().parent==args.source.resolve()/'lvec'
    import awkward as ak
    from cms_data import load_cache
    from cms_analysis import calculate,good_muons,construct
    columns=load_cache(args.cache/'eligible-four-muon.npz');rows=[]
    outputs={backend:calculate(columns,backend,'four_muons',True) for backend in ('lvec','vector','vector_coordinates','components')}
    result=outputs['components'];positions=ak.to_numpy(result['event_positions']);indices=ak.to_list(result['track_indices'])
    mu=good_muons(columns);components=construct(mu,'components')
    assert len(positions)==86
    for j,(event,tracks) in enumerate(zip(positions,indices)):
        parts=[]
        source_indices=ak.to_list(mu.source_index[event])
        for i in tracks:
            selected=source_indices.index(i)
            parts.append(np.array([float(getattr(components,key)[event][selected]) for key in ('px','py','pz','E')]))
        parent=(parts[0]+parts[1])+(parts[2]+parts[3])
        reference=float(root_reference(invariant(parent)[0]))
        for backend,output in outputs.items():
            value=float(output['masses'][j])
            row=dict(run=int(columns['run'][event]),luminosity_block=int(columns['luminosityBlock'][event]),
                     event=int(columns['event'][event]),backend=backend,reference_cartesian_mass=reference,mass=value,
                     absolute_error_GeV=abs(value-reference))
            rows.append(row)
            # Natural-coordinate construction retains the input mass and has different rounding.
            if backend!='vector_coordinates':assert abs(value-reference)<2e-8
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(len(rows),'CMS candidate/backend exact-invariant observations',flush=True)


if __name__=='__main__':main()
