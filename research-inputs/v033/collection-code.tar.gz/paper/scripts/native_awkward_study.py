"""Causal adapter experiments and paired timings with frozen LHCb inputs."""
import argparse
import ast
import csv
from datetime import datetime,timezone
import gc
import hashlib
import importlib.metadata
import itertools
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys
import time
import tarfile

import common

BASELINE=Path(os.environ.get('LVEC_STUDY_BASELINE', '/tmp/lvec-paper-v0.3.1'))
CANDIDATE=Path(os.environ.get('LVEC_STUDY_SOURCE', '/tmp/lvec-release-v0.3.3'))
OUTPUT=common.PAPER/'results/native-awkward'
THREADS=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')
RICH=('dalitz','rest_frame','hypotheses','analysis')


def write(path,rows):
    with path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))


def orders_for(variants):
    if len(variants)==3:return list(itertools.permutations(variants))
    if len(variants)==4:
        # Each position and each preceding treatment is balanced across rows.
        return [tuple(variants[(index+shift)%4] for index in (0,1,3,2)) for shift in range(4)]
    raise ValueError('This design requires three or four variants')


def apply_ablation(mode,baseline=BASELINE):
    if mode=='none':return
    if mode=='restore_both':
        apply_ablation('restore_view',baseline)
        apply_ablation('restore_arithmetic',baseline)
        return
    import lvec.awkward as adapter
    if mode=='restore_view':
        tree=ast.parse((baseline/'lvec/awkward.py').read_text())
        node=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='_view')
        namespace=adapter.__dict__.copy()
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(baseline/'lvec/awkward.py'),'exec'),namespace)
        adapter._view=namespace['_view']
    elif mode=='restore_arithmetic':
        from lvec import LVec,Vector2D,Vector3D
        for cls,base in ((adapter._Borrowed2D,Vector2D),(adapter._Borrowed3D,Vector3D),(adapter._Borrowed4D,LVec)):
            for name in ('__add__','__sub__','__mul__','__rmul__','__getitem__'):
                setattr(cls,name,getattr(base,name))
    else:raise ValueError(mode)


def configure(source,ablation='none'):
    sys.path.insert(0,str(source.resolve()))
    import lvec
    assert Path(lvec.__file__).resolve().parent==source.resolve()/'lvec'
    assert platform.python_version()=='3.13.12'
    assert common.fingerprint(BASELINE/'lvec')=='13be557c610f7724410cdda01d3bb30e284a1772263929327460cbbeede20556'
    for name,version in {'numpy':'2.5.4','awkward':'2.14.0','vector':'1.9.0','uproot':'5.7.7'}.items():
        assert importlib.metadata.version(name)==version
    apply_ablation(ablation)


def cases():
    result=[]
    for polarity in ('down','up'):
        result.extend(dict(polarity=polarity,stage='selected',size=0,layout='awkward_native',scenario=scenario) for scenario in RICH)
        result.extend(dict(polarity=polarity,stage='selected',size=0,layout=layout,scenario='analysis') for layout in ('numpy','awkward_owned'))
        result.extend(dict(polarity=polarity,stage='selected',size=size,layout='awkward_native',scenario=scenario)
                      for size in (128,1024) for scenario in ('analysis','hypotheses'))
        result.append(dict(polarity=polarity,stage='resident',size=100000,layout='awkward_native',scenario='analysis'))
    return result


def columns_for(case):
    import numpy as np
    from lhcb_data import CACHE,READ_BRANCHES,FILES,read
    if case['stage']=='resident':return read(CACHE/FILES[case['polarity']]['name'],case['size'])
    with np.load(CACHE/f"pid-selected-{case['polarity']}.npz",allow_pickle=False) as bank:
        return {name:bank[name][:case['size'] or None] for name in READ_BRANCHES}


def worker(args):
    configure(args.source,args.ablation)
    from lhcb_analysis import calculate,reference,check
    case=cases()[args.case]
    columns=columns_for(case)
    implementation='vector' if args.variant=='vector' else 'lvec'
    call=lambda:calculate(columns,implementation,case['layout'],case['scenario'])
    expected=reference(columns,case['scenario'])
    check(call(),expected)
    for _ in range(2):call()
    enabled=gc.isenabled();gc.disable()
    try:
        loops=1
        while True:
            start=time.perf_counter()
            for _ in range(loops):call()
            duration=time.perf_counter()-start
            if duration>=.03:break
            loops*=max(2,min(10,int(.03/max(duration,1e-12))+1))
        rows=[]
        for sample in range(args.samples):
            load=os.getloadavg()[0]
            start=time.perf_counter();cpu=time.process_time()
            for _ in range(loops):call()
            wall=time.perf_counter()-start;cpu=time.process_time()-cpu
            rows.append(dict(**case,case=args.case,block=args.block,variant=args.variant,ablation=args.ablation,
                             order=args.order,sample=sample,loops=loops,wall_seconds=wall/loops,cpu_seconds=cpu/loops,
                             input_candidates=int(expected['counts'][0]),pid_candidates=int(expected['counts'][1]),
                             window_candidates=int(expected['counts'][2]),load_start=load,load_end=os.getloadavg()[0]))
    finally:
        if enabled:gc.enable()
    check(call(),expected)
    writer=csv.DictWriter(sys.stdout,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def validate(args):
    configure(args.source,args.ablation)
    import numpy as np
    from lhcb_data import CACHE,FILES,chunks,count
    from lhcb_analysis import SCENARIOS,calculate,reference,check
    from lhcb_validate import audit
    args.output.mkdir(parents=True,exist_ok=False)
    checks=0;audits=[];cutflow=[]
    for polarity,metadata in FILES.items():
        offset=selected=window=0;max_angle=0.
        for columns in chunks(CACHE/metadata['name'],100000):
            for scenario in SCENARIOS:
                check(calculate(columns,'lvec','awkward_native',scenario),reference(columns,scenario));checks+=1
            expected=reference(columns,'analysis',True)
            actual=calculate(columns,'lvec','awkward_native','analysis',True)
            check(actual,expected)
            selected+=int(actual['counts'][1]);window+=int(actual['counts'][2])
            if len(actual['cosine']):max_angle=max(max_angle,float(np.max(abs(actual['cosine']-expected['cosine']))))
            audits.extend(audit(columns,polarity,offset))
            offset+=count(columns)
            print(polarity,offset,flush=True)
        assert offset==metadata['entries']
        cutflow.append(dict(polarity=polarity,candidates=offset,pid_selected=selected,parent_window=window,
                            max_opening_cosine_difference=max_angle))
    write(args.output/'cutflow.csv',cutflow);write(args.output/'exact-audits.csv',audits)
    (args.output/'summary.md').write_text(f'# Candidate physics validation\n\n{checks} full-file native workflow/chunk comparisons pass with exact histogram agreement.\n\n{len(audits)} exact invariant observations pass. Both complete collision files were processed.\n\nSource SHA256: `{common.fingerprint(args.source/"lvec")}`\n')


def summarize(output):
    raw=read(output/'samples.csv')
    grouped={}
    for r in raw:grouped.setdefault((int(r['case']),r['variant']),{}).setdefault(int(r['block']),[]).append(r)
    summaries=[];centers={}
    for (case,variant),blocks in sorted(grouped.items()):
        med={b:statistics.median(float(r['wall_seconds']) for r in rows) for b,rows in blocks.items()}
        centers[case,variant]=med
        center=statistics.median(med.values())
        summaries.append(dict(**cases()[case],case=case,variant=variant,blocks=len(blocks),median_seconds=center,
                              mad_seconds=statistics.median(abs(t-center) for t in med.values())))
    variants=sorted({r['variant'] for r in raw});pairs=[]
    for case in sorted({int(r['case']) for r in raw}):
        own=centers[case,'candidate']
        for other in variants:
            if other=='candidate':continue
            med=centers[case,other];assert set(own)==set(med)
            ratio=[med[b]/own[b] for b in sorted(own)];center=statistics.median(ratio)
            pairs.append(dict(**cases()[case],case=case,comparison=other+'_over_candidate',paired_blocks=len(ratio),
                              time_ratio=center,ratio_mad=statistics.median(abs(x-center) for x in ratio),
                              min_block_ratio=min(ratio),max_block_ratio=max(ratio)))
    write(output/'summary.csv',summaries);write(output/'paired-ratios.csv',pairs)
    lines=['# Native adapter experiment','',f'{len(raw)} raw samples; {len(summaries)} case/variant cells.','',
           'Ratios pair process medians within blocks. MAD is dispersion, not a confidence interval.','',
           '| Polarity | Stage/size | Layout | Workflow | Comparison | Ratio | MAD |',
           '| --- | --- | --- | --- | --- | ---: | ---: |']
    for r in pairs:lines.append(f"| {r['polarity']} | {r['stage']}/{r['size']} | {r['layout']} | {r['scenario']} | {r['comparison']} | ${r['time_ratio']:.3f}$ | ${r['ratio_mad']:.3f}$ |")
    (output/'summary.md').write_text('\n'.join(lines)+'\n')


def collect(args):
    configure(CANDIDATE)
    from lhcb_data import CACHE,FILES,verify
    for metadata in FILES.values():verify(CACHE/metadata['name'],metadata)
    args.output.mkdir(parents=True,exist_ok=False)
    all_cases=cases()
    selected=[i for i,c in enumerate(all_cases) if c['polarity']=='down' and c['stage']=='selected' and not c['size'] and c['layout']=='awkward_native'] if args.task=='ablation' else list(range(len(all_cases)))
    variants=('baseline','view_only','arithmetic_only','candidate') if args.task=='ablation' else ('baseline','candidate','vector')
    orders=orders_for(variants)
    sources={name:(CANDIDATE if args.task=='ablation' else BASELINE if name in ('baseline','vector') else CANDIDATE) for name in variants}
    ablations={'view_only':'restore_arithmetic','arithmetic_only':'restore_view'}
    if args.task=='ablation':ablations['baseline']='restore_both'
    hashes={name:common.fingerprint(source/'lvec') for name,source in sources.items()}
    input_hashes={p:hashlib.file_digest((CACHE/f'pid-selected-{p}.npz').open('rb'),'sha256').hexdigest() for p in ('down','up')}
    with tarfile.open(args.output/'sources.tar.gz','w:gz') as archive:
        for variant,source in (('baseline',BASELINE),('candidate',CANDIDATE)):
            for path in (source/'lvec').glob('*.py'):archive.add(path,arcname=variant+'/lvec/'+path.name)
        for path in (Path(__file__),common.PAPER/'scripts/common.py',
                     common.PAPER/'scripts/native_awkward_profile.py',
                     common.PAPER/'scripts/lhcb_validate.py',common.PAPER/'scripts/references.py',
                     common.PAPER/'scripts/lhcb_analysis.py',common.PAPER/'scripts/lhcb_data.py',
                     common.PAPER/'requirements.txt',common.PAPER/'native-awkward-study.md',
                     CANDIDATE/'lvec/tests/test_native_awkward_views.py'):
            if path.exists():archive.add(path,arcname='study/'+path.name)
    info={'utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'platform':platform.platform(),
          'source_hashes':hashes,'selected_bank_hashes':input_hashes,'orders':orders,'samples':args.samples,
          'packages':{name:importlib.metadata.version(name) for name in ('numpy','awkward','vector','uproot')}}
    (args.output/'provenance.md').write_text('# Experiment provenance\n\n'+'\n'.join(f'- {k}: `{v}`' for k,v in info.items())+'\n')
    patch=subprocess.run(['git','diff','--','lvec/awkward.py'],cwd=CANDIDATE,capture_output=True,text=True,check=True).stdout
    (args.output/'candidate.patch').write_text(patch)
    rows=[]
    for block,order in enumerate(orders):
        sequence=selected.copy();random.Random(20261103+block).shuffle(sequence)
        for case in sequence:
            for rank,variant in enumerate(order):
                assert common.fingerprint(CANDIDATE/'lvec')==hashes.get('candidate',common.fingerprint(CANDIDATE/'lvec'))
                print(args.task,'block',block+1,'case',case,variant,flush=True)
                command=[sys.executable,'-W','error::RuntimeWarning',str(Path(__file__).resolve()),'--task','worker',
                         '--source',str(sources[variant]),'--variant',variant,'--ablation',ablations.get(variant,'none'),
                         '--case',str(case),'--block',str(block),'--order',str(rank),'--samples',str(args.samples)]
                result=subprocess.run(command,env=dict(os.environ,PYTHONHASHSEED='0',**{k:'1' for k in THREADS}),
                                      capture_output=True,text=True,timeout=120)
                if result.returncode:raise RuntimeError(result.stderr)
                rows.extend(csv.DictReader(result.stdout.splitlines()))
                write(args.output/'samples.csv',rows)
    summarize(args.output)
    print('Collection complete.',flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--task',choices=['worker','validate','compare','ablation','analyse'],required=True)
    p.add_argument('--source',type=Path,default=CANDIDATE)
    p.add_argument('--output',type=Path,default=OUTPUT/'comparison')
    p.add_argument('--variant',default='candidate')
    p.add_argument('--ablation',choices=['none','restore_view','restore_arithmetic','restore_both'],default='none')
    p.add_argument('--case',type=int,default=0);p.add_argument('--block',type=int,default=0)
    p.add_argument('--order',type=int,default=0);p.add_argument('--samples',type=int,default=5)
    args=p.parse_args()
    if args.task=='worker':worker(args)
    elif args.task=='validate':validate(args)
    elif args.task=='analyse':summarize(args.output)
    else:collect(args)


if __name__=='__main__':main()
