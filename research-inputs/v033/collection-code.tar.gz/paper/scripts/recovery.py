"""Time two-point recovery mixtures; count actual recovery in separate workers."""
import argparse
from contextlib import ExitStack
import csv
import hashlib
import io
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import time
from unittest.mock import patch

from common import PAPER, environment
from references import boost_reference, invariant, rounded
from performance import THREADS, summaries, write_csv
import numpy as np

FRACTIONS=(0.,1e-4,1e-2,.1,1.)
BETA=(-.9,0.,0.)
ORDINARY=(1.,2.,3.,5.)
CHALLENGING={'mass2':(math.ldexp(3.,900),math.ldexp(4.,900),0.,math.ldexp(5.,900)),
             'boost':(1e308,0.,0.,1e308)}


def fixture(operation,size,fraction,seed,layout):
    count=round(size*fraction)
    if not math.isclose(count/size,fraction,rel_tol=0,abs_tol=1e-15):
        raise ValueError('size must realize every fraction exactly')
    selected=np.zeros(size,dtype=bool)
    selected[np.random.default_rng(seed).permutation(size)[:count]]=True
    flat=tuple(np.where(selected,special,ordinary) for ordinary,special in zip(ORDINARY,CHALLENGING[operation]))
    digest=hashlib.sha256(b''.join(x.tobytes() for x in flat)).hexdigest()
    counts=np.full(size//4,4,dtype=int)
    counts[:2]=[0,8]  # An empty event while retaining exactly size particles.
    if layout=='jagged':
        import awkward as ak
        values=tuple(ak.unflatten(x,counts) for x in flat)
    else:values=flat
    return values,selected,counts,digest


def prepare(operation,size,fraction,seed,layout):
    from lvec import LVec
    values,selected,counts,digest=fixture(operation,size,fraction,seed,layout)
    collection=LVec(*values,max_cache_size=0)
    if operation=='mass2':
        ordinary=rounded(invariant(ORDINARY)[0]);challenging=rounded(invariant(CHALLENGING[operation])[0])
        expected=(np.where(selected,challenging,ordinary),)
        call=lambda:collection.mass2
    else:
        a,b=boost_reference(ORDINARY,BETA),boost_reference(CHALLENGING[operation],BETA)
        expected=tuple(np.where(selected,rounded(y),rounded(x)) for x,y in zip(a,b))
        call=lambda:collection.boost(*BETA)
    def check(result):
        actual=(result,) if operation=='mass2' else result.to_p4()
        for component,wanted in zip(actual,expected):
            if layout=='jagged':
                import awkward as ak
                assert ak.to_list(ak.num(component))==counts.tolist()
                component=ak.to_numpy(ak.flatten(component))
            np.testing.assert_allclose(component,wanted,rtol=3e-15,atol=0.)
        assert collection.cache_size==0
    return call,check,digest


def diagnose(call):
    """Count selected rows and the specific arithmetic paths, returning real outputs."""
    from lvec import _adaptive, _exact
    original_selected=_exact._accurate_numpy
    original_integer=_exact._numpy_result
    original_compensated=_exact._compensated_sum
    original_decimal=_adaptive._boost_decimal
    counts=dict(selected_invariant_entries=0,integer_entries=0,compensated_entries=0,decimal_entries=0)
    def selected(values,**kwargs):
        arrays=np.broadcast_arrays(*values)
        mask=np.logical_and.reduce([np.isfinite(x) for x in arrays])
        if kwargs.get('where') is not None:mask &= np.broadcast_to(kwargs['where'],mask.shape)
        counts['selected_invariant_entries']+=int(np.count_nonzero(mask))
        return original_selected(values,**kwargs)
    def integer(values,**kwargs):
        counts['integer_entries']+=np.asarray(values[0]).size
        return original_integer(values,**kwargs)
    def compensated(values,**kwargs):
        counts['compensated_entries']+=np.asarray(values[0]).size
        return original_compensated(values,**kwargs)
    def decimal(values):
        counts['decimal_entries']+=1
        return original_decimal(values)
    with ExitStack() as stack:
        for module,name,wrapper in [(_exact,'_accurate_numpy',selected),(_exact,'_numpy_result',integer),
                                    (_exact,'_compensated_sum',compensated),(_adaptive,'_boost_decimal',decimal)]:
            stack.enter_context(patch.object(module,name,wrapper))
        result=call()
    assert _exact._accurate_numpy is original_selected and _adaptive._boost_decimal is original_decimal
    return result,counts


def worker(args):
    sys.path.insert(0,str(args.source.resolve()))
    environment()
    from benchmarks.runner import measure
    cases=[(layout,operation,fraction) for layout in ('numpy','jagged')
           for operation in ('mass2','boost') for fraction in FRACTIONS]
    random.Random(args.seed+args.process).shuffle(cases)
    rows=[]
    for layout,operation,fraction in cases:
        call,check,digest=prepare(operation,args.size,fraction,args.seed,layout)
        base=dict(layout=layout,size=args.size,case=operation,fraction=fraction,
                  challenging_entries=round(args.size*fraction),input_sha256=digest)
        if args.worker=='diagnostic':
            result,counts=diagnose(call);check(result)
            rows.append(dict(**base,**counts))
        else:
            check(call())
            measurement=measure(call,args.samples,args.min_time,args.warmups)
            check(call())
            for sample,seconds in enumerate(measurement['seconds']):
                rows.append(dict(**base,process=args.process,sample=sample,
                                 loops=measurement['loops'],seconds=repr(seconds)))
    writer=csv.DictWriter(sys.stdout,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=Path('/tmp/lvec-paper-v0.3.1'))
    parser.add_argument('--output',type=Path,default=PAPER/'results'/'recovery')
    parser.add_argument('--size',type=int,default=10000)
    parser.add_argument('--processes',type=int,default=7)
    parser.add_argument('--samples',type=int,default=9)
    parser.add_argument('--warmups',type=int,default=3)
    parser.add_argument('--min-time',type=float,default=.05)
    parser.add_argument('--seed',type=int,default=20261101)
    parser.add_argument('--worker',choices=('diagnostic','timing'))
    parser.add_argument('--process',type=int,default=0)
    parser.add_argument('--diagnostic-only',action='store_true')
    args=parser.parse_args()
    if args.size<8 or args.size%10000 or min(args.processes,args.samples,args.warmups)<1 or args.min_time<=0:
        parser.error('size must be a positive multiple of 10000; counts and duration positive')
    if args.worker:worker(args);return
    args.output.mkdir(parents=True,exist_ok=True)
    if (args.output/'samples.csv').exists():parser.error('choose a fresh output directory')
    sys.path.insert(0,str(args.source.resolve()))
    info=environment()
    args.output.joinpath('provenance.md').write_text('# Recovery timing provenance\n\n'+
        '\n'.join(f'- {k}: `{v}`' for k,v in info.items())+f'\n- Arguments: `{vars(args)}`\n'+
        '\nPrivate recovery functions are wrapped only in a separate diagnostic process.\n'+
        'Timing workers use unmodified functions, the frozen timer, and disabled input caching.\n')
    def launch(mode,process=0):
        command=[sys.executable,'-W','error::RuntimeWarning',str(Path(__file__).resolve()),
                 '--worker',mode,'--source',str(args.source),'--size',str(args.size),
                 '--samples',str(args.samples),'--warmups',str(args.warmups),'--min-time',str(args.min_time),
                 '--seed',str(args.seed),'--process',str(process)]
        result=subprocess.run(command,env=dict(os.environ,PYTHONHASHSEED='0',**{k:'1' for k in THREADS}),
                              capture_output=True,text=True,timeout=600)
        if result.returncode:raise RuntimeError(result.stderr)
        return list(csv.DictReader(io.StringIO(result.stdout)))
    diagnostics=launch('diagnostic');write_csv(args.output/'diagnostics.csv',diagnostics)
    if args.diagnostic_only:
        print('Saved diagnostics; no timing.',flush=True);return
    start=time.monotonic()
    with (args.output/'samples.csv').open('w',newline='') as stream:
        writer=None
        for process in range(args.processes):
            print(f'Recovery timing: process {process+1}/{args.processes}; elapsed {(time.monotonic()-start)/60:.1f} min',flush=True)
            rows=launch('timing',process)
            for row in rows:
                diagnostic=next(d for d in diagnostics if all(d[key]==row[key] for key in ('layout','size','case','fraction')))
                assert diagnostic['input_sha256']==row['input_sha256'],'diagnostic and timing inputs differ'
            if writer is None:writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader()
            writer.writerows(rows);stream.flush()
    with (args.output/'samples.csv').open(newline='') as stream:raw=list(csv.DictReader(stream))
    # Fraction is a part of each workload key; retain it while sharing aggregation.
    prepared=[dict(r,case=r['case']+':'+r['fraction']) for r in raw]
    summary=summaries(prepared)
    for row in summary:
        row['case'],fraction=row['case'].split(':');row['fraction']=float(fraction)
        observed=next(r for r in diagnostics if r['layout']==row['layout'] and r['case']==row['case'] and float(r['fraction'])==row['fraction'])
        row['recovered_entries']=int(observed['selected_invariant_entries'])+int(observed['decimal_entries'])
        row['actual_recovery_fraction']=row['recovered_entries']/args.size
    write_csv(args.output/'summary.csv',summary)
    lines=['# Recovery mixture study','',f'{args.size:,} particles per call; seven fresh processes by default.',
           'Two-point mixtures use a fixed ordinary row and an exact-null stress row.',
           'The null stress inputs are finite and future-directed. Squared mass exercises',
           'integer product sums; the boost fixture exercises Decimal range recovery.',
           'These are controlled fixtures, not measured frequencies in physics datasets.','',
           '| Layout | Operation | Difficult fraction | Actual recovered | Median ms | MAD ms |',
           '| --- | --- | ---: | ---: | ---: | ---: |']
    for r in sorted(summary,key=lambda r:(r['layout'],r['case'],r['fraction'])):
        lines.append(f"| {r['layout']} | {r['case']} | ${r['fraction']:g}$ | ${r['actual_recovery_fraction']:g}$ | ${r['median_seconds']*1000:.5f}$ | ${r['mad_seconds']*1000:.5f}$ |")
    lines += ['', 'Medians and MAD describe process medians. Setup, independent output checks,',
              'and recovery instrumentation are outside timing. Both layouts contain the',
              'same number of particles; jagged inputs have one empty event. The cost',
              'includes the checks and traversal that select risky entries, not just the',
              'arithmetic inside recovery helpers. No safeguards were disabled.','']
    (args.output/'summary.md').write_text('\n'.join(lines))
    print('Recovery study complete.',flush=True)


if __name__=='__main__':main()
