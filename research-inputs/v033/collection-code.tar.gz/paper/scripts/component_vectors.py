"""Explicit component arithmetic baseline; no ownership, caching, or recovery."""
import numpy as np


class Components:
    def __init__(self,px,py,pz,E):self.px,self.py,self.pz,self.E=px,py,pz,E
    def __add__(self,other):
        return Components(self.px+other.px,self.py+other.py,self.pz+other.pz,self.E+other.E)
    def __getitem__(self,index):
        return Components(*(c[index] for c in (self.px,self.py,self.pz,self.E)))
    @property
    def mass2(self):return self.E*self.E-(self.px*self.px+self.py*self.py+self.pz*self.pz)
    @property
    def mass(self):
        squared=self.mass2
        return np.copysign(np.sqrt(abs(squared)),squared)
    def boostCM_of_p4(self,p):
        mass=p.mass
        product=self.px*p.px+self.py*p.py+self.pz*p.pz
        factor=product/(mass*(p.E+mass))-self.E/mass
        return Components(self.px+factor*p.px,self.py+factor*p.py,self.pz+factor*p.pz,
                          (self.E*p.E-product)/mass)
