"""Write and verify a checksum manifest confined to one boundary collection."""
import hashlib
from pathlib import Path

NAME = 'checksums.sha256'


def payload(directory):
    return {path.name: path for path in sorted(Path(directory).iterdir())
            if path.is_file() and path.name != NAME}


def write_manifest(directory):
    directory = Path(directory)
    lines = [hashlib.sha256(path.read_bytes()).hexdigest()+'  '+name+'\n'
             for name, path in payload(directory).items()]
    with (directory / NAME).open('x') as stream:
        stream.writelines(lines)


def verify_manifest(directory):
    directory = Path(directory)
    expected = {}
    for line in (directory / NAME).read_text().splitlines():
        digest, name = line.split('  ', 1)
        if Path(name).name != name or name in ('.', '..', NAME) or name in expected:
            raise ValueError(f'Invalid manifest entry: {name}')
        expected[name] = digest
    actual = payload(directory)
    if not expected or set(expected) != set(actual):
        raise ValueError('Manifest does not list exactly this collection\'s files')
    for name, path in actual.items():
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected[name]:
            raise ValueError(f'Checksum mismatch: {name}')
    return len(expected)
