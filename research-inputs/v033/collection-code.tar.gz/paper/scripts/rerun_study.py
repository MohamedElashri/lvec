"""Run the complete released-source study on an explicitly identified native host."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tomllib

from common import PAPER, fingerprint
from release_study import summarize_numerical

THREADS = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
           'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')
CANDIDATE = 'fb9bd5d7bf386336aae87fad9d252bbad09670c727bfd3ef53d16c2538c2d251'
BASELINE = '13be557c610f7724410cdda01d3bb30e284a1772263929327460cbbeede20556'


def host_record(host, source, baseline, output):
    system, machine = platform.system(), platform.machine().lower()
    expected = {'m1-macos': ('Darwin', ('arm64',)),
                'x86_64-linux': ('Linux', ('x86_64',)),
                'aarch64-linux': ('Linux', ('aarch64', 'arm64'))}
    wanted, architectures = expected[host]
    assert system == wanted and machine in architectures, (host, system, machine)
    assert fingerprint(source/'lvec') == CANDIDATE and fingerprint(baseline/'lvec') == BASELINE
    metadata = tomllib.loads((PAPER/'source.toml').read_text())
    assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip() == metadata['source']['commit']
    assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
    assert not subprocess.check_output(['git','-C',str(baseline),'status','--porcelain'],text=True)
    pinned = tomllib.loads((PAPER/'source.toml').read_text())['baseline_environment']
    assert platform.python_version() == pinned['python']
    for name in ('numpy','awkward','vector','pytest'):
        assert importlib.metadata.version(name) == pinned[name]
    lines = ['# Collection host', '', f'host = {host}', f'utc = {datetime.now(timezone.utc).isoformat()}',
             f'platform = {platform.platform()}', f'architecture = {machine}',
             f'logical_cpus = {os.cpu_count()}', f'library_sha256 = {CANDIDATE}',
             f'baseline_sha256 = {BASELINE}', f'collection_scripts_sha256 = {fingerprint(PAPER/"scripts")}',
             f'input_bundle_sha256 = {os.environ.get("LVEC_INPUT_SHA256", "local-preflight")}',
             f'github_run_id = {os.environ.get("GITHUB_RUN_ID", "local")}',
             'numerical_library_threads = 1']
    if hasattr(os,'sched_getaffinity'):
        allowed = sorted(os.sched_getaffinity(0))
        os.sched_setaffinity(0,allowed[:2])
        lines += [f'original_affinity = {allowed}',f'collection_affinity = {sorted(os.sched_getaffinity(0))}']
        for name in ('cpuinfo','meminfo'):
            path=Path('/proc')/name
            if path.exists():(output/(name+'.txt')).write_text(path.read_text())
    else:
        result=subprocess.run(['sysctl','machdep.cpu.brand_string','hw.logicalcpu','hw.memsize'],capture_output=True,text=True)
        (output/'hardware.txt').write_text(result.stdout + result.stderr)
    (output/'host.md').write_text('\n'.join(lines)+'\n')
    packages=sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions())
    (output/'environment.txt').write_text(''.join(f'{n}=={v}\n' for n,v in packages))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',choices=('m1-macos','x86_64-linux','aarch64-linux'),required=True)
    parser.add_argument('--source',type=Path,default=Path('/tmp/lvec-release-v0.3.3'))
    parser.add_argument('--baseline',type=Path,default=Path('/tmp/lvec-paper-v0.3.1'))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--phase',choices=('all','prepare','measure','diagnostics'),default='all')
    args=parser.parse_args()
    args.source=args.source.resolve();args.baseline=args.baseline.resolve();args.output=args.output.resolve()
    scripts=Path(__file__).resolve().parent
    env=dict(os.environ, PYTHONPATH=str(args.source), PYTHONHASHSEED='0',
             LVEC_STUDY_SOURCE=str(args.source), LVEC_STUDY_BASELINE=str(args.baseline),
             LVEC_PAPER_SOURCE=str(args.source),
             **{name:'1' for name in THREADS})
    def run(label,script,arguments=(),cwd=None):
        print('Starting '+label,flush=True)
        log=args.output/'logs'/(label+'.txt')
        if log.exists():raise RuntimeError(f'Existing phase log must be preserved: {log}')
        with log.open('w') as stream:
            command=[sys.executable,*(['-W','error::RuntimeWarning'] if script != '-m' else []),
                     str(scripts/script) if script != '-m' else '-m',*map(str,arguments)]
            subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
        print('Completed '+label,flush=True)
    if args.phase in ('all','prepare'):
        args.output.mkdir(parents=True,exist_ok=False);(args.output/'logs').mkdir()
        host_record(args.host,args.source,args.baseline,args.output)
        run('tests','-m',['pytest','-q',args.source/'lvec/tests',args.source/'benchmarks/tests',PAPER/'tests','-W','error::RuntimeWarning'],cwd=args.source)
        run('lhcb-input','lhcb_data.py',['--download'])
        run('cms-input','cms_data.py',['--download'])
        run('lhcb-validation','lhcb_validate.py',['--output',args.output/'lhcb'])
        run('cms-validation','cms_validate.py',['--source',args.source,'--output',args.output/'cms'])
        golden=PAPER/'results/lhcb/histograms.csv';golden.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(args.output/'lhcb/histograms.csv',golden)
        run('accuracy','accuracy.py',['--output',args.output/'accuracy'])
        run('decay','decay.py',['--output',args.output/'decay'])
        run('cms-exact','cms_exact_audit.py',['--source',args.source,'--output',args.output/'cms-exact.csv'])
        (args.output/'numerical').mkdir()
        for label,source,backend in [('candidate',args.source,'lvec'),('released',args.baseline,'lvec'),
                                     ('vector',args.source,'vector'),('components',args.source,'components')]:
            run('numerical-'+label,'physics_effects.py',['--source',source,'--backend',backend,'--output',args.output/'numerical'/(label+'.csv')])
        summarize_numerical(args.output/'numerical')
        run('recovery-paths','recovery_paths.py',['--input',args.output/'numerical/candidate.csv','--source',args.source,'--output',args.output/'diagnostics'])
        run('referee-acceptance','review_acceptance.py',['--source',args.source,'--output',args.output/'review'])
        run('boundary-validation','recovery_boundaries.py',['--output',args.output/'boundaries'])
        run('ordinary-recovery','ordinary_recovery.py',['--output',args.output/'ordinary-recovery'])
        (args.output/'PREPARED').write_text(CANDIDATE+'\n')
    else:
        assert (args.output/'PREPARED').read_text().strip()==CANDIDATE
        host_record(args.host,args.source,args.baseline,args.output)
    if args.phase in ('all','measure'):
        for suite in ('lhcb','cms'):
            for mode in ('time','memory'):
                run(suite+'-'+mode,'complete_study.py',['run','--suite',suite,'--mode',mode,
                    '--candidate',args.source,'--baseline',args.baseline,'--output',args.output/(suite+'-'+mode)])
        run('lhcb-ancillary','complete_study.py',['run','--suite','lhcb','--ancillary','--candidate',args.source,'--baseline',args.baseline,'--output',args.output/'lhcb-ancillary'])
        run('ablation','native_awkward_study.py',['--task','ablation','--output',args.output/'ablation'])
        run('native-comparison','native_awkward_study.py',['--task','compare','--output',args.output/'native-comparison'])
        run('operations','performance.py',['--source',args.source,'--output',args.output/'performance',
            '--sizes',1,1000,10000,100000,'--processes',7,'--samples',9,'--min-time',.05])
        run('recovery','recovery.py',['--source',args.source,'--output',args.output/'recovery'])
        run('gamma-runtime','gamma_validation.py',['--original',args.baseline,'--corrected',args.source,'--output',args.output/'gamma-runtime.csv'])
        (args.output/'MEASURED').write_text(CANDIDATE+'\n')
        run('api-costs','numerical_api_timing.py',['--output',args.output/'api-costs'])
        run('owned-reuse','reuse_study.py',['--output',args.output/'reuse'])
    if args.phase in ('all','diagnostics'):
        assert (args.output/'MEASURED').read_text().strip()==CANDIDATE
        for mode in ('none','restore_view','restore_arithmetic'):
            run('profile-'+mode,'native_awkward_profile.py',['--source',args.source,'--ablation',mode,'--output',args.output/'profiles'/mode])
        run('cms-profile','cms_profile.py',['--source',args.source,'--output',args.output/'profiles/cms'])
        (args.output/'COMPLETE').write_text('Library SHA256: '+CANDIDATE+'\n')
        print('Complete research rerun finished: '+args.host,flush=True)


if __name__=='__main__':main()
