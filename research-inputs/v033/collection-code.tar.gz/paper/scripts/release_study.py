"""Collect the v0.3.3 M1 study sequentially from frozen collection code."""
import argparse
import csv
import os
from pathlib import Path
import statistics
import subprocess
import sys

from common import PAPER, fingerprint


def summarize_numerical(directory):
    summaries = []
    for name in ('candidate', 'released', 'vector', 'components'):
        with (directory / (name + '.csv')).open() as stream:
            rows = list(csv.DictReader(stream))
        assert len(rows) == 3584
        for gamma in (1, 2, 10, 100, 1000, 10000, 1000000):
            values = [r for r in rows if int(r['gamma']) == gamma]
            assert len(values) == 512
            result = dict(backend=name, gamma=gamma, candidates=len(values))
            for stage in ('input', 'addition', 'arithmetic', 'total'):
                errors = [abs(float(r[stage + '_error'])) for r in values]
                result['max_abs_' + stage + '_error'] = max(errors)
                result['median_abs_' + stage + '_error'] = statistics.median(errors)
            for decision in ('cut', 'bin'):
                for stage in ('input', 'addition', 'arithmetic', 'total'):
                    key = stage + '_' + decision + '_change'
                    result[key] = sum(int(r[key]) for r in values)
            result['spacelike_input'] = sum(int(r['spacelike_input']) for r in values)
            summaries.append(result)
    with (directory / 'summary.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path('/tmp/lvec-release-v0.3.3'))
    parser.add_argument('--baseline', type=Path, default=Path('/tmp/lvec-paper-v0.3.1'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / 'logs').mkdir()
    env = os.environ.copy()
    env.update({k: '1' for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                                'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')})
    env['PYTHONPATH'] = str(args.source.resolve())
    env['PYTHONHASHSEED'] = '0'
    scripts = Path(__file__).resolve().parent

    def run(label, script, arguments=()):
        print(f'Starting {label}', flush=True)
        with (args.output / 'logs' / (label + '.txt')).open('w') as log:
            subprocess.run([sys.executable, str(scripts / script), *map(str, arguments)],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        print(f'Completed {label}', flush=True)

    run('lhcb-input', 'lhcb_data.py')
    run('cms-input', 'cms_data.py')
    run('lhcb-validation', 'lhcb_validate.py', ['--output', args.output / 'lhcb'])
    run('cms-validation', 'cms_validate.py', ['--source', args.source, '--output', args.output / 'cms'])
    run('accuracy', 'accuracy.py', ['--output', args.output / 'accuracy'])
    run('decay', 'decay.py', ['--output', args.output / 'decay'])
    run('cms-exact', 'cms_exact_audit.py', ['--source', args.source, '--output', args.output / 'cms-exact.csv'])
    numerical = args.output / 'numerical'
    numerical.mkdir()
    for label, source, backend in [('candidate', args.source, 'lvec'), ('released', args.baseline, 'lvec'),
                                    ('vector', args.source, 'vector'), ('components', args.source, 'components')]:
        run('numerical-' + label, 'physics_effects.py', ['--source', source, '--backend', backend,
                                                       '--output', numerical / (label + '.csv')])
    summarize_numerical(numerical)
    run('recovery-paths', 'recovery_paths.py', ['--input', numerical / 'candidate.csv',
                                              '--source', args.source, '--output', args.output / 'diagnostics'])
    host = args.output / 'm1-macos'
    for suite in ('lhcb', 'cms'):
        for mode in ('time', 'memory'):
            run(suite + '-' + mode, 'complete_study.py', ['run', '--suite', suite, '--mode', mode,
                '--candidate', args.source, '--baseline', args.baseline, '--output', host / f'{suite}-{mode}'])
    run('lhcb-ancillary', 'complete_study.py', ['run', '--suite', 'lhcb', '--ancillary',
        '--candidate', args.source, '--baseline', args.baseline, '--output', host / 'lhcb-ancillary'])
    run('ablation', 'native_awkward_study.py', ['--task', 'ablation', '--output', args.output / 'ablation'])
    run('operations', 'performance.py', ['--source', args.source, '--output', args.output / 'performance',
        '--sizes', 1, 10000, '--processes', 5, '--samples', 5, '--min-time', .03])
    run('recovery', 'recovery.py', ['--source', args.source, '--output', args.output / 'recovery'])
    run('gamma-runtime', 'gamma_validation.py', ['--original', args.baseline, '--corrected', args.source,
                                               '--output', args.output / 'gamma-runtime.csv'])
    (args.output / 'COMPLETE').write_text(f'Library SHA256: {fingerprint(args.source / "lvec")}\n')
    print('Release study complete.', flush=True)


if __name__ == '__main__':
    main()
