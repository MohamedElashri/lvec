"""Conserving two-body decay, independent matrix checks, and jagged masks."""
import argparse
import csv
from pathlib import Path

from common import PAPER, environment, write_provenance
from references import matrix_boost, two_body_constants
import awkward as ak
import numpy as np
import vector
from lvec import LVec

NAMES = ('px', 'py', 'pz', 'E')
RTOL = 2e-11
ATOL = 2e-12  # GeV; fixed before inspecting outcomes.


def generate(seed, events):
    rng = np.random.default_rng(seed)
    counts = rng.integers(0, 9, size=events)
    counts[:4] = [0, 1, 2, 4]
    count = int(counts.sum())
    q, ea, eb = two_body_constants()
    cosine = rng.uniform(-1., 1., count)
    phi = rng.uniform(-np.pi, np.pi, count)
    sine = np.sqrt((1-cosine)*(1+cosine))
    momentum = q*np.column_stack((sine*np.cos(phi), sine*np.sin(phi), cosine))
    first = np.column_stack((momentum, np.full(count, ea)))
    second = np.column_stack((-momentum, np.full(count, eb)))
    beta = rng.normal(size=(count, 3))
    beta *= rng.uniform(0., .995, count)[:,None]/np.linalg.norm(beta, axis=1)[:,None]
    present = rng.random(count) > .15
    event_present = rng.random(events) > .1
    event_present[:4] = [True, True, False, True]
    present[0] = True
    present[3] = False
    return first, second, beta, counts, present, event_present


def jagged(values, counts, present, event_present):
    return ak.mask(ak.unflatten(ak.mask(values, present), counts), event_present)


def visible(values):
    return ak.to_numpy(ak.flatten(values, axis=None)) if isinstance(values, ak.Array) else np.asarray(values)


def compare(actual, expected, implementation, layout, name, rows):
    if isinstance(expected, ak.Array):
        for axis in (0, 1):
            assert ak.to_list(ak.is_none(actual, axis=axis)) == ak.to_list(ak.is_none(expected, axis=axis)), (layout, name, 'mask', axis)
        assert ak.to_list(ak.num(actual, axis=1)) == ak.to_list(ak.num(expected, axis=1)), (layout, name, 'counts')
    actual, expected = visible(actual), visible(expected)
    assert actual.shape == expected.shape, (layout, name, 'shape')
    assert np.all(np.isfinite(actual)) and np.all(np.isfinite(expected)), (layout, name, 'nonfinite')
    residual = np.abs(actual-expected)
    normalized = residual/(ATOL+RTOL*np.abs(expected))
    maximum = float(np.max(normalized, initial=0.))
    rows.append(dict(implementation=implementation, layout=layout, check=name,
                     values=actual.size, max_absolute_error_GeV=float(np.max(residual, initial=0.)),
                     max_tolerance_fraction=maximum, passed=maximum <= 1.))
    if maximum > 1:
        raise AssertionError((implementation, layout, name, maximum))


def run(data):
    first, second, beta, counts, present, event_present = data
    matrix_a, matrix_b = matrix_boost(first, beta), matrix_boost(second, beta)
    count = len(first)
    rest_parent = np.zeros_like(first)
    rest_parent[:,3] = 5.
    matrix_parent = matrix_boost(rest_parent, beta)
    checks, outputs = [], {}
    vector.register_awkward()
    for layout in ('dense','jagged','jagged_missing'):
        def wrap(values):
            if layout == 'dense':
                return values
            return jagged(values, counts, present if layout.endswith('missing') else np.ones(count, bool),
                          event_present if layout.endswith('missing') else np.ones(len(counts), bool))
        for implementation in ('lvec','vector'):
            def make(rows):
                fields = dict(zip(NAMES, (wrap(x) for x in rows.T)))
                if implementation == 'lvec':
                    return LVec(**fields)
                return vector.array(fields) if layout == 'dense' else vector.zip(fields)
            a, b = make(first), make(second)
            velocity = [wrap(x) for x in beta.T]
            if implementation == 'lvec':
                lab_a, lab_b = a.boost(*velocity), b.boost(*velocity)
            else:
                fields = dict(zip(('x','y','z'), velocity))
                boost = vector.array(fields) if layout == 'dense' else vector.zip(fields)
                lab_a, lab_b = a.boost_beta3(boost), b.boost_beta3(boost)
            parent = lab_a+lab_b
            for label, obj, expected in [('daughter_a',lab_a,matrix_a),('daughter_b',lab_b,matrix_b),('parent',parent,matrix_parent)]:
                for index, name in enumerate(NAMES):
                    compare(getattr(obj, name), wrap(expected[:,index]), implementation, layout, label+'_'+name, checks)
            for label, obj, mass in [('daughter_a',lab_a,1.),('daughter_b',lab_b,.5),('parent',parent,5.)]:
                compare(obj.mass, wrap(np.full(count,mass)), implementation, layout, label+'_mass', checks)
            restored_a = lab_a.boost_to_rest(parent) if implementation=='lvec' else lab_a.boostCM_of_p4(parent)
            restored_b = lab_b.boost_to_rest(parent) if implementation=='lvec' else lab_b.boostCM_of_p4(parent)
            for label, obj, expected in [('rest_a',restored_a,first),('rest_b',restored_b,second),('rest_parent',restored_a+restored_b,rest_parent)]:
                for index, name in enumerate(NAMES):
                    compare(getattr(obj,name), wrap(expected[:,index]), implementation, layout, label+'_'+name, checks)
            if layout != 'dense':
                # Compare sums of reconstructed parents to independent component sums.
                total = parent.sum(axis=-1) if implementation=='lvec' else ak.sum(parent, axis=-1)
                for index, name in enumerate(NAMES):
                    expected = ak.sum(wrap(matrix_parent[:,index]), axis=-1)
                    actual = getattr(total,name)
                    assert ak.to_list(ak.is_none(actual)) == ak.to_list(ak.is_none(expected))
                    compare(visible(actual), visible(expected), implementation, layout, 'event_sum_'+name, checks)
            if layout == 'dense':
                outputs[implementation] = (np.asarray(parent.mass), np.asarray(restored_a.E))
    return checks, outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=PAPER/'results'/'decay')
    parser.add_argument('--events', type=int, default=2500)
    parser.add_argument('--seed', type=int, default=20261101)
    args = parser.parse_args()
    if args.events < 4 or args.seed < 0:
        parser.error('events must be at least four and seed nonnegative')
    info = environment()
    write_provenance(args.output, info, vars(args))
    (args.output/'summary.md').write_text('# No completed result for this invocation\n\nReplaced only after the study completes.\n')
    data = generate(args.seed,args.events)
    checks, outputs = run(data)
    first, second, beta, counts, present, event_present = data
    with (args.output/'checks.csv').open('w',newline='') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(checks[0]))
        writer.writeheader(); writer.writerows(checks)
    # Hexadecimal strings round-trip every binary float, independently of CSV parsers.
    with (args.output/'inputs.csv').open('w',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(['event','candidate','present','event_present',
                         *['a_'+x+'_hex' for x in NAMES],*['b_'+x+'_hex' for x in NAMES],
                         'bx_hex','by_hex','bz_hex'])
        offset=0
        for event,count in enumerate(counts):
            for candidate in range(count):
                index=offset+candidate
                writer.writerow([event,candidate,bool(present[index]),bool(event_present[event]),
                                 *[float(x).hex() for x in (*first[index],*second[index],*beta[index])]])
            offset+=count
    with (args.output/'events.csv').open('w',newline='') as stream:
        writer=csv.writer(stream); writer.writerow(['event','candidates','present'])
        writer.writerows((i,int(n),bool(p)) for i,(n,p) in enumerate(zip(counts,event_present)))
    with (args.output/'reconstruction.csv').open('w',newline='') as stream:
        writer=csv.writer(stream); writer.writerow(['candidate','implementation','parent_mass_GeV','rest_a_energy_GeV'])
        for name,(masses,energies) in outputs.items():
            writer.writerows((i,name,repr(float(m)),repr(float(e))) for i,(m,e) in enumerate(zip(masses,energies)))
    maximum=max(row['max_tolerance_fraction'] for row in checks)
    lines=['# Conserving two-body decay', '',
           f'- Seed: {args.seed}; events: {args.events}; generated candidates: {len(first)}.',
           f'- Empty generated events: {np.count_nonzero(counts==0)}; absent events: {np.count_nonzero(~event_present)}.',
           f'- Masses: $M=5$, $m_a=1$, $m_b=0.5$ GeV; $c=1$.',
           '- Laboratory speed sampled uniformly in $[0,0.995)$ with isotropic direction.',
           f'- Passed {len(checks)} checks across both implementations and all three layouts.',
           f'- Fixed tolerances: relative ${RTOL:g}$; absolute ${ATOL:g}$ GeV.',
           f'- Largest fraction of the allowed error: {maximum:.6g}.', '',
           'Checks cover independent active-boost matrix components, daughter and parent',
           'masses, restoration to the parent rest frame, jagged masks and multiplicities,',
           'and event reductions. Empty event sums are zero; absent events stay missing.', '',
           'This is an idealized generated sample, with no detector response or physical',
           'production model. No execution times or reconstruction-resolution claims are made.', '']
    (args.output/'summary.md').write_text('\n'.join(lines))
    print('\n'.join(lines))


if __name__=='__main__':
    main()
