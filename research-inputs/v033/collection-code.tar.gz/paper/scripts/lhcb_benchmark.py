"""Paired, workflow-level benchmarks on authenticated LHCb collision data."""
import argparse
import csv
import gc
import hashlib
import importlib.metadata
import io
import os
from pathlib import Path
import random
import resource
import statistics
import subprocess
import sys
import time

from common import PAPER,environment,fingerprint
from lhcb_data import CACHE,FILES,READ_BRANCHES,read,chunks,count,verify
from lhcb_analysis import SCENARIOS,LAYOUTS,calculate,reference,check,add_results
from performance import THREADS,write_csv,read_csv
import numpy as np

RICH=('dalitz','rest_frame','hypotheses','analysis')
FIELDS=['stage','polarity','size','layout','scenario','implementation','process','sample',
        'loops','wall_seconds','cpu_seconds','input_candidates','pid_candidates','window_candidates',
        'load_start','load_end','order']


def timed(call,samples,warmups,target):
    for _ in range(warmups):call()
    loops=1;enabled=gc.isenabled();gc.disable()
    try:
        while True:
            start=time.perf_counter()
            for _ in range(loops):call()
            duration=time.perf_counter()-start
            if duration>=target or loops>=1000000:break
            loops=min(1000000,loops*max(2,min(10,int(np.ceil(target/max(duration,1e-12))))))
        output=[]
        for sample in range(samples):
            start=time.perf_counter();cpu=time.process_time()
            for _ in range(loops):call()
            output.append(dict(sample=sample,loops=loops,wall_seconds=(time.perf_counter()-start)/loops,
                               cpu_seconds=(time.process_time()-cpu)/loops))
    finally:
        if enabled:gc.enable()
    return output


def stream(path,step,implementation,layout):
    total=None
    for columns in chunks(path,step):total=add_results(total,calculate(columns,implementation,layout,'analysis'))
    return total


def stream_expected(output,polarity):
    result={}
    rows=[r for r in read_csv(output/'histograms.csv') if r['polarity']==polarity]
    for name in {r['observable'] for r in rows}:
        subset=[r for r in rows if r['observable']==name]
        shape=(max(int(r['bin_x']) for r in subset)+1,)
        if int(subset[0]['bin_y'])>=0:shape+=(max(int(r['bin_y']) for r in subset)+1,)
        a=np.zeros(shape,dtype=np.int64)
        for r in subset:a[(int(r['bin_x']),int(r['bin_y'])) if len(shape)>1 else int(r['bin_x'])]=int(r['count'])
        result[name]=a
    cut=next(r for r in read_csv(output/'cutflow.csv') if r['polarity']==polarity)
    result['counts']=np.array([int(cut[k]) for k in ['candidates','pid_selected','parent_window']])
    return result


def load_columns(args):
    if args.stage=='stream':return None
    if args.stage=='selected':
        with np.load(args.cache/f'pid-selected-{args.polarity}.npz',allow_pickle=False) as bank:
            return {k:bank[k] for k in READ_BRANCHES}
    return read(args.cache/FILES[args.polarity]['name'],args.size)


def reader_worker(args):
    environment()
    def call():return sum(count(columns) for columns in chunks(args.cache/FILES[args.polarity]['name'],args.size))
    assert call()==FILES[args.polarity]['entries']
    rows=[]
    enabled=gc.isenabled();gc.disable()
    try:
        for sample in range(3):
            load=os.getloadavg()[0]
            start=time.perf_counter();cpu=time.process_time()
            candidates=call()
            wall=time.perf_counter()-start;cpu=time.process_time()-cpu
            assert candidates==FILES[args.polarity]['entries']
            rows.append(dict(polarity=args.polarity,size=args.size,process=args.process,sample=sample,
                             wall_seconds=wall,cpu_seconds=cpu,input_candidates=candidates,
                             load_start=load,load_end=os.getloadavg()[0]))
    finally:
        if enabled:gc.enable()
    writer=csv.DictWriter(sys.stdout,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def worker(args):
    environment()
    assert importlib.metadata.version('uproot')=='5.7.7'
    columns=load_columns(args)
    cases=[(layout,scenario) for layout in (('numpy','awkward_native') if args.stage=='stream' else LAYOUTS)
           for scenario in (('analysis',) if args.stage=='stream' else RICH if args.stage=='selected' else SCENARIOS)]
    if args.layout:cases=[(args.layout,args.scenario)]
    random.Random(20261101+args.process).shuffle(cases)
    results=[]
    for index,(layout,scenario) in enumerate(cases):
        expected=None if args.worker=='memory' else stream_expected(args.validation,args.polarity) if args.stage=='stream' else reference(columns,scenario)
        order=['lvec','vector'] if (args.process+index)%2==0 else ['vector','lvec']
        if args.worker=='memory':order=[args.implementation]
        for rank,implementation in enumerate(order):
            call=(lambda:stream(args.cache/FILES[args.polarity]['name'],args.size,implementation,layout)) if args.stage=='stream' else (lambda:calculate(columns,implementation,layout,scenario))
            base=dict(stage=args.stage,polarity=args.polarity,size=args.size,layout=layout,
                      scenario=scenario,implementation=implementation,process=args.process)
            if args.worker=='memory':
                result=call()  # No independent oracle is run in this memory process.
                peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
                peak_bytes=peak if sys.platform=='darwin' else peak*1024
                results.append(dict(**base,peak_rss_bytes=peak_bytes,input_candidates=int(result['counts'][0]),
                                    pid_candidates=int(result['counts'][1]),window_candidates=int(result['counts'][2])))
            else:
                actual=call();check(actual,expected)
                counts=dict(zip(('input_candidates','pid_candidates','window_candidates'),map(int,actual['counts'])))
                load=os.getloadavg()[0]
                if args.stage=='stream':
                    # The checked call above is the one warmup. Complete-file
                    # calls exceed the batch target; no calibration is needed.
                    measurements=[]
                    enabled=gc.isenabled();gc.disable()
                    try:
                        for sample in range(args.samples):
                            start=time.perf_counter();cpu=time.process_time()
                            result=call()
                            wall=time.perf_counter()-start;cpu=time.process_time()-cpu
                            measurements.append(dict(sample=sample,loops=1,wall_seconds=wall,cpu_seconds=cpu))
                            check(result,expected)  # Outside both timers.
                    finally:
                        if enabled:gc.enable()
                else:
                    measurements=timed(call,args.samples,2,.02)
                    check(call(),expected)
                endload=os.getloadavg()[0]
                results.extend(dict(**base,**m,**counts,load_start=load,load_end=endload,order=rank) for m in measurements)
    writer=csv.DictWriter(sys.stdout,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)


def summarize(output):
    raw=read_csv(output/'samples.csv')
    grouped={}
    for row in raw:
        key=tuple(row[k] for k in ('stage','polarity','size','layout','scenario','implementation'))
        grouped.setdefault(key,{}).setdefault(int(row['process']),[]).append(row)
    summary=[];process_medians={}
    for key,processes in sorted(grouped.items()):
        medians={p:statistics.median(float(x['wall_seconds']) for x in rows) for p,rows in processes.items()}
        cpu=[statistics.median(float(x['cpu_seconds']) for x in rows) for rows in processes.values()]
        center=statistics.median(medians.values());first=next(iter(processes.values()))[0]
        summary.append(dict(zip(('stage','polarity','size','layout','scenario','implementation'),key),
                            processes=len(processes),median_seconds=center,
                            mad_seconds=statistics.median(abs(x-center) for x in medians.values()),
                            median_cpu_seconds=statistics.median(cpu),
                            **{k:int(first[k]) for k in ('input_candidates','pid_candidates','window_candidates')}))
        process_medians[key]=medians
    pairs=[]
    for key,own in process_medians.items():
        if key[-1]!='lvec':continue
        other=process_medians[key[:-1]+('vector',)]
        assert set(own)==set(other)
        ratios=[other[p]/own[p] for p in sorted(own)]
        center=statistics.median(ratios)
        pairs.append(dict(zip(('stage','polarity','size','layout','scenario'),key[:-1]),
                          paired_processes=len(ratios),vector_over_lvec=center,
                          ratio_mad=statistics.median(abs(x-center) for x in ratios),
                          min_process_ratio=min(ratios),max_process_ratio=max(ratios)))
    write_csv(output/'summary.csv',summary);write_csv(output/'paired-ratios.csv',pairs)
    lines=['# Real-data workflow timings','',f'{len(pairs)} paired cells; {len(raw)} timed samples.',
           'Wall times are medians of fresh-process medians. Ratios are medians of',
           'within-process vector/LVec time ratios; MAD is process dispersion.','',
           '## Complete preselected samples','',
           '| Polarity | Layout | Workflow | LVec ms | vector ms | Paired ratio |',
           '| --- | --- | --- | ---: | ---: | ---: |']
    for pair in pairs:
        if pair['stage']!='selected':continue
        cells=[r for r in summary if all(str(r[k])==str(pair[k]) for k in ('stage','polarity','size','layout','scenario'))]
        own=next(r for r in cells if r['implementation']=='lvec');other=next(r for r in cells if r['implementation']=='vector')
        lines.append(f"| {pair['polarity']} | {pair['layout']} | {pair['scenario']} | ${own['median_seconds']*1000:.4f}$ | ${other['median_seconds']*1000:.4f}$ | ${pair['vector_over_lvec']:.3f}$ |")
    lines+=['','## ROOT-to-histogram processing','','| Polarity | Chunk | Layout | LVec s | vector s | Paired ratio |',
            '| --- | ---: | --- | ---: | ---: | ---: |']
    for pair in pairs:
        if pair['stage']!='stream':continue
        cells=[r for r in summary if all(str(r[k])==str(pair[k]) for k in ('stage','polarity','size','layout','scenario'))]
        own=next(r for r in cells if r['implementation']=='lvec');other=next(r for r in cells if r['implementation']=='vector')
        lines.append(f"| {pair['polarity']} | {pair['size']} | {pair['layout']} | ${own['median_seconds']:.4f}$ | ${other['median_seconds']:.4f}$ | ${pair['vector_over_lvec']:.3f}$ |")
    lines+=['','Full resident-prefix, selection-ordering, CPU-time, RSS, and process-ratio',
            'results are retained in the CSVs. All input records are actual collision',
            'candidates. Awkward records are flat, not fabricated collision groups.','']
    (output/'summary.md').write_text('\n'.join(lines))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache',type=Path,default=CACHE)
    parser.add_argument('--output',type=Path,default=PAPER/'results/lhcb/timing')
    parser.add_argument('--validation',type=Path,default=PAPER/'results/lhcb')
    parser.add_argument('--worker',choices=['timing','memory','reader'])
    parser.add_argument('--stage',choices=['resident','selected','stream'],default='resident')
    parser.add_argument('--polarity',choices=FILES,default='down')
    parser.add_argument('--size',type=int,default=100000)
    parser.add_argument('--process',type=int,default=0)
    parser.add_argument('--samples',type=int,default=7)
    parser.add_argument('--layout',choices=LAYOUTS)
    parser.add_argument('--scenario',choices=SCENARIOS)
    parser.add_argument('--implementation',choices=['lvec','vector'])
    parser.add_argument('--smoke',action='store_true')
    parser.add_argument('--analyse-only',action='store_true')
    args=parser.parse_args()
    if args.worker=='reader':reader_worker(args);return
    if args.worker:worker(args);return
    if args.analyse_only:summarize(args.output);return
    args.output.mkdir(parents=True,exist_ok=True)
    if (args.output/'samples.csv').exists():parser.error('choose a fresh output directory')
    info=environment()
    for metadata in FILES.values():verify(args.cache/metadata['name'],metadata)
    banks={p:hashlib.file_digest((args.cache/f'pid-selected-{p}.npz').open('rb'),'sha256').hexdigest() for p in FILES}
    (args.output/'provenance.md').write_text('# ROOT workflow timing provenance\n\n'+
        '\n'.join(f'- {k}: `{v}`' for k,v in info.items())+f'\n- uproot: `{importlib.metadata.version("uproot")}`\n- Selected bank SHA256: `{banks}`\n'+
        '\nFive processes/seven samples for resident data; three processes/three samples for complete-file streaming.\n'+
        'Within each process, implementation order alternates and situations are shuffled.\n'+
        'Wall and process CPU times are recorded independently. Reader parallelism is one plus one worker.\n'+
        f'Reading is restricted to the {len(READ_BRANCHES)} branches used by the analysis.\n')
    def launch(stage,polarity,size,process,samples,mode='timing',layout=None,scenario=None,implementation=None):
        command=[sys.executable,'-W','error::RuntimeWarning',str(Path(__file__).resolve()),'--worker',mode,
                 '--cache',str(args.cache),'--validation',str(args.validation),'--stage',stage,'--polarity',polarity,
                 '--size',str(size),'--process',str(process),'--samples',str(samples)]
        for flag,value in [('--layout',layout),('--scenario',scenario),('--implementation',implementation)]:
            if value is not None:command.extend([flag,value])
        result=subprocess.run(command,env=dict(os.environ,PYTHONHASHSEED='0',**{k:'1' for k in THREADS}),
                              capture_output=True,text=True,timeout=900)
        if result.returncode:raise RuntimeError(result.stderr)
        return list(csv.DictReader(io.StringIO(result.stdout)))
    groups=[('resident',p,size) for p in FILES for size in ([10000] if args.smoke else [100000,1000000])]
    if not args.smoke:groups += [('selected',p,0) for p in FILES]+[('stream',p,size) for p in FILES for size in (25000,100000,500000)]
    with (args.output/'samples.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=FIELDS);writer.writeheader()
        for stage,polarity,size in groups:
            processes=1 if args.smoke else 3 if stage=='stream' else 5
            samples=1 if args.smoke else 3 if stage=='stream' else 7
            for process in range(processes):
                print(f'Timing {stage} {polarity} {size}: process {process+1}/{processes}',flush=True)
                writer.writerows(launch(stage,polarity,size,process,samples));stream.flush()
    memory=[]
    if not args.smoke:
        for stage,polarity,size in groups:
            if stage not in ('resident','stream') or stage=='resident' and size!=1000000:continue
            layouts=('numpy','awkward_native') if stage=='stream' else LAYOUTS
            for layout in layouts:
                for scenario in (('analysis',) if stage=='stream' else ('select_early','select_late')):
                    for implementation in ('lvec','vector'):
                        print(f'Peak RSS {stage} {polarity} {size} {layout} {scenario} {implementation}',flush=True)
                        memory.extend(launch(stage,polarity,size,0,1,'memory',layout,scenario,implementation))
        write_csv(args.output/'memory.csv',memory)
        reader=[]
        for polarity in FILES:
            for size in (25000,100000,500000):
                for process in range(3):
                    print(f'Reader baseline {polarity} {size}: process {process+1}/3',flush=True)
                    command=[sys.executable,'-W','error::RuntimeWarning',str(Path(__file__).resolve()),
                             '--worker','reader','--cache',str(args.cache),'--polarity',polarity,
                             '--size',str(size),'--process',str(process)]
                    result=subprocess.run(command,env=dict(os.environ,PYTHONHASHSEED='0',**{k:'1' for k in THREADS}),
                                          capture_output=True,text=True,timeout=900)
                    if result.returncode:raise RuntimeError(result.stderr)
                    reader.extend(csv.DictReader(io.StringIO(result.stdout)))
        write_csv(args.output/'reader.csv',reader)
    summarize(args.output)
    print('Real-data timing complete.',flush=True)


if __name__=='__main__':main()
