"""Independent study references. No LVec or vector implementation is imported.

Component order inside the study is (px, py, pz, E), except for the explicitly
energy-first Lorentz matrices. Exact references describe supplied binary floats.
"""
from decimal import Decimal, localcontext
from fractions import Fraction
import math

import numpy as np


def rational(value):
    return Fraction.from_float(float(value))


def invariant(row):
    terms = [rational(value) ** 2 for value in row]
    return terms[3] - sum(terms[:3]), sum(terms)


def as_decimal(value):
    if isinstance(value, Fraction):
        return Decimal(value.numerator) / Decimal(value.denominator)
    return Decimal.from_float(float(value))


def rounded(value):
    try:
        return float(value)
    except OverflowError:
        return math.copysign(math.inf, -1 if value < 0 else 1)


def signed_root(value, precision):
    with localcontext() as context:
        context.prec = precision
        root = as_decimal(abs(value)).sqrt()
        return root.copy_negate() if value < 0 else root


def root_reference(value):
    low, high = signed_root(value, 400), signed_root(value, 800)
    if rounded(low).hex() != rounded(high).hex():
        raise ArithmeticError("Root reference did not converge at float64 output")
    return high


def valid_beta(beta):
    return all(math.isfinite(float(x)) for x in beta) and sum(rational(x)**2 for x in beta) < 1


def decimal_boost(row, beta, precision):
    if not valid_beta(beta):
        raise ValueError("Reference requires finite, subluminal beta")
    with localcontext() as context:
        context.prec = precision
        p = [as_decimal(x) for x in row]
        b = [as_decimal(x) for x in beta]
        b2 = sum(x*x for x in b)
        gamma = 1 / (1-b2).sqrt()
        # Algebraically equal to (gamma-1)/b2, including its zero-velocity limit.
        coefficient = gamma*gamma / (gamma+1)
        bp = sum(x*y for x, y in zip(p[:3], b))
        spatial = [p[i] + b[i]*(coefficient*bp + gamma*p[3]) for i in range(3)]
        return tuple(spatial + [gamma*(p[3]+bp)])


def boost_reference(row, beta):
    low, high = decimal_boost(row, beta, 400), decimal_boost(row, beta, 800)
    if any(rounded(a).hex() != rounded(b).hex() for a, b in zip(low, high)):
        raise ArithmeticError("Boost reference did not converge at float64 output")
    return high


def lorentz_matrices(beta):
    """Active boost matrices on columns (E, px, py, pz), for ordinary inputs."""
    beta = np.asarray(beta, dtype=float)
    b2 = np.einsum('ni,ni->n', beta, beta)
    if np.any(~np.isfinite(beta)) or np.any(b2 >= 1):
        raise ValueError("Matrix reference requires subluminal finite velocities")
    gamma = 1 / np.sqrt(1-b2)
    matrix = np.zeros((len(beta), 4, 4))
    matrix[:, 0, 0] = gamma
    matrix[:, 0, 1:] = matrix[:, 1:, 0] = gamma[:, None]*beta
    coefficient = gamma*gamma/(gamma+1)
    matrix[:, 1:, 1:] = np.eye(3) + coefficient[:, None, None]*beta[:, :, None]*beta[:, None, :]
    return matrix


def matrix_boost(rows, beta):
    energy_first = np.asarray(rows)[:, [3, 0, 1, 2]]
    transformed = np.einsum('nij,nj->ni', lorentz_matrices(beta), energy_first)
    return transformed[:, [1, 2, 3, 0]]


def two_body_constants(parent=5, first=1, second=.5):
    """Analytic phase space in GeV; arithmetic is independent of vector classes."""
    with localcontext() as context:
        context.prec = 100
        m, a, b = map(as_decimal, (parent, first, second))
        if a < 0 or b < 0 or m <= a+b:
            raise ValueError("Require positive available two-body phase space")
        q = ((m*m-(a+b)**2)*(m*m-(a-b)**2)).sqrt()/(2*m)
        return float(q), float((m*m+a*a-b*b)/(2*m)), float((m*m+b*b-a*a)/(2*m))
