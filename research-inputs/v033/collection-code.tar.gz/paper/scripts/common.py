"""Frozen-source and research-artifact bookkeeping."""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import os
from pathlib import Path
import platform
import sys
import tomllib

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parent
sys.path.insert(0, str(ROOT))


def fingerprint(directory):
    digest = hashlib.sha256()
    for path in sorted(directory.glob('*.py')):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def environment():
    import lvec
    manifest = tomllib.loads((PAPER / 'source.toml').read_text())
    source = Path(lvec.__file__).resolve().parent
    if lvec.__version__ != manifest['source']['version'] or fingerprint(source) != manifest['source']['library_sha256']:
        raise RuntimeError("Loaded implementation differs from the frozen study release")
    versions = {name: importlib.metadata.version(name) for name in ('numpy', 'awkward', 'vector', 'pytest')}
    if platform.python_version() != manifest['baseline_environment']['python']:
        raise RuntimeError("Use the frozen Python version or explicitly revise the study environment")
    for name, version in versions.items():
        if version != manifest['baseline_environment'][name]:
            raise RuntimeError(f"Unexpected {name} version: {version}")
    return {'utc': datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'python': platform.python_version(), 'executable': sys.executable,
            'platform': platform.platform(), 'logical_cpus': os.cpu_count(),
            'release_commit': manifest['source']['commit'], 'lvec_version': lvec.__version__,
            'loaded_module': str(source), 'library_sha256': fingerprint(source),
            'study_scripts_sha256': fingerprint(PAPER / 'scripts'), **versions}


def write_provenance(output, info, arguments):
    output.mkdir(parents=True, exist_ok=True)
    lines = ['# Study provenance', '', *[f'- {key}: `{value}`' for key, value in info.items()],
             '', f'- Arguments: `{arguments}`', '',
             'Numerical validation only; no execution-time measurements.', '']
    (output / 'provenance.md').write_text('\n'.join(lines))
    # Works in uv-created environments without pip; source imports are recorded above.
    packages = sorted((distribution.metadata['Name'], distribution.version)
                      for distribution in importlib.metadata.distributions())
    (output / 'environment.txt').write_text(''.join(f'{name}=={version}\n' for name, version in packages))
