"""Complete-event validation, scalar pairing checks, and physical histograms."""
import argparse
import csv
from pathlib import Path
import sys

import common


def write(path,rows):
    with path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=Path('/tmp/lvec-native-awkward'))
    parser.add_argument('--cache',type=Path,default=Path('/tmp/lvec-cms-open-data'))
    parser.add_argument('--output',type=Path,default=common.PAPER/'results/complete/cms')
    parser.add_argument('--limit',type=int)
    args=parser.parse_args();sys.path.insert(0,str(args.source.resolve()))
    import lvec
    assert Path(lvec.__file__).resolve().parent==args.source.resolve()/'lvec'
    import awkward as ak
    import numpy as np
    from cms_data import chunks,NAME,ENTRIES,BRANCHES,save_cache
    from cms_analysis import calculate,check,scalar_reference,SCENARIOS,good_muons,EDGES
    args.output.mkdir(parents=True,exist_ok=True)
    totals={};offset=0;checks=0;scalar_count=0;raw_parts=[];good_parts=[]
    multiplicity={};good_multiplicity={};nraw4=neligible=0
    for columns in chunks(args.cache/NAME,100000,args.limit):
        np.testing.assert_array_equal(ak.to_numpy(ak.num(columns['Muon_pt'])),ak.to_numpy(columns['nMuon']))
        for name in BRANCHES:
            if name.startswith('Muon_'):
                np.testing.assert_array_equal(ak.to_numpy(ak.num(columns[name])),ak.to_numpy(columns['nMuon']))
        good=good_muons(columns);counts=ak.num(good)
        eligible=(counts>=4)&(ak.sum(good.charge==1,axis=1)>=2)&(ak.sum(good.charge==-1,axis=1)>=2)
        raw=columns['nMuon']>=4;nraw4+=int(ak.sum(raw));neligible+=int(ak.sum(eligible))
        if args.limit is None:
            raw_parts.append({k:ak.to_packed(v[raw]) for k,v in columns.items()})
            good_parts.append({k:ak.to_packed(v[eligible]) for k,v in columns.items()})
        for source,out in ((columns['nMuon'],multiplicity),(counts,good_multiplicity)):
            values,freq=np.unique(ak.to_numpy(source),return_counts=True)
            for value,n in zip(values,freq):out[int(value)]=out.get(int(value),0)+int(n)
        last=None
        for scenario in SCENARIOS:
            expected=calculate(columns,'components',scenario,True)
            for backend in ('lvec','vector','vector_coordinates'):
                check(calculate(columns,backend,scenario,True),expected);checks+=1
            plain={k:v for k,v in expected.items() if isinstance(v,np.ndarray)}
            if scenario not in totals:totals[scenario]={k:v.copy() for k,v in plain.items()}
            else:
                for k,v in plain.items():totals[scenario][k]+=v
            if scenario=='four_muons':last=expected
        scalar=scalar_reference(columns)
        positions=[r['event'] for r in scalar]
        assert positions==ak.to_list(last['event_positions']),(offset,positions,ak.to_list(last['event_positions']))
        assert [r['indices'] for r in scalar]==ak.to_list(last['track_indices']),offset
        np.testing.assert_allclose([r['mass'] for r in scalar],ak.to_numpy(last['masses']),rtol=2e-7,atol=2e-8)
        scalar_count+=len(scalar);offset+=len(columns['nMuon'])
        print(f'Validated {offset:,} events; {neligible:,} eligible; {scalar_count:,} accepted four-muon candidates',flush=True)
    if args.limit is None:
        assert offset==ENTRIES
        for label,parts in (('raw-four-muon',raw_parts),('eligible-four-muon',good_parts)):
            bank={key:ak.concatenate([part[key] for part in parts]) for key in BRANCHES}
            save_cache(args.cache/f'{label}.npz',bank)
    histograms=[];cutflow=[]
    for scenario,values in totals.items():
        row=dict(scenario=scenario)
        row.update(dict(zip(('events','raw_muons','good_muons','eligible_events','os_pairs','accepted'),map(int,values['counts']))))
        cutflow.append(row)
        for name,array in values.items():
            if name=='counts':continue
            for i,count in enumerate(array):histograms.append(dict(scenario=scenario,observable=name,bin=i,count=int(count)))
    write(args.output/'histograms.csv',histograms);write(args.output/'cutflow.csv',cutflow)
    write(args.output/'multiplicities.csv',[dict(selection=label,muons=value,events=n) for label,d in [('raw',multiplicity),('good',good_multiplicity)] for value,n in sorted(d.items())])
    (args.output/'summary.md').write_text(f'# CMS jagged validation\n\n{offset:,} actual collision events; {checks} backend/scenario/chunk comparisons pass.\n\n'+
        f'{nraw4:,} events have at least four raw muons; {neligible:,} meet good-muon multiplicity/charge requirements.\n\n'+
        f'{scalar_count:,} accepted candidates have independently checked scalar pair choices and masses.\n\n'+
        f'Candidate source SHA256: `{common.fingerprint(args.source/"lvec")}`.\n')
    print((args.output/'summary.md').read_text())


if __name__=='__main__':main()
