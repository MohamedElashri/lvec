"""Run every frozen benchmark case, sequentially, with durable raw CSV output."""
import argparse
import csv
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

from common import PAPER, environment, fingerprint

THREADS = ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
           'VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')
SAMPLE_FIELDS = ('layout','size','particles','visible_particles','case','process',
                 'sample','loops','seconds')


def summaries(rows):
    groups = {}
    for row in rows:
        key = (row['layout'],int(row['size']),row['case'])
        groups.setdefault(key,{}).setdefault(int(row['process']),[]).append(float(row['seconds']))
    output=[]
    for (layout,size,case),processes in sorted(groups.items()):
        medians=[statistics.median(values) for _,values in sorted(processes.items())]
        median=statistics.median(medians)
        output.append(dict(layout=layout,size=size,case=case,processes=len(medians),
                           median_seconds=median,mad_seconds=statistics.median(abs(x-median) for x in medians),
                           min_process_seconds=min(medians),max_process_seconds=max(medians)))
    return output


def write_csv(path,rows):
    with path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def read_csv(path):
    with path.open(newline='') as stream:return list(csv.DictReader(stream))


def analyse(output):
    raw=read_csv(output/'samples.csv')
    summary=summaries(raw)
    write_csv(output/'summary.csv',summary)
    by_key={(r['layout'],r['size'],r['case']):r for r in summary}
    pairs=[]
    for row in summary:
        case=row['case']
        if case.startswith('vector.'):continue
        other={'mass_uncached':'vector.mass','record_construct':'vector.construct',
               'record_construct_mass':'vector.construct_mass','record_mass':'vector.mass',
               'record_boost':'vector.boost','record_rotate_euler':'vector.rotate_euler'}.get(case,'vector.'+case)
        reference=by_key.get((row['layout'],row['size'],other))
        if reference is None:continue
        semantics='different ownership guarantees' if case in ('construct','construct_mass') else 'same calculation boundary'
        # Store empty fixtures, but do not interpret them as particle throughput.
        count=next(int(r['visible_particles']) for r in raw if r['layout']==row['layout'] and int(r['size'])==row['size'])
        pairs.append(dict(layout=row['layout'],size=row['size'],visible_particles=count,
                          lvec_case=case,vector_case=other,boundary=semantics,
                          lvec_seconds=row['median_seconds'],vector_seconds=reference['median_seconds'],
                          vector_over_lvec=reference['median_seconds']/row['median_seconds']))
    write_csv(output/'comparisons.csv',pairs)
    lines=['# Performance study', '',
           f'{len(summary)} workload/size/layout rows; {len(raw)} timed samples.',
           'Primary times are medians of fresh-process medians. MAD is the dispersion',
           'of those process medians, not a confidence interval. Raw samples and loop',
           'counts are retained. Allocation measurements use separate workers and are not RSS.', '',
           '## Largest fixtures', '',
           r'Ratios $t_{\mathrm{vector}}/t_{\mathrm{LVec}}>1$ favor LVec.', '',
           '| Layout | Operation | LVec ms | vector ms | Ratio |',
           '| --- | --- | ---: | ---: | ---: |']
    selected=('mass_uncached','unit_cold','boost','boost_gamma_array','boost_p4','boost_p4_array',
              'rotate_euler_array','rotate_quaternion_array','matrix4d_dense_array','workflow')
    largest=max(r['size'] for r in summary)
    for row in pairs:
        if row['size']==largest and row['lvec_case'] in selected:
            lines.append(f"| {row['layout']} | `{row['lvec_case']}` | ${row['lvec_seconds']*1000:.4f}$ | ${row['vector_seconds']*1000:.4f}$ | ${row['vector_over_lvec']:.3f}$ |")
    lines += ['', 'All remaining cases, construction boundaries, smaller fixtures, and native',
              'record cases are retained in the CSVs. Jagged sizes count events; use',
              'visible-particle counts when comparing layouts. The size-one jagged fixture',
              'is empty. Cached reads and owned construction are separate use cases.', '',
              'Only one machine is measured. Power mode is recorded, but frequency,',
              'affinity, thermal conditions, and other user activity are not controlled.', '']
    (output/'summary.md').write_text('\n'.join(lines))
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=Path('/tmp/lvec-paper-v0.3.1'))
    parser.add_argument('--output',type=Path,default=PAPER/'results'/'performance')
    parser.add_argument('--sizes',type=int,nargs='+',default=[1,1000,10000,100000])
    parser.add_argument('--processes',type=int,default=7)
    parser.add_argument('--samples',type=int,default=9)
    parser.add_argument('--warmups',type=int,default=3)
    parser.add_argument('--min-time',type=float,default=.05)
    parser.add_argument('--seed',type=int,default=20261101)
    parser.add_argument('--analyse-only',action='store_true')
    args=parser.parse_args()
    if args.analyse_only:
        analyse(args.output);return
    if min(args.sizes+[args.processes,args.samples,args.warmups])<1 or args.min_time<=0:
        parser.error('sizes, counts, and durations must be positive')
    args.source=args.source.resolve();args.output.mkdir(parents=True,exist_ok=True)
    if (args.output/'samples.csv').exists():
        parser.error('raw samples already exist; choose a fresh output directory')
    sys.path.insert(0,str(args.source))
    os.environ.update({key:'1' for key in THREADS})
    info=environment()
    from benchmarks import runner
    import tomllib
    manifest=tomllib.loads((PAPER/'source.toml').read_text())
    assert fingerprint(args.source/'benchmarks')==manifest['source']['framework_sha256']
    assert subprocess.check_output(['git','-C',str(args.source),'rev-parse','HEAD'],text=True).strip()==info['release_commit']
    assert not subprocess.check_output(['git','-C',str(args.source),'status','--porcelain'],text=True)
    (args.output/'summary.md').write_text('# Incomplete timing run\n\nCompleted processes remain in samples.csv.\n')
    (args.output/'provenance.md').write_text('# Timing provenance\n\n'+'\n'.join(f'- {key}: `{value}`' for key,value in info.items())+
        f'\n- Framework SHA256: `{runner.framework_hash()}`\n- Arguments: `{vars(args)}`\n- Initial load averages: `{os.getloadavg()}`\n\n'+
        'Frozen benchmark workers are reused unchanged; their JSON IPC remains in memory.\n'+
        'Inputs, output checks, case order, GC behavior, and timing calibration follow that framework.\n')
    import importlib.metadata
    (args.output/'environment.txt').write_text(''.join(f"{d.metadata['Name']}=={d.version}\n" for d in sorted(importlib.metadata.distributions(),key=lambda d:d.metadata['Name'])))
    baseline=None;start=time.monotonic()
    with (args.output/'samples.csv').open('w',newline='') as samples, (args.output/'allocations.csv').open('w',newline='') as allocation_file:
        writer=csv.DictWriter(samples,fieldnames=SAMPLE_FIELDS);writer.writeheader()
        allocations=csv.DictWriter(allocation_file,fieldnames=['layout','size','case','retained_bytes','peak_bytes']);allocations.writeheader()
        for layout in ('numpy','jagged'):
            for size in args.sizes:
                config=dict(source=str(args.source),layout=layout,size=size,seed=args.seed,compare_vector=True,
                            cases=None,samples=args.samples,min_time=args.min_time,warmups=args.warmups)
                for process in range(args.processes):
                    print(f'Timing {layout}/{size}: process {process+1}/{args.processes}; elapsed {(time.monotonic()-start)/60:.1f} min',flush=True)
                    result=runner.run_worker(dict(config,mode='timing',process=process),300)
                    current=result['environment']
                    assert current['revision']==info['release_commit'] and not current['dirty']
                    assert current['source_sha256']==info['library_sha256']
                    if baseline is not None:assert current==baseline,'source/environment changed'
                    baseline=current
                    for case,measurement in sorted(result['rows'].items()):
                        for sample,seconds in enumerate(measurement['seconds']):
                            writer.writerow(dict(layout=layout,size=size,particles=result['input']['particles'],
                                                visible_particles=result['input']['visible_particles'],case=case,
                                                process=process,sample=sample,loops=measurement['loops'],seconds=repr(seconds)))
                    samples.flush()
                print(f'Allocations {layout}/{size}',flush=True)
                result=runner.run_worker(dict(config,mode='memory',process=0),300)
                assert result['environment']==baseline
                for case,values in sorted(result['rows'].items()):allocations.writerow(dict(layout=layout,size=size,case=case,**values))
                allocation_file.flush()
    summary=analyse(args.output)
    with (args.output/'provenance.md').open('a') as stream:stream.write(f'\n- Final load averages: `{os.getloadavg()}`\n')
    print(f'Completed {len(summary)} rows in {(time.monotonic()-start)/60:.1f} min.',flush=True)


if __name__=='__main__':main()
