"""Post-collection stage instrumentation, separate from benchmark estimates."""
import argparse
import csv
from pathlib import Path
import sys
import time
import common


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=args.source.resolve();sys.path.insert(0,str(source))
    import lvec
    assert Path(lvec.__file__).resolve().parent==source.resolve()/'lvec'
    from lvec import LVec
    from cms_data import load_cache
    import cms_analysis as analysis
    output=args.output;output.mkdir(parents=True,exist_ok=False)
    rows=[];original_good=analysis.good_muons;original_init=LVec.__init__
    for name in ('raw-four-muon','eligible-four-muon'):
        columns=load_cache(Path('/tmp/lvec-cms-open-data')/f'{name}.npz')
        expected=analysis.calculate(columns,'components','rest_frame')
        stages={'good_calls':0,'good_seconds':0.,'owned_calls':0}
        def good(columns):
            start=time.perf_counter();result=original_good(columns)
            stages['good_seconds']+=time.perf_counter()-start;stages['good_calls']+=1
            return result
        def owned(self,*args,**kwargs):
            stages['owned_calls']+=1;return original_init(self,*args,**kwargs)
        analysis.good_muons=good;LVec.__init__=owned
        try:
            LVec(0.,0.,0.,1.);assert stages['owned_calls']==1
            stages['owned_calls']=0
            start=time.perf_counter();actual=analysis.calculate(columns,'lvec','rest_frame')
            total=time.perf_counter()-start
        finally:analysis.good_muons=original_good;LVec.__init__=original_init
        analysis.check(actual,expected)
        assert stages['good_calls']==1 and 0<stages['good_seconds']<=total
        rows.append(dict(bank=name,input_events=len(columns['nMuon']),accepted=int(actual['counts'][-1]),
            instrumented_wall_seconds=total,good_muons_seconds=stages['good_seconds'],
            good_muons_fraction=stages['good_seconds']/total,owned_lvec_factories=stages['owned_calls']))
    with (output/'stages.csv').open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (output/'README.md').write_text('# Post-collection CMS stage diagnostics\n\nOne instrumented candidate rest-frame call per bank on the recorded host, after all timing collection. A wrapper records quality-selection wall time and owned factories; an owned-constructor positive control and one-call quality check validate the counters. Component-reference checks are outside instrumentation. Input loading is excluded. These diagnostic observations are not benchmark estimates or uncertainty intervals. Source library SHA256: '+common.fingerprint(source/'lvec')+'.\n')
    for row in rows:print(row)


if __name__=='__main__':main()
