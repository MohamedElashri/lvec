"""Rounding stages and decision changes under physical longitudinal boosts."""
import argparse
import csv
from decimal import Decimal,localcontext
from fractions import Fraction
from pathlib import Path
import subprocess
import sys

import common
import numpy as np
from references import rational,invariant,root_reference

GAMMAS=(1,2,10,100,1000,10000,1000000)


def transform(row,gamma,precision):
    with localcontext() as ctx:
        ctx.prec=precision
        p=[Decimal.from_float(float(v)) for v in row];g=Decimal(gamma);k=(g*g-1).sqrt()
        return [float(p[0]),float(p[1]),float(g*p[2]+k*p[3]),float(g*p[3]+k*p[2])]


def exact_mass(rows):
    total=[sum((rational(row[k]) for row in rows),Fraction()) for k in range(4)]
    squared=total[3]**2-sum(v*v for v in total[:3])
    return float(root_reference(squared))


def decision(m):return int(5.15<m<5.45)
def mass_bin(m):return int(np.searchsorted(np.linspace(4.7,6.2,151),m,side='right')-1)


def worker(args):
    sys.path.insert(0,str(args.source.resolve()))
    import lvec,vector
    assert Path(lvec.__file__).resolve().parent==args.source.resolve()/'lvec'
    from lhcb_analysis import momenta,energies
    from lhcb_data import KAON
    from lvec import LVec
    from component_vectors import Components
    records=[];rng=np.random.default_rng(20261103)
    for polarity in ('down','up'):
        with np.load(args.cache/f'pid-selected-{polarity}.npz',allow_pickle=False) as bank:
            indices=np.sort(rng.choice(len(bank['H1_PX']),256,replace=False))
            columns={name:bank[name][indices] for name in bank.files}
        spatial=momenta(columns);es=energies(spatial,(KAON,)*3)
        daughters=np.stack([np.column_stack((*p,e)) for p,e in zip(spatial,es)],axis=1)
        for gamma in GAMMAS:
            transformed=np.array([[transform(row,gamma,400) for row in tracks] for tracks in daughters])
            # Independent precision convergence check of every transformed binary output.
            high=np.array([[transform(row,gamma,800) for row in tracks] for tracks in daughters])
            assert np.array_equal(transformed,high)
            objects=[]
            for j in range(3):
                values=transformed[:,j,:];fields=dict(zip(('px','py','pz','E'),values.T))
                if args.backend=='lvec':obj=LVec(**fields)
                elif args.backend=='vector':obj=vector.array(fields)
                else:obj=Components(*values.T)
                objects.append(obj)
            parent=objects[0]+objects[1]+objects[2]
            masses=np.asarray(parent.mass)
            rounded_parent=np.column_stack([getattr(parent,key) for key in ('px','py','pz','E')])
            for i,tracks in enumerate(daughters):
                original=exact_mass(tracks);input_mass=exact_mass(transformed[i]);parent_mass=exact_mass([rounded_parent[i]])
                m=float(masses[i])
                records.append(dict(polarity=polarity,selected_bank_row=int(indices[i]),gamma=gamma,backend=args.backend,
                    original_mass=original,transformed_input_mass=input_mass,rounded_parent_mass=parent_mass,computed_mass=m,
                    input_error=input_mass-original,addition_error=parent_mass-input_mass,arithmetic_error=m-parent_mass,
                    total_error=m-original,input_cut_change=int(decision(input_mass)!=decision(original)),
                    addition_cut_change=int(decision(parent_mass)!=decision(input_mass)),arithmetic_cut_change=int(decision(m)!=decision(parent_mass)),
                    total_cut_change=int(decision(m)!=decision(original)),input_bin_change=int(mass_bin(input_mass)!=mass_bin(original)),
                    addition_bin_change=int(mass_bin(parent_mass)!=mass_bin(input_mass)),arithmetic_bin_change=int(mass_bin(m)!=mass_bin(parent_mass)),
                    total_bin_change=int(mass_bin(m)!=mass_bin(original)),spacelike_input=int(input_mass<0)))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    print(args.backend,len(records),'physical transformed candidates checked',flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=Path('/tmp/lvec-native-awkward'))
    p.add_argument('--cache',type=Path,default=Path('/tmp/lvec-lhcb-open-data'));p.add_argument('--output',type=Path,required=True)
    p.add_argument('--backend',choices=('lvec','vector','components'),default='lvec');args=p.parse_args();worker(args)


if __name__=='__main__':main()
