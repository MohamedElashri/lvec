"""Untimed path counts for the retained physical-boost sample, with output checks."""
import argparse
import csv
from pathlib import Path

from study_source import PAPER, activate_source, fingerprint


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', type=Path, default=Path('/tmp/lvec-lhcb-open-data'))
    parser.add_argument('--source', type=Path)
    parser.add_argument('--input', type=Path, default=PAPER / 'results/complete/numerical/candidate.csv')
    parser.add_argument('--output', type=Path, default=PAPER / 'results/referee-revision')
    args = parser.parse_args()
    if args.source:
        import sys, tomllib
        source = args.source.resolve()
        expected_source = tomllib.loads((PAPER / 'source.toml').read_text())['source']
        assert fingerprint(source / 'lvec') == expected_source['library_sha256']
        sys.path.insert(0, str(source))
    else:
        source = activate_source()
    import numpy as np
    from lvec import LVec
    import lvec.utils as utils
    import lvec._exact as exact
    from lhcb_analysis import momenta, energies
    from lhcb_data import KAON
    from physics_effects import transform, GAMMAS

    directory = args.output
    directory.mkdir(parents=True, exist_ok=True)
    with args.input.open() as stream:
        expected = {(r['polarity'], int(r['selected_bank_row']), int(r['gamma'])): float(r['computed_mass'])
                    for r in csv.DictReader(stream)}
    counters = {g: dict(gamma=g, candidates=0, recovered=0, compensated_attempts=0, integer=0)
                for g in GAMMAS}
    active = None
    original_accurate, original_compensated, original_integer = utils.accurate_result, exact._compensated_sum, exact._numpy_result

    def accurate(values, *positional, **keywords):
        active['recovered'] += np.asarray(values[0]).size
        return original_accurate(values, *positional, **keywords)

    def compensated(values, **keywords):
        active['compensated_attempts'] += np.asarray(values[0]).size
        return original_compensated(values, **keywords)

    def integer(values, **keywords):
        active['integer'] += np.asarray(values[0]).size
        return original_integer(values, **keywords)

    rng = np.random.default_rng(20261103)
    try:
        utils.accurate_result, exact._compensated_sum, exact._numpy_result = accurate, compensated, integer
        for polarity in ('down', 'up'):
            with np.load(args.cache / f'pid-selected-{polarity}.npz', allow_pickle=False) as bank:
                indices = np.sort(rng.choice(len(bank['H1_PX']), 256, replace=False))
                columns = {name: bank[name][indices] for name in bank.files}
            spatial = momenta(columns)
            es = energies(spatial, (KAON,) * 3)
            daughters = np.stack([np.column_stack((*p, e)) for p, e in zip(spatial, es)], axis=1)
            for gamma in GAMMAS:
                active = counters[gamma]
                transformed = np.array([[transform(row, gamma, 400) for row in tracks] for tracks in daughters])
                vectors = [LVec(*transformed[:, j, :].T) for j in range(3)]
                masses = np.asarray((vectors[0] + vectors[1] + vectors[2]).mass)
                wanted = [expected[polarity, int(index), gamma] for index in indices]
                np.testing.assert_array_equal(masses, wanted)
                active['candidates'] += len(indices)
    finally:
        utils.accurate_result, exact._compensated_sum, exact._numpy_result = original_accurate, original_compensated, original_integer
    with (directory / 'recovery-paths.csv').open('w', newline='') as stream:
        rows = list(counters.values())
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (directory / 'recovery-paths.toml').write_text(
        f'library_sha256 = "{fingerprint(source / "lvec")}"\n'
        'retained_masses_matched = 3584\n'
        'timings_collected = false\n'
        'note = "Compensated attempts and integer recovery can overlap."\n')
    print(*rows, sep='\n')


if __name__ == '__main__':
    main()
